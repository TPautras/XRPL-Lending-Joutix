/// <reference types="chrome" />
/// <reference types="chrome" />

import * as CrossmarkTypings from '@crossmarkio/typings/sdk';
import * as GemWalletAPI from '@gemwallet/api';
import { Network } from '@xyrawallet/sdk';
import { SignClientTypes } from '@walletconnect/types';
import { SubmittableTransaction } from 'xrpl';
import * as XamanOAuth2 from 'xumm-oauth2-pkce';
import * as XamanSDK from 'xumm';

/**
 * Account information returned after connection
 */
export declare interface AccountInfo {
    address: string;
    publicKey?: string;
    network: NetworkInfo;
}

/**
 * Packaged adapters in their recommended display order.
 *
 * `remote` wallets open a hosted/QR flow, `extension` wallets require an
 * injected browser provider, `browser` wallets need browser primitives such as
 * popups, and `device` wallets require browser hardware APIs.
 */
export declare const ADAPTER_DESCRIPTORS: readonly [{
    readonly exportKey: "Xaman";
    readonly id: "xaman";
    readonly name: "Xaman";
    readonly Adapter: typeof XamanAdapter;
    readonly availability: "remote";
    readonly configuration: {
        readonly requiredOptions: readonly ["apiKey"];
        readonly supportsDeferredConnection: true;
    };
}, {
    readonly exportKey: "Crossmark";
    readonly id: "crossmark";
    readonly name: "Crossmark";
    readonly Adapter: typeof CrossmarkAdapter;
    readonly availability: "extension";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}, {
    readonly exportKey: "GemWallet";
    readonly id: "gemwallet";
    readonly name: "GemWallet";
    readonly Adapter: typeof GemWalletAdapter;
    readonly availability: "extension";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}, {
    readonly exportKey: "WalletConnect";
    readonly id: "walletconnect";
    readonly name: "WalletConnect";
    readonly Adapter: typeof WalletConnectAdapter;
    readonly availability: "remote";
    readonly configuration: {
        readonly requiredOptions: readonly ["projectId"];
        readonly supportsDeferredConnection: true;
    };
}, {
    readonly exportKey: "Ledger";
    readonly id: "ledger";
    readonly name: "Ledger";
    readonly Adapter: typeof LedgerAdapter;
    readonly availability: "device";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}, {
    readonly exportKey: "Xyra";
    readonly id: "xyra";
    readonly name: "Xyra";
    readonly Adapter: typeof XyraAdapter;
    readonly availability: "browser";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}, {
    readonly exportKey: "Otsu";
    readonly id: "otsu";
    readonly name: "Otsu";
    readonly Adapter: typeof OtsuAdapter;
    readonly availability: "extension";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}, {
    readonly exportKey: "MetaMaskSnap";
    readonly id: "metamask-snap";
    readonly name: "MetaMask Snap";
    readonly Adapter: typeof MetaMaskSnapAdapter;
    readonly availability: "extension";
    readonly configuration: {
        readonly requiredOptions: readonly [];
        readonly supportsDeferredConnection: false;
    };
}];

export declare type AdapterAvailability = 'remote' | 'extension' | 'browser' | 'device';

declare type AdapterConstructor<TKey extends AdapterExportKey> = (typeof Adapters)[TKey];

/** Metadata for one packaged adapter, tied to its exact constructor and runtime ID. */
export declare type AdapterDescriptor = { [TKey in AdapterExportKey]: DescriptorFor<TKey>; }[AdapterExportKey];

declare type AdapterEventListener = (data?: unknown) => void;

export declare type AdapterExportKey = keyof typeof Adapters;

declare type AdapterInstance<TKey extends AdapterExportKey> = InstanceType<AdapterConstructor<TKey>>;

declare type AdapterOptionKey<TKey extends AdapterExportKey> = Extract<keyof AdapterOptions<TKey>, string>;

declare type AdapterOptions<TKey extends AdapterExportKey> = ConstructorParameters<AdapterConstructor<TKey>> extends [] ? never : NonNullable<ConstructorParameters<AdapterConstructor<TKey>>[0]>;

/** Constructors for every adapter included in the umbrella package. */
export declare const Adapters: {
    readonly Xaman: typeof XamanAdapter;
    readonly Crossmark: typeof CrossmarkAdapter;
    readonly GemWallet: typeof GemWalletAdapter;
    readonly WalletConnect: typeof WalletConnectAdapter;
    readonly Ledger: typeof LedgerAdapter;
    readonly Xyra: typeof XyraAdapter;
    readonly Otsu: typeof OtsuAdapter;
    readonly MetaMaskSnap: typeof MetaMaskSnapAdapter;
};

/**
 * Resolve whether an adapter supports a capability, applying
 * {@link CAPABILITY_DEFAULTS} when the adapter doesn't declare it.
 */
export declare function adapterSupports(adapter: WalletAdapter, capability: keyof WalletCapabilities): boolean;

/**
 * Address display configuration
 */
export declare const ADDRESS_DISPLAY: {
    readonly TRUNCATE_CHARS_DEFAULT: 6;
    readonly TRUNCATE_CHARS_BUTTON: 4;
};

/**
 * Adjust color brightness
 * @param hex - Hex color string
 * @param amount - Amount to adjust (0-1), positive for lighter, negative for darker
 * @returns Adjusted hex color
 */
export declare function adjustColorBrightness(hex: string, amount: number): string;

/**
 * Browser detection patterns.
 *
 * Mobile/tablet detection (incl. iPadOS desktop-mode) lives in
 * `@xrpl-connect/core`'s `isMobile()`; this only retains the Safari probe used
 * by `isSafari()` for user-gesture preservation.
 */
export declare const BROWSER_PATTERNS: {
    readonly SAFARI: RegExp;
};

/**
 * Calculate luminance to determine if text should be black or white
 * Based on WCAG relative luminance formula
 * @param hex - Hex color string (with or without #)
 * @returns Luminance value between 0 and 1
 */
export declare function calculateLuminance(hex: string): number;

/**
 * Default value for each capability when an adapter doesn't declare it.
 */
export declare const CAPABILITY_DEFAULTS: Readonly<Required<WalletCapabilities>>;

/**
 * Color adjustment constants
 */
export declare const COLOR_ADJUSTMENT: {
    readonly HOVER_BRIGHTNESS: 0.15;
    readonly MAX_COLOR_VALUE: 255;
};

/**
 * Configure the global logger used by every `Logger` instance — including the
 * per-adapter loggers created via `createLogger`. Called by `WalletManager`
 * when a consumer passes `logger` in `WalletManagerOptions`.
 *
 * - A `LoggerInstance` routes every subsequent log call (from the manager and
 *   all adapters) into the supplied object.
 * - A `LoggerOptions` value sets a global default level. Per-logger overrides
 *   still win when explicitly set.
 * - `undefined` resets the global configuration.
 */
export declare function configureLogger(option: LoggerOptions | LoggerInstance | undefined): void;

/**
 * Options for connecting to a wallet
 */
export declare type ConnectOptions<WalletSpecificOptions extends object = {}> = {
    network?: NetworkConfig;
    autoReconnect?: boolean;
    /**
     * Ask the adapter to return the address without prompting for permission when
     * it already has access (mirrors SEP-43 `skipRequestAccess`). Adapters that
     * can't distinguish silent access may ignore this.
     */
    skipRequestAccess?: boolean;
} & WalletSpecificOptions;

/** Connection options narrowed to the selected packaged wallet. */
export declare type ConnectOptionsFor<Wallet extends WalletIdentifier> = ConnectOptions<WalletSpecificConnectOptions<Wallet>>;

/** Instantiate every packaged adapter in canonical display order. */
export declare function createAdapters(configuration?: PackagedAdapterOptions): WalletAdapter[];

/**
 * Create a logger instance with a specific prefix
 * Useful for creating loggers in different packages/modules
 */
export declare function createLogger(prefix: string, level?: LoggerOptions['level']): Logger;

/**
 * Helper functions to create specific error types
 */
export declare const createWalletError: {
    notFound: (walletId: string) => WalletError;
    notInstalled: (walletName: string) => WalletError;
    notAvailable: (walletName: string) => WalletError;
    configurationRequired: (walletName: string, missingFields: readonly string[]) => WalletError;
    connectionFailed: (walletName: string, originalError?: Error) => WalletError;
    connectionRejected: (walletName: string, originalError?: Error) => WalletError;
    signFailed: (originalError?: Error) => WalletError;
    signRejected: (originalError?: Error) => WalletError;
    networkNotSupported: (networkId: string, walletName: string) => WalletError;
    networkMismatch: (expected: string, actual: string) => WalletError;
    notConnected: () => WalletError;
    alreadyConnected: (walletName: string) => WalletError;
    unsupportedMethod: (message: string) => WalletError;
    unknown: (message: string, originalError?: Error) => WalletError;
};

/** Public request tracked by Crossmark while it awaits a wallet response. */
export declare interface CrossmarkActiveRequest {
    resolve: (value: unknown) => void;
    reject: (value: unknown) => void;
}

/**
 * Crossmark adapter implementation
 */
export declare class CrossmarkAdapter implements WalletAdapter, SupportsFetchAccount {
    readonly id = "crossmark";
    readonly name = "Crossmark";
    readonly icon: string;
    readonly url = "https://crossmark.io";
    readonly capabilities: WalletCapabilities;
    private currentAccount;
    private connectionGeneration;
    private accountRefreshRevision;
    constructor(_options?: CrossmarkAdapterOptions);
    /**
     * Check if Crossmark is installed
     */
    isAvailable(): Promise<boolean>;
    /**
     * Connect to Crossmark wallet
     */
    connect(options?: ConnectOptions): Promise<AccountInfo>;
    /**
     * Disconnect from Crossmark
     */
    disconnect(): Promise<void>;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Fetch the active account and network directly from Crossmark.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    private getLiveNetwork;
    private assertCurrentNetwork;
    private resolveRequestedNetwork;
    /**
     * Get current network
     */
    getNetwork(): Promise<NetworkInfo>;
    private toNetworkInfo;
    /**
     * Sign a transaction without submitting it to the ledger
     * @param transaction - The transaction to sign
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger
     * @param transaction - The transaction to sign and submit
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Generate a random hash for signing
     */
    private generateRandomHash;
}

/**
 * Crossmark adapter options
 */
export declare interface CrossmarkAdapterOptions {}

/** Promise-based Crossmark methods. */
export declare interface CrossmarkAsyncMethods {
    readonly sdk: CrossmarkClient;
    readonly api: CrossmarkRequestAPI;
    readonly session: CrossmarkSession;
    readonly mount: CrossmarkMount;
    signInAndWait(hex?: string): Promise<typeof CrossmarkTypings.Models.SignInFullResponse>;
    signAndWait(transaction: CrossmarkTransaction, options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.SignFullResponse>;
    submitAndWait(address: string, transactionBlob: string, options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.SubmitFullResponse>;
    signAndSubmitAndWait(transaction: CrossmarkTransaction, options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.SignAndSubmitFullResponse>;
    bulkSignAndWait(transactions: CrossmarkIndexedTransaction[], options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.BulkSignFullResponse>;
    bulkSubmitAndWait(address: string, transactionBlobs: string[], options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.BulkSubmitFullResponse>;
    bulkSignAndSubmitAndWait(transactions: CrossmarkIndexedTransaction[], options?: CrossmarkSignOptions): Promise<typeof CrossmarkTypings.Models.BulkSignAndSubmitFullResponse>;
    readonly encryptAndWait: {
        aes(address: string, data: string, options?: CrossmarkCryptOptions): Promise<typeof CrossmarkTypings.Models.EncryptFullResponse>;
    };
    readonly decryptAndAwait: {
        aes(address: string, hex: string, options?: CrossmarkCryptOptions): Promise<typeof CrossmarkTypings.Models.DecryptFullResponse>;
    };
    isLockedAndWait(): Promise<typeof CrossmarkTypings.Models.IsLockedFullResponse>;
    versionAndWait(): Promise<typeof CrossmarkTypings.Models.VersionFullResponse>;
    verifyAndWait(hex: string): Promise<typeof CrossmarkTypings.Models.VerifyFullResponse>;
    connect(timeout?: number): Promise<boolean>;
    detect(timeout?: number): Promise<boolean>;
}

/** Complete Crossmark client surface. */
export declare interface CrossmarkClient extends CrossmarkEventEmitter {
    readonly mount: CrossmarkMount;
    readonly api: CrossmarkRequestAPI;
    readonly session: CrossmarkSession;
    readonly env: CrossmarkEnvironment;
    readonly async: CrossmarkAsyncMethods;
    readonly sync: CrossmarkSyncMethods;
    readonly methods: CrossmarkAsyncMethods & CrossmarkSyncMethods;
    readonly app: typeof CrossmarkTypings.Config.config.title;
    on(event: typeof CrossmarkTypings.EVENTS.PING, listener: () => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.CLOSE, listener: () => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.OPEN, listener: () => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.SIGNOUT, listener: () => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.USER_CHANGE, listener: (user: typeof CrossmarkTypings.BasicUser) => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.NETWORK_CHANGE, listener: (network: typeof CrossmarkTypings.BasicNetwork) => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.RESPONSE, listener: (response: CrossmarkTypings.Models.Response) => void): this;
    on(event: typeof CrossmarkTypings.EVENTS.ALL, listener: (event: typeof CrossmarkTypings.CatchAllEvent) => void): this;
    on(event: string | symbol, listener: CrossmarkListener): this;
}

/** Constructor exported by the upstream SDK as `vanilla`. */
declare interface CrossmarkClientConstructor {
    new (options?: {
        project: typeof CrossmarkTypings.Config.config.title;
    }): CrossmarkClient;
}

declare type CrossmarkCryptOptions = typeof CrossmarkTypings.Models.CryptOpts;

/** Runtime environment detected by Crossmark. */
export declare interface CrossmarkEnvironment {
    readonly isAndroid: boolean;
    readonly isIos: boolean;
    readonly isOpera: boolean;
    readonly isWindows: boolean;
    readonly isSSR: boolean;
    readonly isXApp: boolean;
    readonly isMobile: boolean;
    readonly isDesktop: boolean;
}

/** EventEmitter methods available on Crossmark SDK objects. */
export declare interface CrossmarkEventEmitter {
    addListener(event: string | symbol, listener: CrossmarkListener): this;
    on(event: string | symbol, listener: CrossmarkListener): this;
    once(event: string | symbol, listener: CrossmarkListener): this;
    removeListener(event: string | symbol, listener: CrossmarkListener): this;
    off(event: string | symbol, listener: CrossmarkListener): this;
    removeAllListeners(event?: string | symbol): this;
    setMaxListeners(count: number): this;
    getMaxListeners(): number;
    listeners(event: string | symbol): CrossmarkListener[];
    rawListeners(event: string | symbol): CrossmarkListener[];
    emit(event: string | symbol, ...args: unknown[]): boolean;
    listenerCount(event: string | symbol): number;
    prependListener(event: string | symbol, listener: CrossmarkListener): this;
    prependOnceListener(event: string | symbol, listener: CrossmarkListener): this;
    eventNames(): Array<string | symbol>;
}

declare type CrossmarkIndexedTransaction = typeof CrossmarkTypings.Models.IndexedTransactionRequest;

/** Listener accepted by Crossmark's EventEmitter-based APIs. */
export declare type CrossmarkListener = (...args: any[]) => void;

/** Crossmark extension discovery helper. */
export declare interface CrossmarkMount extends CrossmarkEventEmitter {
    readonly sdk: CrossmarkClient;
    readonly isDetected?: boolean;
    loop(timeout?: number): Promise<boolean>;
    on(event: 'detected', listener: () => void): this;
    on(event: string | symbol, listener: CrossmarkListener): this;
}

/** Low-level Crossmark request transport. */
export declare interface CrossmarkRequestAPI extends CrossmarkEventEmitter {
    readonly sdk: CrossmarkClient;
    readonly active: Map<string, CrossmarkActiveRequest>;
    readonly uuid: string;
    readonly connected: boolean;
    readonly target?: string;
    readonly timestamp?: number;
    awaitRequest(request: Partial<CrossmarkTypings.Models.Request>): Promise<CrossmarkResponse>;
    request(request: Partial<CrossmarkTypings.Models.Request>): string;
}

/** A response returned by the Crossmark SDK. */
export declare type CrossmarkResponse = CrossmarkTypings.Models.FullResponse;

/**
 * Complete Crossmark runtime SDK.
 *
 * A local structural type keeps the facade compatible with strict NodeNext
 * consumers; the upstream package's declarations reference private subpaths
 * that TypeScript cannot resolve through its `exports` map.
 */
export declare const CrossmarkSDK: CrossmarkSDKNamespace;

/** Collision-safe namespace mirroring every runtime export from `@crossmarkio/sdk`. */
export declare interface CrossmarkSDKNamespace {
    readonly default: CrossmarkClient;
    readonly modules: {
        readonly embark: CrossmarkClient;
        readonly xmark: CrossmarkClient;
    };
    readonly typings: typeof CrossmarkTypings;
    readonly vanilla: CrossmarkClientConstructor;
}

/** Current Crossmark wallet session. */
export declare interface CrossmarkSession {
    readonly sdk: CrossmarkClient;
    readonly user?: typeof CrossmarkTypings.BasicUser;
    readonly network?: typeof CrossmarkTypings.BasicNetwork;
    readonly address?: string;
    readonly isOpen: boolean;
    readonly lastPing?: number;
    readonly state: 'active' | 'unactive' | 'error';
    readonly responses: Map<string, CrossmarkResponse>;
    handleDetect(): Promise<void>;
    handlePing(): number;
    handleClose(): boolean;
    handleOpen(): boolean;
    handleSignOut(): void;
    handleNetworkChange(network: {
        network: typeof CrossmarkTypings.BasicNetwork;
    }): void;
    handleUserChange(user: {
        user: typeof CrossmarkTypings.BasicUser;
    }): void;
    handleResponse(response: CrossmarkResponse): void;
}

declare type CrossmarkSignOptions = typeof CrossmarkTypings.Models.ExtendedSignOpts;

/** Synchronous Crossmark request and state methods. */
export declare interface CrossmarkSyncMethods {
    readonly sdk: CrossmarkClient;
    readonly api: CrossmarkRequestAPI;
    readonly session: CrossmarkSession;
    readonly mount: CrossmarkMount;
    signIn(hex?: string): string;
    sign(transaction: CrossmarkTransaction, options?: CrossmarkSignOptions): string;
    submit(address: string, transactionBlob: string, options?: CrossmarkSignOptions): string;
    signAndSubmit(transaction: CrossmarkTransaction, options?: CrossmarkSignOptions): string;
    bulkSign(transactions: CrossmarkIndexedTransaction[], options?: CrossmarkSignOptions): string;
    bulkSubmit(address: string, transactionBlobs: string[], options?: CrossmarkSignOptions): string;
    bulkSignAndSubmit(transactions: CrossmarkIndexedTransaction[], options?: CrossmarkSignOptions): string;
    readonly encrypt: {
        aes(address: string, data: string, options?: CrossmarkCryptOptions): string;
    };
    readonly decrypt: {
        aes(address: string, hex: string, options?: CrossmarkCryptOptions): string;
    };
    getResponse(id: string): CrossmarkResponse | undefined;
    isConnected(): boolean | undefined;
    isInstalled(): boolean | undefined;
    isLocked(): string;
    isOpen(): boolean;
    version(): string;
    verify(hex: string): string;
    getAddress(): string | undefined;
    getNetwork(): typeof CrossmarkTypings.BasicNetwork | undefined;
    getUser(): typeof CrossmarkTypings.BasicUser | undefined;
}

declare type CrossmarkTransaction = typeof CrossmarkTypings.Models.AllTransactionRequest;

/**
 * Default theme colors
 */
export declare const DEFAULT_THEME: {
    readonly BACKGROUND_COLOR: "#000637";
    readonly TEXT_COLOR: "#F5F4E7";
    readonly PRIMARY_COLOR: "#0EA5E9";
    readonly DANGER_COLOR: "#ef4444";
    readonly FONT_FAMILY: "'Karla', sans-serif";
};

/**
 * Create a promise that resolves after a delay
 * @param ms - Delay in milliseconds
 * @returns Promise that resolves after delay
 */
export declare function delay(ms: number): Promise<void>;

declare type DescriptorFor<TKey extends AdapterExportKey> = {
    readonly exportKey: TKey;
    readonly id: AdapterInstance<TKey>['id'];
    readonly name: string;
    readonly Adapter: AdapterConstructor<TKey>;
    readonly availability: AdapterAvailability;
    readonly configuration: {
        readonly requiredOptions: readonly AdapterOptionKey<TKey>[];
        readonly supportsDeferredConnection: boolean;
    };
};

/**
 * Error codes for wallet operations
 */
export declare const ERROR_CODES: {
    readonly USER_REJECTED: 4001;
    readonly POPUP_CLOSED: -32002;
};

/**
 * Minimal `EventEmitter` interface that is molded against the Node.js
 * `EventEmitter` interface.
 */
declare class EventEmitter<
EventTypes extends EventEmitter.ValidEventTypes = string | symbol,
Context extends any = any
> {
    static prefixed: string | boolean;

    /**
     * Return an array listing the events for which the emitter has registered
     * listeners.
     */
    eventNames(): Array<EventEmitter.EventNames<EventTypes>>;

    /**
     * Return the listeners registered for a given event.
     */
    listeners<T extends EventEmitter.EventNames<EventTypes>>(
    event: T
    ): Array<EventEmitter.EventListener<EventTypes, T>>;

    /**
     * Return the number of listeners listening to a given event.
     */
    listenerCount(event: EventEmitter.EventNames<EventTypes>): number;

    /**
     * Calls each of the listeners registered for a given event.
     */
    emit<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    ...args: EventEmitter.EventArgs<EventTypes, T>
    ): boolean;

    /**
     * Add a listener for a given event.
     */
    on<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    fn: EventEmitter.EventListener<EventTypes, T>,
    context?: Context
    ): this;
    addListener<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    fn: EventEmitter.EventListener<EventTypes, T>,
    context?: Context
    ): this;

    /**
     * Add a one-time listener for a given event.
     */
    once<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    fn: EventEmitter.EventListener<EventTypes, T>,
    context?: Context
    ): this;

    /**
     * Remove the listeners of a given event.
     */
    removeListener<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    fn?: EventEmitter.EventListener<EventTypes, T>,
    context?: Context,
    once?: boolean
    ): this;
    off<T extends EventEmitter.EventNames<EventTypes>>(
    event: T,
    fn?: EventEmitter.EventListener<EventTypes, T>,
    context?: Context,
    once?: boolean
    ): this;

    /**
     * Remove all listeners, or those of the specified event.
     */
    removeAllListeners(event?: EventEmitter.EventNames<EventTypes>): this;
}

declare namespace EventEmitter {
    interface ListenerFn<Args extends any[] = any[]> {
        (...args: Args): void;
    }

    interface EventEmitterStatic {
        new <
        EventTypes extends ValidEventTypes = string | symbol,
        Context = any
        >(): EventEmitter<EventTypes, Context>;
    }

    /**
     * `object` should be in either of the following forms:
     * ```
     * interface EventTypes {
     *   'event-with-parameters': any[]
     *   'event-with-example-handler': (...args: any[]) => void
     * }
     * ```
     */
    type ValidEventTypes = string | symbol | object;

    type EventNames<T extends ValidEventTypes> = T extends string | symbol
    ? T
    : keyof T;

    type ArgumentMap<T extends object> = {
        [K in keyof T]: T[K] extends (...args: any[]) => void
        ? Parameters<T[K]>
        : T[K] extends any[]
        ? T[K]
        : any[];
    };

    type EventListener<
    T extends ValidEventTypes,
    K extends EventNames<T>
    > = T extends string | symbol
    ? (...args: any[]) => void
    : (
    ...args: ArgumentMap<Exclude<T, string | symbol>>[Extract<K, keyof T>]
    ) => void;

    type EventArgs<
    T extends ValidEventTypes,
    K extends EventNames<T>
    > = Parameters<EventListener<T, K>>;

    const EventEmitter: EventEmitterStatic;
}

/**
 * Font weights
 */
export declare const FONT_WEIGHTS: {
    readonly LIGHT: 300;
    readonly REGULAR: 400;
    readonly MEDIUM: 500;
    readonly SEMIBOLD: 600;
};

/**
 * GemWallet adapter implementation
 */
export declare class GemWalletAdapter implements WalletAdapter, SupportsFetchAccount {
    readonly id = "gemwallet";
    readonly name = "GemWallet";
    readonly icon: string;
    readonly url = "https://gemwallet.app";
    private currentAccount;
    private connectionGeneration;
    private accountRefreshRevision;
    constructor(_options?: GemWalletAdapterOptions);
    /**
     * Check if GemWallet is installed
     */
    isAvailable(): Promise<boolean>;
    /**
     * Connect to GemWallet
     */
    connect(options?: ConnectOptions): Promise<AccountInfo>;
    /**
     * Disconnect from GemWallet
     */
    disconnect(): Promise<void>;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Fetch the active account and network directly from GemWallet.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    private getLiveNetwork;
    private assertCurrentNetwork;
    private resolveRequestedNetwork;
    /**
     * Get current network
     */
    getNetwork(): Promise<NetworkInfo>;
    private toNetworkInfo;
    /**
     * Sign a transaction without submitting it to the ledger
     * @param transaction - The transaction to sign
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger
     * @param transaction - The transaction to sign and submit
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
}

/**
 * GemWallet adapter options
 */
export declare interface GemWalletAdapterOptions {}

export { GemWalletAPI }

/**
 * Get contrasting text color (black or white) based on background luminance
 * Ensures WCAG contrast compliance
 * @param backgroundColor - Background color in hex format
 * @returns '#ffffff' for dark backgrounds, '#000000' for light backgrounds
 */
export declare function getContrastTextColor(backgroundColor: string): string;

/**
 * Get error message from unknown error type
 */
export declare function getErrorMessage(error: unknown): string;

/** Return the configuration fields an adapter still needs before connecting. */
export declare function getMissingAdapterConfiguration(adapter: WalletAdapter, options?: ConnectOptions): readonly string[];

/** Return an absolute HTTP(S) URL that is safe to open outside the application. */
export declare function getSafeExternalUrl(value: string | undefined): string | null;

/**
 * Resolve the category for a given error code.
 */
export declare function getWalletErrorCategory(code: WalletErrorCode): WalletErrorCategory;

/**
 * Deterministic gradient generation from wallet addresses
 */
export declare const GRADIENT: {
    readonly HUE_MAX_DEGREES: 360;
    readonly HUE_OFFSET_DEGREES: 60;
    readonly SATURATION_PERCENT: 70;
    readonly LIGHTNESS_PERCENT: 55;
};

declare type InternalLogLevel = 'debug' | 'info' | 'warn' | 'error' | 'silent';

/** Whether an adapter has enough configuration to begin a connection. */
export declare function isAdapterConfigured(adapter: WalletAdapter, options?: ConnectOptions): boolean;

/**
 * Type guard for a user-supplied LoggerInstance.
 */
export declare function isLoggerInstance(value: unknown): value is LoggerInstance;

/**
 * Device / browser detection helpers.
 *
 * Framework-agnostic and safe to call in non-DOM environments (SSR, workers),
 * where they degrade to `false` instead of throwing on a missing `navigator`.
 */
/**
 * Detect if the user is on a mobile (phone/tablet) device.
 *
 * Beyond the usual user-agent sniff, this also catches iPadOS 13+ in its default
 * "desktop" mode, which reports a `Macintosh` user-agent indistinguishable from a
 * real Mac except that it is a touch device (`maxTouchPoints > 1`; desktop Safari
 * reports `0`). Without this, iPads fall through to the desktop QR flow instead of
 * the mobile deep-link/modal flow. (#16)
 *
 * @returns true if mobile device
 */
export declare function isMobile(): boolean;

/**
 * Detect if browser is Safari
 * Safari requires immediate connection (user gesture preservation)
 * @returns true if Safari browser
 */
export declare function isSafari(): boolean;

export declare function isStandardNetworkId(networkId: string): networkId is StandardNetworkId;

/**
 * Check if an error is a WalletError
 */
export declare function isWalletError(error: unknown): error is WalletError;

/**
 * Check if URI is a Xaman QR code image
 * Xaman provides PNG images directly instead of WalletConnect URIs
 * @param uri - URI to check
 * @returns true if Xaman QR code image URL
 */
export declare function isXamanQRImage(uri: string): boolean;

/**
 * User-friendly messages for each device state
 */
export declare const LEDGER_STATE_MESSAGES: Record<LedgerDeviceState, string>;

/**
 * Ledger adapter implementation
 */
export declare class LedgerAdapter implements WalletAdapter, SupportsFetchAccount, SupportsReconnectOptions {
    readonly id = "ledger";
    readonly name = "Ledger";
    readonly icon: string;
    readonly url = "https://www.ledger.com";
    readonly capabilities: WalletCapabilities;
    private transport;
    private xrpApp;
    private currentAccount;
    private derivationPath;
    private timeout;
    private preferWebHID;
    private connectionGeneration;
    private accountDiscoveryGeneration;
    private accountDiscoveryTransports;
    constructor(options?: LedgerAdapterOptions);
    /**
     * Check if Ledger is available (browser supports WebHID/WebUSB)
     */
    isAvailable(): Promise<boolean>;
    /** Persist the effective path used to derive the connected Ledger address. */
    serializeReconnectOptions(_options: ConnectOptions<LedgerConnectOptions>): ReconnectOptions;
    /**
     * Get the current device state
     */
    getDeviceState(): Promise<LedgerDeviceState>;
    /**
     * Connect to Ledger device
     */
    connect(options?: ConnectOptions<LedgerConnectOptions>): Promise<AccountInfo>;
    /**
     * Disconnect from Ledger
     */
    disconnect(): Promise<void>;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Re-read the configured derivation path from the connected Ledger device.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    /**
     * Get current network
     */
    getNetwork(): Promise<NetworkInfo>;
    /** Encode and sign a prepared transaction with the Ledger device. */
    private signPreparedTransaction;
    private getSigningContext;
    private validateSigningInput;
    private withClient;
    /**
     * Sign a transaction without submitting it to the ledger
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Get multiple accounts from Ledger device
     * Useful for account selection UI
     *
     * @param count Number of accounts to retrieve (default: 5)
     * @param startIndex Starting account index (default: 0)
     * @returns Array of account addresses with their derivation paths
     *
     * @example
     * ```typescript
     * const accounts = await ledgerAdapter.getAccounts(5, 0);
     * // Returns accounts at paths 44'/144'/0'/0/0 through 44'/144'/4'/0/0
     * ```
     */
    getAccounts(count?: number, startIndex?: number): Promise<Array<{
        address: string;
        publicKey: string;
        path: string;
        index: number;
    }>>;
    /**
     * Create transport (WebHID or WebUSB)
     */
    private createTransport;
    /**
     * Clean up transport connection
     */
    private cleanup;
    private closeTransport;
    /**
     * Wrap promise with timeout
     */
    private withTimeout;
}

/**
 * Ledger adapter types and interfaces
 */
/**
 * Options for configuring the Ledger adapter
 */
export declare interface LedgerAdapterOptions {
    /**
     * BIP44 derivation path for the XRP account
     * If not specified, accountIndex will be used to generate the path
     * @default "44'/144'/0'/0/0"
     */
    derivationPath?: string;
    /**
     * Account index for automatic path generation (44'/144'/N'/0/0)
     * Only used if derivationPath is not provided
     * @default 0
     */
    accountIndex?: number;
    /**
     * Timeout for operations (in milliseconds)
     * @default 60000 (60 seconds)
     */
    timeout?: number;
    /**
     * Prefer WebHID over WebUSB when both are available
     * @default true
     */
    preferWebHID?: boolean;
}

export declare type LedgerConnectOptions = {
    derivationPath?: string;
    accountIndex?: number;
};

/**
 * Ledger device connection states
 */
export declare enum LedgerDeviceState {
    /** Device is not connected via USB */
    NOT_CONNECTED = "NOT_CONNECTED",
    /** Device is connected but locked (PIN required) */
    LOCKED = "LOCKED",
    /** Device is unlocked but XRP app is not open */
    APP_NOT_OPEN = "APP_NOT_OPEN",
    /** Device is ready (unlocked and XRP app open) */
    READY = "READY",
    /** Unknown state or error */
    UNKNOWN = "UNKNOWN"
}

/**
 * LocalStorage-based storage adapter
 */
export declare class LocalStorageAdapter implements StorageAdapter {
    private readonly prefix;
    get(key: string): Promise<string | null>;
    set(key: string, value: string): Promise<void>;
    remove(key: string): Promise<void>;
    clear(): Promise<void>;
}

/**
 * Logger class for structured logging.
 *
 * Resolution order for the effective level:
 *   1. Explicit level passed to the constructor / `setLevel`.
 *   2. Global level set via `configureLogger`.
 *   3. `'debug'` in development, `'warn'` in production.
 *
 * When a custom `LoggerInstance` is configured globally, all log calls are
 * routed to that instance instead of `console.*`.
 */
export declare class Logger {
    private localLevel?;
    private prefix;
    constructor(options?: LoggerOptions);
    /**
     * Compute the level that should apply to this logger right now.
     */
    private effectiveLevel;
    /**
     * Check if a log level should be output
     */
    private shouldLog;
    /**
     * Format log message with prefix
     */
    private formatMessage;
    /**
     * Log debug message
     */
    debug(message: string, ...args: unknown[]): void;
    /**
     * Log info message
     */
    info(message: string, ...args: unknown[]): void;
    /**
     * Log warning message
     */
    warn(message: string, ...args: unknown[]): void;
    /**
     * Log error message
     */
    error(message: string, ...args: unknown[]): void;
    /**
     * Update log level
     */
    setLevel(level: LogLevel): void;
    /**
     * Get current effective log level
     */
    getLevel(): InternalLogLevel;
}

/**
 * A custom logger object the application can supply to route log output
 * (e.g. into Sentry, Datadog, or any structured logging stack).
 *
 * Method signatures match `console.debug/info/warn/error`.
 */
export declare interface LoggerInstance {
    debug(message: string, ...args: unknown[]): void;
    info(message: string, ...args: unknown[]): void;
    warn(message: string, ...args: unknown[]): void;
    error(message: string, ...args: unknown[]): void;
}

/**
 * Logger configuration options
 * Level is optional - defaults to 'debug' in development, 'warn' in production
 */
export declare interface LoggerOptions {
    level?: LogLevel;
    prefix?: string;
}

/**
 * Supported log levels.
 * `'silent'` disables all output; `'none'` is a deprecated alias kept for backwards compatibility.
 */
export declare type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'silent' | 'none';

/**
 * WCAG luminance constants
 */
export declare const LUMINANCE: {
    readonly THRESHOLD: 0.5;
    readonly GAMMA_CORRECTION_THRESHOLD: 0.03928;
    readonly GAMMA_CORRECTION_DIVISOR: 12.92;
    readonly GAMMA_CORRECTION_OFFSET: 0.055;
    readonly GAMMA_CORRECTION_POWER: 2.4;
    readonly GAMMA_CORRECTION_BASE: 1.055;
    readonly RED_WEIGHT: 0.2126;
    readonly GREEN_WEIGHT: 0.7152;
    readonly BLUE_WEIGHT: 0.0722;
};

/** Message signature returned by WalletManager with a known signer. */
export declare type ManagedSignedMessage = SignedMessage & {
    signerAddress: string;
};

/** Transaction signature returned by WalletManager with a known signer. */
export declare type ManagedSignedTransaction = SignedTransaction & {
    signerAddress: string;
};

/**
 * In-memory storage adapter (for testing or SSR)
 */
export declare class MemoryStorageAdapter implements StorageAdapter {
    private storage;
    get(key: string): Promise<string | null>;
    set(key: string, value: string): Promise<void>;
    remove(key: string): Promise<void>;
    clear(): Promise<void>;
}

/**
 * MetaMask Snap adapter implementation
 */
export declare class MetaMaskSnapAdapter implements WalletAdapter {
    readonly id = "metamask-snap";
    readonly name = "MetaMask";
    readonly icon: string;
    readonly url = "https://snaps.metamask.io/snap/npm/xrpl-snap/";
    private readonly snapId;
    private provider;
    private currentAccount;
    private connectionGeneration;
    constructor(options?: MetaMaskSnapAdapterOptions);
    /**
     * Get the MetaMask provider from the window object
     */
    private getProvider;
    /**
     * Check if MetaMask with Snaps support is available
     */
    isAvailable(): Promise<boolean>;
    /**
     * Connect to the XRPL Snap via MetaMask
     */
    connect(options?: ConnectOptions): Promise<AccountInfo>;
    /**
     * Disconnect from the snap
     */
    disconnect(): Promise<void>;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Get current network
     */
    getNetwork(): Promise<NetworkInfo>;
    /** Switch the Snap network and verify the active network before returning. */
    switchNetwork(network: NetworkConfig): Promise<NetworkInfo>;
    /**
     * Sign a transaction without submitting
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Invoke a method on the XRPL Snap
     */
    private invokeSnap;
    private readActiveNetwork;
    private resolveSupportedNetwork;
    private assertActiveNetwork;
    private selectNetwork;
}

/**
 * MetaMask Snap adapter options
 */
export declare interface MetaMaskSnapAdapterOptions {
    snapId?: string;
}

/**
 * Network configuration type - can be a standard network key or custom NetworkInfo
 */
export declare type NetworkConfig = StandardNetworkId | NetworkInfo;

/**
 * Network information
 */
export declare interface NetworkInfo {
    id: string;
    name: string;
    wss: string;
    rpc?: string;
    walletConnectId?: string;
}

/**
 * Order wallets by most-recently-used first (`mruIds`, newest first), keeping
 * the input order for wallets with no usage history. Stable: never reorders two
 * wallets that are both unused.
 *
 * @param wallets - Wallets to order.
 * @param mruIds - Wallet ids in most-recently-used order (newest first).
 */
export declare function orderWalletsByMru<T extends {
    id: string;
}>(wallets: T[], mruIds: string[]): T[];

/**
 * Network mapping between xrpl-connect network IDs and Otsu network identifiers.
 *
 * xrpl-connect uses: 'mainnet', 'testnet', 'devnet'
 * Otsu uses: 'mainnet', 'testnet', 'devnet'
 */
export declare const OTSU_NETWORK_MAP: Record<string, string>;

/**
 * Otsu adapter implementation for XRPL Connect.
 *
 * Otsu Wallet is an MV3 browser extension for XRPL that supports
 * mainnet, testnet, and devnet. It provides granular dApp permission
 * scopes (read, sign, submit, switchNetwork) and transaction simulation
 * with risk scanning before user approval.
 *
 * @example
 * ```typescript
 * import { WalletManager } from '@xrpl-connect/core';
 * import { OtsuAdapter } from '@xrpl-connect/adapter-otsu';
 *
 * const walletManager = new WalletManager({
 *   adapters: [new OtsuAdapter()],
 *   network: 'testnet',
 * });
 *
 * const account = await walletManager.connect('otsu');
 * console.log('Connected:', account.address);
 * ```
 */
export declare class OtsuAdapter implements WalletAdapter, SupportsFetchAccount {
    readonly id = "otsu";
    readonly name = "Otsu Wallet";
    readonly icon: any;
    readonly url = "https://github.com/RomThpt/otsu-wallet";
    private currentAccount;
    private connectionGeneration;
    private stateRevision;
    private listeners;
    private providerListeners;
    private providerListenerOwner;
    private providerListenerGeneration;
    /**
     * Check if the Otsu Wallet extension is installed.
     *
     * The extension injects a provider object at window.xrpl with
     * isOtsu=true. The provider is checked on every call so an extension
     * injected after adapter construction can be detected.
     */
    isAvailable(): Promise<boolean>;
    /**
     * Connect to Otsu Wallet.
     *
     * Triggers the extension's connection flow which opens a notification
     * popup where the user can approve the connection and select permission
     * scopes. The extension supports granular scopes: read, sign, submit,
     * and switchNetwork.
     *
     * @param options - Connection options (network config, etc.)
     * @returns Account info with address and network
     */
    connect(options?: ConnectOptions): Promise<AccountInfo>;
    /**
     * Disconnect from Otsu Wallet.
     *
     * Calls the extension's disconnect method to revoke the dApp's
     * permission, then clears local state.
     */
    disconnect(): Promise<void>;
    /**
     * Get the currently connected account information.
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Fetch the active account and network directly from the injected provider.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    /**
     * Get the current network information.
     *
     * Queries the extension for the active network and maps it to
     * an xrpl-connect NetworkInfo object.
     */
    getNetwork(): Promise<NetworkInfo>;
    /**
     * Sign a transaction without submitting it to the ledger.
     *
     * Opens the extension's signing popup where the user can review
     * the transaction details, simulation results, and risk warnings
     * before approving.
     *
     * @param transaction - The XRPL transaction object
     * @returns The signed transaction with tx_blob and hash
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger.
     *
     * Opens the extension's signing popup. On approval, the transaction
     * is signed and submitted to the connected network.
     *
     * @param transaction - The XRPL transaction object
     * @returns The submitted transaction result with hash
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign an arbitrary message for authentication or proof of ownership.
     *
     * @param message - The message to sign (string or Uint8Array)
     * @returns The signed message with signature and public key
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Register an event listener.
     */
    on(event: WalletAdapterEvent, callback: (data?: unknown) => void): void;
    /**
     * Remove an event listener.
     */
    off(event: WalletAdapterEvent, callback: (data?: unknown) => void): void;
    /**
     * Get the injected provider, throwing if not available.
     */
    private getProvider;
    /**
     * Get the injected provider without throwing.
     */
    private getProviderSafe;
    /**
     * Fetch network info from the provider and map to xrpl-connect NetworkInfo.
     */
    private fetchNetworkInfo;
    private resolveRequestedNetwork;
    private toNetworkInfo;
    /**
     * Verify that the provider is still on the network represented by the
     * cached account before asking it to sign. Otsu's signing methods do not
     * accept a network argument, so this live check prevents signing after an
     * unobserved wallet network switch.
     */
    private assertCurrentNetwork;
    /**
     * Set up listeners on the Otsu provider to forward events.
     */
    private setupProviderListeners;
    private getProviderEventValue;
    /**
     * Remove listeners from the Otsu provider.
     */
    private removeProviderListeners;
    /**
     * Emit an event to registered listeners.
     */
    private emit;
    /**
     * Map Otsu provider errors to xrpl-connect WalletError instances.
     */
    private mapError;
}

/**
 * Types for Otsu wallet adapter
 */
/**
 * Otsu provider interface injected at window.xrpl by the extension.
 *
 * The Otsu extension injects this provider into every page via
 * a content script. dApps interact with the wallet through this
 * interface using postMessage-based communication.
 */
export declare interface OtsuProvider {
    /** Identifies the provider as Otsu Wallet */
    isOtsu: boolean;
    /** Check if a dApp is currently connected */
    isConnected(): boolean;
    /** Request connection with optional permission scopes */
    connect(params?: {
        scopes?: string[];
    }): Promise<{
        address: string;
    }>;
    /** Disconnect the dApp */
    disconnect(): Promise<void>;
    /** Get the connected account address */
    getAddress(): Promise<{
        address: string;
    }>;
    /** Get the current network identifier */
    getNetwork(): Promise<{
        network: string;
    }>;
    /** Sign a transaction without submitting */
    signTransaction(tx: Record<string, unknown>): Promise<{
        tx_blob: string;
        hash: string;
    }>;
    /** Sign and submit a transaction to the ledger */
    signAndSubmit(tx: Record<string, unknown>): Promise<{
        tx_blob: string;
        hash: string;
    }>;
    /** Sign an arbitrary message */
    signMessage(message: string): Promise<{
        signature: string;
    }>;
    /** Register an event listener */
    on(event: string, callback: (data: unknown) => void): void;
    /** Remove an event listener */
    off(event: string, callback: (data: unknown) => void): void;
}

/** Constructor options keyed by canonical runtime wallet ID. */
export declare type PackagedAdapterOptions = { [TKey in AdapterExportKey as AdapterInstance<TKey>['id']]?: AdapterOptions<TKey>; };

/**
 * QR Code configuration
 */
export declare const QR_CONFIG: {
    SIZE: number;
    MARGIN: number;
    IMAGE_MARGIN: number;
    IMAGE_SIZE: number;
    DOT_COLOR: string;
    ERROR_CORRECTION_LEVEL: "Q";
    DOT_TYPE: "rounded";
    BACKGROUND_COLOR: string;
};

/**
 * Adapter-owned, JSON-safe options required to restore a wallet account.
 * Core-owned connection policy must not be overridden by persisted adapter data.
 */
export declare type ReconnectOptions = Record<string, unknown> & {
    network?: never;
    autoReconnect?: never;
};

/**
 * Resolve a `ConnectOptions['network']` value to a concrete `NetworkInfo`.
 *
 * - `undefined` → mainnet (default).
 * - `string` → looked up in `STANDARD_NETWORKS`; throws if unknown.
 * - `NetworkInfo` → returned as-is.
 */
export declare function resolveNetwork(config?: ConnectOptions['network']): NetworkInfo;

/**
 * Result of signing a message
 */
export declare interface SignedMessage {
    message: string;
    signature: string;
    publicKey: string;
    signerAddress?: string;
}

/**
 * Result of signing a transaction
 */
export declare interface SignedTransaction {
    hash: string;
    tx_blob?: string;
    signature?: string;
    signerAddress?: string;
    tx_json?: Transaction;
    [key: string]: unknown;
}

/**
 * Size constants (in pixels)
 */
export declare const SIZES: {
    readonly QR_CODE: 260;
    readonly QR_IMAGE_BORDER_RADIUS: 16;
    readonly LOADING_LOGO: 80;
    readonly MODAL_WIDTH: 343;
    readonly MODAL_BORDER_RADIUS: 20;
    readonly QR_CARD_PADDING: 28;
    readonly BUTTON_PADDING_VERTICAL: 16;
    readonly BUTTON_PADDING_HORIZONTAL: 20;
    readonly BUTTON_BORDER_RADIUS: 12;
    readonly ICON_SMALL: 24;
    readonly ICON_MEDIUM: 28;
    readonly ICON_LARGE: 80;
    readonly CLOSE_BUTTON_SIZE: 34;
    readonly HEADER_PADDING: 18;
};

export declare const STANDARD_NETWORKS: Record<StandardNetworkId, NetworkInfo>;

/** Canonical runtime IDs for the adapters packaged by `xrpl-connect`. */
export declare const STANDARD_WALLET_IDS: readonly ["xaman", "crossmark", "gemwallet", "walletconnect", "ledger", "xyra", "otsu", "metamask-snap"];

/**
 * Standard XRPL networks
 */
export declare type StandardNetworkId = 'mainnet' | 'testnet' | 'devnet';

/**
 * Registered migrations keyed by the source version. The entry at key `N`
 * upgrades a payload from version `N` to version `N + 1`. Migrations run
 * sequentially until the payload reaches the current version.
 *
 * v1 is the first versioned schema, so there are no upgrades yet. Anything
 * written before versioning was introduced is treated as unrecognized and
 * cleared rather than silently coerced.
 */
export declare const STATE_MIGRATIONS: Record<number, StoredStateMigration>;

/**
 * Storage manager for wallet state
 */
declare class Storage_2 {
    private static readonly STATE_KEY;
    private adapter;
    private version;
    private migrations;
    constructor(adapterOrOptions?: StorageAdapter | StorageOptions);
    /**
     * Save wallet connection state
     */
    saveState(state: StoredState): Promise<void>;
    /**
     * Load wallet connection state.
     *
     * Reads the stored envelope, runs any registered migrations to bring the
     * payload up to {@link STORED_STATE_VERSION}, and clears the entry instead
     * of throwing when the data is unrecognized, too new, or un-migratable.
     * Callers (notably `WalletManager.autoConnect`) must never see an
     * exception from this method.
     */
    loadState(): Promise<StoredState | null>;
    /**
     * Clear wallet connection state
     */
    clearState(): Promise<void>;
    /**
     * Clear all storage
     */
    clear(): Promise<void>;
    private migrate;
    private safeRemove;
}
export { Storage_2 as Storage }

/**
 * Storage adapter interface for persisting connection state
 */
export declare interface StorageAdapter {
    get(key: string): Promise<string | null>;
    set(key: string, value: string): Promise<void>;
    remove(key: string): Promise<void>;
    clear(): Promise<void>;
}

/**
 * Optional configuration for {@link Storage}. The `version` and `migrations`
 * fields are overridable primarily to allow unit-testing the migration
 * pipeline without mutating module-level state.
 */
export declare interface StorageOptions {
    adapter?: StorageAdapter;
    version?: number;
    migrations?: Record<number, StoredStateMigration>;
}

/**
 * Current persisted-state schema version. Bump this whenever the shape of
 * `StoredState` changes in a way that's not safely readable by older code,
 * and add a matching entry to `STATE_MIGRATIONS` that maps the previous
 * version's payload to the new shape.
 */
export declare const STORED_STATE_VERSION = 1;

/**
 * Stored connection state
 */
export declare interface StoredState {
    walletId: WalletIdentifier;
    account: AccountInfo;
    network: NetworkInfo;
    timestamp: number;
    /**
     * Adapter-selected, JSON-safe options required to restore the same account.
     * Arbitrary caller-provided connection options are never stored.
     */
    connectOptions?: ReconnectOptions;
}

/**
 * Versioned envelope written to storage. Older callers that read the raw
 * value will see `{ version, payload }` rather than a `StoredState`, and
 * the load path uses `version` to drive migrations.
 */
export declare interface StoredStateEnvelope<T = unknown> {
    version: number;
    payload: T;
}

/**
 * Migration function for upgrading a stored payload from version `N` to
 * version `N + 1`. Receives the previous payload as `unknown` so each
 * migration is responsible for reshaping it.
 */
export declare type StoredStateMigration = (payload: unknown) => unknown;

/**
 * Result of submitting a transaction to the ledger
 */
export declare interface SubmittedTransaction {
    hash: string;
    id?: string;
    tx_blob?: string;
    signature?: string;
    tx_json?: Transaction;
    [key: string]: unknown;
}

/**
 * Capability: adapter can transform a generic connection URI into a
 * wallet-specific deep link (e.g. mobile app handoff).
 */
export declare interface SupportsDeepLink {
    getDeepLinkURI(uri: string): string;
}

export declare function supportsDeepLink(adapter: WalletAdapter): adapter is WalletAdapter & SupportsDeepLink;

/**
 * Capability: adapter can query its wallet, provider, device, or authenticated
 * session for account information without opening a new connection flow.
 * This does not guarantee a live network query. Xaman refreshes its OAuth subject
 * and retains session network context, not the mobile app's current selection.
 */
export declare interface SupportsFetchAccount {
    fetchAccount(): Promise<AccountInfo | null>;
}

export declare function supportsFetchAccount(adapter: WalletAdapter): adapter is WalletAdapter & SupportsFetchAccount;

/**
 * Capability: a wallet authorization has returned to this page before the manager
 * could persist its session. Detection must be synchronous and side-effect free;
 * connect() must complete the returned authorization without starting a new one.
 */
export declare interface SupportsPendingConnection {
    hasPendingConnection(): boolean;
}

export declare function supportsPendingConnection(adapter: WalletAdapter): adapter is WalletAdapter & SupportsPendingConnection;

/**
 * Capability: adapter can pre-initialize its connection session before the
 * user picks the wallet, so the QR code / handshake is ready by the time the
 * UI opens its panel. Implemented by WalletConnect.
 */
export declare interface SupportsPreInitialize {
    preInitialize(network?: NetworkConfig, onQRCode?: (uri: string) => void): Promise<void>;
}

export declare function supportsPreInitialize(adapter: WalletAdapter): adapter is WalletAdapter & SupportsPreInitialize;

/**
 * Capability: adapter can select the small, JSON-safe subset of connection
 * options required to restore the same wallet account after a reload.
 */
export declare interface SupportsReconnectOptions {
    serializeReconnectOptions(options: ConnectOptions): ReconnectOptions | undefined;
}

export declare function supportsReconnectOptions(adapter: WalletAdapter): adapter is WalletAdapter & SupportsReconnectOptions;

/**
 * Time constants (in milliseconds)
 */
export declare const TIME: {
    /** Maximum age for stored wallet state before it's considered stale (7 days) */
    readonly STATE_MAX_AGE: number;
    /**
     * Maximum time an adapter's `isAvailable()` may take before it's treated as
     * unavailable, so one slow/hung wallet can't block the connect modal.
     */
    readonly AVAILABILITY_TIMEOUT: 1000;
};

/**
 * Timing constants (in milliseconds)
 */
export declare const TIMINGS: {
    readonly QR_RENDER_DELAY: 100;
    readonly QR_LOGO_TIMEOUT: 3000;
    readonly COPY_FEEDBACK_DURATION: 2000;
    readonly ANIMATION_DURATION: 200;
    readonly SAFARI_CONNECT_DELAY: 0;
    readonly NON_SAFARI_CONNECT_DELAY: 100;
};

/**
 * Transaction type (extends XRPL transaction)
 */
export declare type Transaction = SubmittableTransaction;

/**
 * Truncate string with ellipsis
 * @param str - String to truncate
 * @param maxLength - Maximum length before truncation
 * @returns Truncated string with '...'
 */
export declare function truncateString(str: string, maxLength: number): string;

/** CSS custom properties supported by the wallet connector and its portals. */
export declare const WALLET_CONNECTOR_CSS_VARIABLES: readonly ["--xc-font-family", "--xc-border-radius", "--xc-overlay-background", "--xc-overlay-backdrop-filter", "--xc-primary-color", "--xc-background-color", "--xc-text-color", "--xc-text-muted-color", "--xc-background-secondary", "--xc-background-tertiary", "--xc-loading-border-color", "--xc-connect-button-font-size", "--xc-connect-button-border-radius", "--xc-connect-button-color", "--xc-connect-button-background", "--xc-connect-button-border", "--xc-connect-button-hover-background", "--xc-connect-button-font-weight", "--xc-primary-button-color", "--xc-primary-button-background", "--xc-primary-button-border-radius", "--xc-primary-button-font-weight", "--xc-primary-button-hover-background", "--xc-secondary-button-color", "--xc-secondary-button-background", "--xc-secondary-button-border-radius", "--xc-secondary-button-font-weight", "--xc-secondary-button-hover-background", "--xc-account-address-button-hover-color", "--xc-modal-background", "--xc-modal-border-radius", "--xc-modal-box-shadow", "--xc-focus-color", "--xc-danger-color"];

/** Stable shadow parts grouped by the shadow host that exposes them. */
export declare const WALLET_CONNECTOR_PARTS: {
    readonly connector: {
        readonly connectButton: "connect-button";
    };
    readonly walletModal: {
        readonly overlay: "overlay";
        readonly modal: "modal";
        readonly closeButton: "close-button";
    };
    readonly accountModal: {
        readonly overlay: "overlay";
        readonly modal: "modal";
        readonly closeButton: "close-button";
        readonly addressButton: "account-address-button";
        readonly disconnectButton: "disconnect-button";
    };
};

/** Stable attributes used by the body-level modal portal hosts. */
export declare const WALLET_CONNECTOR_PORTAL_ATTRIBUTES: {
    readonly wallet: "data-xrpl-overlay-portal";
    readonly account: "data-xrpl-account-modal-portal";
};

/** Stable selectors for the body-level modal portal hosts. */
export declare const WALLET_CONNECTOR_PORTAL_SELECTORS: {
    readonly wallet: "[data-xrpl-overlay-portal]";
    readonly account: "[data-xrpl-account-modal-portal]";
};

/**
 * Core interface that all wallet adapters must implement
 */
export declare interface WalletAdapter {
    readonly id: WalletIdentifier;
    readonly name: string;
    readonly icon?: string;
    readonly url?: string;
    /**
     * Declared feature support. Optional — omitted flags use
     * {@link CAPABILITY_DEFAULTS}. Declare a capability as `false` for operations
     * the wallet can't perform (e.g. Xaman/WalletConnect message signing).
     */
    readonly capabilities?: WalletCapabilities;
    serializeReconnectOptions?(options: ConnectOptions): ReconnectOptions | undefined;
    getMissingConfiguration?(options?: ConnectOptions): readonly string[];
    isAvailable(): Promise<boolean>;
    connect(options?: ConnectOptions): Promise<AccountInfo>;
    disconnect(): Promise<void>;
    getAccount(): Promise<AccountInfo | null>;
    getNetwork(): Promise<NetworkInfo>;
    sign(transaction: Transaction): Promise<SignedTransaction>;
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    on?(event: WalletAdapterEvent, callback: (data: unknown) => void): void;
    off?(event: WalletAdapterEvent, callback: (data: unknown) => void): void;
}

/**
 * Events that adapters can emit
 */
export declare type WalletAdapterEvent = 'connect' | 'disconnect' | 'accountChanged' | 'networkChanged' | 'error';

/**
 * Declarative feature support for an adapter. Lets consumers and the manager
 * know ahead of time which optional operations a wallet can actually perform,
 * instead of discovering it only when a call fails at runtime.
 *
 * Every flag is optional; an omitted flag falls back to {@link CAPABILITY_DEFAULTS}
 * (the three signing operations default to `true` for backwards compatibility,
 * so existing adapters keep working without declaring anything).
 */
export declare interface WalletCapabilities {
    /** Can sign a transaction without submitting it (`sign`). Default: `true`. */
    sign?: boolean;
    /** Can sign and submit a transaction (`signAndSubmit`). Default: `true`. */
    signAndSubmit?: boolean;
    /** Can sign an arbitrary message (`signMessage`). Default: `true`. */
    signMessage?: boolean;
}

/**
 * WalletConnect adapter implementation using Sign Client v2
 */
export declare class WalletConnectAdapter implements WalletAdapter, SupportsPreInitialize, SupportsDeepLink {
    readonly id = "walletconnect";
    readonly name = "WalletConnect";
    readonly icon: string;
    readonly url = "https://walletconnect.com";
    readonly capabilities: WalletCapabilities;
    private client;
    private session;
    private currentAccount;
    private options;
    private initializationPromise;
    private initializationProjectId;
    private clientProjectId;
    private connectionAttemptGeneration;
    private pendingConnection;
    private activeConnectionProposals;
    private closedConnectionProposals;
    private modal;
    private eventListenerClient;
    private sessionDeleteHandler;
    private sessionExpireHandler;
    private sessionEventHandler;
    private sessionUpdateHandler;
    private listeners;
    constructor(options?: WalletConnectAdapterOptions);
    private composeQRCodeCallbacks;
    getMissingConfiguration(options?: ConnectOptions<WalletConnectConnectOptions>): readonly string[];
    private getOrInitializeClient;
    private closeConnectionProposal;
    private approveConnectionProposal;
    private waitForConnectionProposal;
    private createConnectionProposal;
    private closeActiveConnectionProposals;
    private releaseActiveConnectionProposal;
    /**
     * WalletConnect is always available (uses QR code)
     */
    isAvailable(): Promise<boolean>;
    /**
     * Initialize WalletConnect modal
     * This provides the official WalletConnect UI with 300+ wallets and automatic deeplinks
     */
    private initializeModal;
    /**
     * Pre-initialize WalletConnect by starting a connection session early
     * This generates the QR code URI before the user clicks WalletConnect
     * Based on ConnectKit's eager initialization pattern
     */
    preInitialize(network?: NetworkConfig, onQRCode?: (uri: string) => void): Promise<void>;
    /**
     * Connect to WalletConnect
     */
    connect(options?: ConnectOptions<WalletConnectConnectOptions>): Promise<AccountInfo>;
    /**
     * Disconnect from WalletConnect
     */
    disconnect(): Promise<void>;
    /**
     * Disconnect an approved session without allowing relay cleanup failures to
     * replace the connection result that caused the cleanup.
     */
    private disconnectSession;
    /**
     * Close a session that was approved but cannot be used by this connection
     * attempt. Cleanup must complete even if the remote disconnect already raced
     * with the wallet or relay.
     */
    private closeApprovedSession;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Get current network
     */
    getNetwork(): Promise<NetworkInfo>;
    on(event: WalletAdapterEvent, callback: AdapterEventListener): void;
    off(event: WalletAdapterEvent, callback: AdapterEventListener): void;
    /**
     * Send a WalletConnect sign transaction request
     */
    private requestSignTransaction;
    /**
     * Sign a transaction without submitting it to the ledger
     *
     * The wallet returns a signed `tx_json` (with `SigningPubKey` / `TxnSignature`
     * populated), not a serialized `tx_blob`. We surface that full `tx_json` (and
     * the raw signature under `signature`, per the `SignedTransaction` contract)
     * rather than mislabeling `TxnSignature` as `tx_blob` — the latter is not a
     * valid signed transaction blob and cannot be submitted as one.
     *
     * @param transaction - The transaction to sign
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger
     * @param transaction - The transaction to sign and submit
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message - NOT SUPPORTED
     * WalletConnect does not currently support message signing for XRPL
     */
    signMessage(_message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Setup event listeners for session
     */
    private setupEventListeners;
    private removeEventListeners;
    private handleSessionEvent;
    private handleSessionUpdate;
    private normalizeChangedChainId;
    private resolveChangedNetwork;
    private updateCurrentAccount;
    private assertSessionAuthorization;
    private failClosed;
    private emit;
    /**
     * Cleanup adapter state
     */
    private cleanup;
    private resolveRequestedNetwork;
    /**
     * Get deep link URI for mobile
     */
    getDeepLinkURI(uri: string): string;
}

/**
 * WalletConnect adapter options
 */
export declare interface WalletConnectAdapterOptions {
    projectId?: string;
    metadata?: SignClientTypes.Metadata;
    onQRCode?: (uri: string) => void;
    onDeepLink?: (uri: string) => string;
    useModal?: boolean;
    modalMode?: 'mobile-only' | 'always' | 'never';
    themeMode?: 'dark' | 'light';
}

export declare type WalletConnectConnectOptions = WalletConnectionOptionsById['walletconnect'];

/**
 * Adapter-specific connection options keyed by wallet ID. Third-party adapter
 * packages can extend this interface through module augmentation. Augment the
 * public module specifier being consumed: `@xrpl-connect/core` for the standalone
 * package or `xrpl-connect` for the rolled umbrella package. Custom IDs retain
 * an open options object without requiring augmentation.
 */
export declare interface WalletConnectionOptionsById {
    xaman: {
        apiKey?: string;
        onQRCode?: (uri: string) => void;
        onDeepLink?: (uri: string) => string;
        returnUrl?: {
            app?: string;
            web?: string;
        };
    };
    walletconnect: {
        projectId?: string;
        onQRCode?: (uri: string) => void;
    };
}

/** A CSS custom property supported by {@link WALLET_CONNECTOR_CSS_VARIABLES}. */
export declare type WalletConnectorCssVariable = (typeof WALLET_CONNECTOR_CSS_VARIABLES)[number];

/** Exact wallet connector CSS-variable overrides. */
export declare type WalletConnectorCssVars = Partial<Record<WalletConnectorCssVariable, string>>;

export declare let WalletConnectorElement: {
    new (): WalletConnectorElementInstance;
    readonly prototype: WalletConnectorElementInstance;
} | null;

/** Public API exposed by the `<xrpl-wallet-connector>` custom element. */
export declare interface WalletConnectorElementInstance extends HTMLElement {
    setWalletManager(manager: WalletManager): void;
    open(): Promise<void>;
    openAndWait(): Promise<AccountInfo>;
    close(): void;
    toggle(): void;
}

/**
 * Custom error class for wallet operations
 */
export declare class WalletError extends Error {
    readonly code: WalletErrorCode;
    readonly category: WalletErrorCategory;
    readonly originalError?: Error;
    static [Symbol.hasInstance](value: unknown): boolean;
    constructor(code: WalletErrorCode, message: string, originalError?: Error);
    /**
     * Convert to JSON representation
     */
    toJSON(): {
        name: string;
        code: WalletErrorCode;
        category: WalletErrorCategory;
        message: string;
        stack: string | undefined;
        originalError: {
            name: string;
            message: string;
            stack: string | undefined;
        } | undefined;
    };
}

/**
 * High-level categories for wallet errors.
 *
 * Each `WalletErrorCode` belongs to exactly one category, letting consumer apps
 * branch UX on the *kind* of failure without enumerating every code:
 *
 * - `USER_ACTION` — user explicitly rejected or cancelled. Usually no error toast.
 * - `WALLET_UNAVAILABLE` — provider missing, locked, or on the wrong network.
 *   Surface install / unlock / switch-network instructions.
 * - `NETWORK` — RPC or transport failure. Retry-friendly.
 * - `INVALID_INPUT` — programmer error (bad call, missing state). Bubble up.
 * - `INTERNAL` — unexpected failure that should be reported.
 */
export declare enum WalletErrorCategory {
    USER_ACTION = "USER_ACTION",
    WALLET_UNAVAILABLE = "WALLET_UNAVAILABLE",
    NETWORK = "NETWORK",
    INVALID_INPUT = "INVALID_INPUT",
    INTERNAL = "INTERNAL"
}

/**
 * Error codes for wallet operations
 */
export declare enum WalletErrorCode {
    WALLET_NOT_FOUND = "WALLET_NOT_FOUND",
    WALLET_NOT_INSTALLED = "WALLET_NOT_INSTALLED",
    WALLET_NOT_AVAILABLE = "WALLET_NOT_AVAILABLE",
    CONNECTION_FAILED = "CONNECTION_FAILED",
    CONNECTION_REJECTED = "CONNECTION_REJECTED",
    CONFIGURATION_REQUIRED = "CONFIGURATION_REQUIRED",
    SIGN_FAILED = "SIGN_FAILED",
    SIGN_REJECTED = "SIGN_REJECTED",
    NETWORK_NOT_SUPPORTED = "NETWORK_NOT_SUPPORTED",
    NETWORK_MISMATCH = "NETWORK_MISMATCH",
    NOT_CONNECTED = "NOT_CONNECTED",
    ALREADY_CONNECTED = "ALREADY_CONNECTED",
    UNSUPPORTED_METHOD = "UNSUPPORTED_METHOD",
    UNKNOWN_ERROR = "UNKNOWN_ERROR"
}

/**
 * Events emitted by WalletManager
 */
export declare type WalletEvent = 'connect' | 'disconnecting' | 'disconnect' | 'accountChanged' | 'networkChanged' | 'error';

/** Runtime ID of an adapter packaged by `xrpl-connect`. */
export declare type WalletId = (typeof STANDARD_WALLET_IDS)[number];

/** A packaged wallet ID or an application-defined custom adapter ID. */
export declare type WalletIdentifier = WalletId | (string & Record<never, never>);

/**
 * Main class for managing wallet connections
 */
export declare class WalletManager extends EventEmitter<WalletEvent> {
    adapters: Map<string, WalletAdapter>;
    private currentAdapter;
    private currentAccount;
    private connectingAdapter;
    private storage;
    private logger;
    private options;
    private adapterListeners;
    private sessionGeneration;
    private connectionAttemptGeneration;
    private reconnectGeneration;
    private pendingReconnects;
    private stateRevision;
    private storageTail;
    private adapterTeardowns;
    private disconnectOperations;
    constructor(options: WalletManagerOptions);
    /**
     * Restore stored state or complete a returned wallet authorization
     */
    private autoConnect;
    /**
     * Check if stored state is still valid (not too old)
     */
    private isStateValid;
    /**
     * Connect to a wallet
     */
    connect<const Wallet extends WalletIdentifier>(walletId: Wallet, options?: ConnectOptionsFor<Wallet>): Promise<AccountInfo>;
    private connectInternal;
    /**
     * Disconnect from current wallet
     */
    disconnect(): Promise<void>;
    private disconnectCurrentState;
    /** Start or join the teardown for the active adapter session. */
    private startDisconnect;
    /** Join every provider teardown that was active when disconnect was requested. */
    private awaitDisconnectOperations;
    private performDisconnect;
    /**
     * Restore a previous session or complete a returned wallet authorization
     */
    reconnect(): Promise<AccountInfo | null>;
    /**
     * Sign a transaction without submitting it to the ledger
     * @param transaction - The transaction to sign
     * @returns SignedTransaction with signed transaction JSON, a blob, and/or a signature
     */
    sign(transaction: Transaction): Promise<ManagedSignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger
     * @param transaction - The transaction to sign and submit
     * @returns SubmittedTransaction with hash from ledger confirmation
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message
     */
    signMessage(message: string | Uint8Array): Promise<ManagedSignedMessage>;
    /**
     * Get registered wallets whose availability check succeeds within the
     * configured availability timeout.
     */
    getAvailableWallets(): Promise<WalletAdapter[]>;
    /**
     * Whether the connected wallet (or a given adapter) supports a capability.
     * Returns `false` when no wallet is connected and no adapter is passed.
     *
     * Lets callers hide/disable UI for operations a wallet can't perform (e.g.
     * a "Sign message" button for Xaman/WalletConnect) instead of letting the
     * call fail at runtime.
     */
    supports(capability: keyof WalletCapabilities, adapter?: WalletAdapter | null): boolean;
    /**
     * Query the connected adapter and refresh cached account information, emitting
     * account/network change events for differences. Freshness is adapter-specific:
     * Xaman queries its OAuth subject and retains the session network context.
     * Success does not universally verify the wallet's current network selection.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    /**
     * Get current connection state
     */
    get connected(): boolean;
    /**
     * Get current account
     */
    get account(): AccountInfo | null;
    /**
     * Get current wallet adapter
     */
    get wallet(): WalletAdapter | null;
    /** The adapter whose connection attempt currently owns the manager, if any. */
    get connectingWallet(): WalletAdapter | null;
    /**
     * Get all registered adapters
     */
    get wallets(): WalletAdapter[];
    /**
     * Default network configured on the manager, if any.
     */
    get defaultNetwork(): NetworkConfig | undefined;
    /**
     * Throw a typed `UNSUPPORTED_METHOD` error if the connected wallet declares
     * it can't perform the given capability.
     */
    private assertSupports;
    /**
     * Handle adapter disconnect event
     */
    private handleAdapterDisconnect;
    /**
     * Handle account changed event
     */
    private handleAccountChanged;
    /**
     * Handle network changed event
     */
    private handleNetworkChanged;
    /** Serialize storage mutations so cleanup is always the final old-session write. */
    private queueStorage;
    /** Deduplicate provider teardown and block reuse of the same adapter until it settles. */
    private teardownAdapter;
    /** Persist an immutable session snapshot without restoring stale state. */
    private persistState;
    private isActiveSession;
    private cloneAccount;
    private networksEqual;
    /**
     * Register adapter listeners and remember them so we can detach later.
     */
    private subscribeToAdapter;
    /**
     * Detach every listener registered via subscribeToAdapter.
     */
    private unsubscribeFromAdapter;
    /**
     * Cleanup connection state
     */
    private cleanup;
}

/**
 * Wallet manager configuration options
 */
export declare interface WalletManagerOptions {
    adapters: WalletAdapter[];
    network?: NetworkConfig;
    autoConnect?: boolean;
    storage?: StorageAdapter;
    logger?: LoggerOptions | LoggerInstance;
}

declare type WalletSpecificConnectOptions<Wallet extends WalletIdentifier> = Wallet extends keyof WalletConnectionOptionsById ? WalletConnectionOptionsById[Wallet] extends object ? WalletConnectionOptionsById[Wallet] : never : Record<string, unknown>;

/**
 * Async utilities shared across the toolkit.
 */
/**
 * Race a promise against a timeout, resolving to `fallback` if it doesn't
 * settle within `ms` — and also if it rejects.
 *
 * This never rejects: it exists so that a single slow or hung wallet adapter
 * (e.g. an `isAvailable()` that performs a network probe on a flaky mobile
 * connection) cannot block availability checks for every other wallet. A
 * `Promise.all` over unbounded `isAvailable()` calls waits for the slowest
 * one; wrapping each call here caps that wait.
 *
 * @param operation - Function that starts the promise to bound. Synchronous
 * throws are treated like rejected promises.
 * @param ms - Maximum time to wait, in milliseconds.
 * @param fallback - Value to resolve with on timeout or rejection.
 */
export declare function withTimeout<T>(operation: () => Promise<T>, ms: number, fallback: T): Promise<T>;

/**
 * Xaman specific constants
 */
export declare const XAMAN: {
    readonly QR_URL_PATTERN: "xumm.app/sign";
    readonly QR_IMAGE_EXTENSION: ".png";
};

/**
 * Xaman wallet adapter implementation
 */
export declare class XamanAdapter implements WalletAdapter, SupportsDeepLink, SupportsFetchAccount, SupportsPendingConnection {
    readonly id = "xaman";
    readonly name = "Xaman";
    readonly icon: string;
    readonly url = "https://xaman.app";
    readonly capabilities: WalletCapabilities;
    private client;
    private clientApiKey;
    private sdkApiKey;
    private currentAccount;
    private options;
    private readonly maxLastLedgerSequenceExtension;
    private activePayloadOperations;
    private connectionGeneration;
    private supersededRestorationGeneration;
    private accountRefreshRevision;
    private connecting;
    private restoringState;
    private disconnecting;
    private connectionAttemptDone;
    private disconnectPromise;
    private activeCallbacks;
    constructor(options?: XamanAdapterOptions);
    getMissingConfiguration(options?: ConnectOptions<XamanConnectOptions>): readonly string[];
    /**
     * Xaman is always available (uses OAuth flow, no extension needed)
     */
    isAvailable(): Promise<boolean>;
    hasPendingConnection(): boolean;
    checkXamanState(options?: ConnectOptions<XamanConnectOptions>): Promise<AccountInfo | null>;
    /**
     * Connect to Xaman wallet
     */
    connect(options?: ConnectOptions<XamanConnectOptions>): Promise<AccountInfo>;
    /**
     * Disconnect from Xaman
     */
    disconnect(): Promise<void>;
    /**
     * Get current account
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Refresh the OAuth session subject, retaining its established network context.
     * Ping does not report the mobile app's current account/network selection.
     */
    fetchAccount(): Promise<AccountInfo | null>;
    /**
     * Get the session network context, not the mobile app's current selection.
     */
    getNetwork(): Promise<NetworkInfo>;
    /**
     * Create a Xaman payload, open the signing popup, wait for Xaman's SDK subscription,
     * then fetch and validate the authoritative resolved payload.
     *
     * `submit` is passed through as `options.submit` on the payload body — Xaman's
     * payload API only submits to the ledger when this is true. Previously the bare
     * transaction was sent with no `options`, so `sign()` could submit despite being
     * the sign-only operation.
     *
     * Subscription events only contain status metadata, never the signed blob. The
     * actual signed data and dispatch result come from `payload.get()`.
     */
    private createAndWaitForPayload;
    /**
     * Sign a transaction without submitting it to the ledger.
     * Note: Xaman uses a popup flow for signing.
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger.
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign a message - NOT SUPPORTED
     * Xaman SignIn payloads prove account ownership but do not sign arbitrary messages.
     */
    signMessage(_message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Parse network from endpoint URL
     */
    private parseNetwork;
    private resolveRequestedNetwork;
    private getSessionNetwork;
    /**
     * Open popup window for signing or trigger QR code callback
     */
    private openSignWindow;
    /**
     * Get deep link URI for mobile (Xaman app)
     */
    getDeepLinkURI(url: string): string;
    private resolveXamanNetwork;
    private validateXamanNetwork;
    private validateSignedTransaction;
    private validateRequestedTransaction;
    private containsRequestedValue;
    private containsRequestedSigners;
    private createPayloadOperation;
    private quiescePayloadOperation;
    private waitForOperation;
    private getResolvedPayload;
    private waitForOperationUntil;
    private waitForPayloadOutcome;
    /**
     * Cleanup adapter state
     */
    private cleanup;
}

export declare interface XamanAdapterOptions {
    apiKey?: string;
    onQRCode?: (uri: string) => void;
    onDeepLink?: (uri: string) => string;
    /** Optional navigation destinations offered after a signing request is resolved */
    returnUrl?: XamanReturnUrl;
    /**
     * Maximum increase to a supplied absolute LastLedgerSequence in sign() results.
     * Defaults to 50 ledgers; 0 requires exact matching. Does not apply to
     * signAndSubmit(), multisigning, Batch, or wallet-chosen (omitted) expiry.
     */
    maxLastLedgerSequenceExtension?: number;
}

export declare type XamanConnectOptions = WalletConnectionOptionsById['xaman'];

export { XamanOAuth2 }

/**
 * Xaman adapter options
 */
export declare interface XamanReturnUrl {
    /** URL or registered deep link opened by the Xaman app after signing */
    app?: string;
    /** URL opened by Xaman's browser flow after signing */
    web?: string;
}

export { XamanSDK }

/**
 * Network mapping between xrpl-connect network IDs and Xyra SDK network strings.
 *
 * xrpl-connect uses: 'mainnet', 'testnet' (Xyra does not support devnet)
 * Xyra SDK uses: 'xrpl-mainnet', 'xrpl-testnet'
 *
 */
export declare const XRPL_CONNECT_TO_XYRA_NETWORK: Record<XyraSupportedNetworkId, Network>;

/**
 * XRPL methods supported by WalletConnect
 */
export declare enum XRPLMethod {
    SIGN_TRANSACTION = "xrpl_signTransaction",
    SIGN_TRANSACTION_FOR = "xrpl_signTransactionFor"
}

/**
 * Reverse mapping: Xyra SDK network → xrpl-connect network ID
 */
export declare const XYRA_TO_XRPL_CONNECT_NETWORK: Partial<Record<Network, XyraSupportedNetworkId>>;

/**
 * Xyra adapter implementation for XRPL Connect.
 *
 * Xyra is a browser-native wallet for XRPL mainnet and testnet.
 * It uses popup-based signing flows where cryptographic seeds never
 * leave the user's browser. No extensions or app installs are required.
 *
 * @example
 * ```typescript
 * import { WalletManager } from '@xrpl-connect/core';
 * import { XyraAdapter } from '@xrpl-connect/adapter-xyra';
 *
 * const walletManager = new WalletManager({
 *   adapters: [new XyraAdapter()],
 *   network: 'testnet',
 * });
 *
 * const account = await walletManager.connect('xyra');
 * console.log('Connected:', account.address);
 * ```
 */
export declare class XyraAdapter implements WalletAdapter {
    readonly id = "xyra";
    readonly name = "Xyra";
    readonly icon: string;
    readonly url = "https://xyra.now";
    private sdk;
    private sdkPromise;
    private readonly sdkConfig;
    private currentAccount;
    private currentXyraNetwork;
    private connectionGeneration;
    private listeners;
    constructor(options?: XyraAdapterOptions);
    /**
     * Xyra is always available — it's a web-based wallet that doesn't
     * require any browser extension or native app to be installed.
     * It opens in a popup window on demand.
     */
    isAvailable(): Promise<boolean>;
    /**
     * Connect to Xyra wallet.
     *
     * Opens a popup window where the user selects an account and
     * approves the connection. The requesting origin is displayed
     * prominently so the user can verify the source.
     *
     * @param options - Connection options (network config, auto-reconnect, etc.)
     * @returns Account info with address, public key, and network
     */
    connect(options?: ConnectOptions<XyraConnectOptions>): Promise<AccountInfo>;
    /**
     * Disconnect from Xyra wallet.
     *
     * Clears the local connection state. Xyra is stateless (no persistent
     * sessions), so there is no server-side session to terminate.
     */
    disconnect(): Promise<void>;
    /**
     * Get the currently connected account information.
     */
    getAccount(): Promise<AccountInfo | null>;
    /**
     * Get the current network information.
     *
     * Returns the network the user connected with.
     */
    getNetwork(): Promise<NetworkInfo>;
    /**
     * Sign a transaction without submitting it to the ledger.
     *
     * Opens a popup window showing the full transaction details
     * and the requesting origin. The user must explicitly approve
     * the transaction before it is signed.
     *
     * @param transaction - The XRPL transaction object
     * @returns The signed transaction with tx_blob
     */
    sign(transaction: Transaction): Promise<SignedTransaction>;
    /**
     * Sign and submit a transaction to the ledger.
     *
     * Opens a popup window showing the full transaction details
     * and the requesting origin. The user must explicitly approve
     * the transaction before it is signed and submitted.
     *
     * @param transaction - The XRPL transaction object
     * @returns The submitted transaction result
     */
    signAndSubmit(transaction: Transaction): Promise<SubmittedTransaction>;
    /**
     * Sign an arbitrary message for authentication or proof of ownership.
     *
     * Opens a popup showing the message to be signed. The user must
     * approve before the message is signed with their private key.
     *
     * @param message - The message to sign (string or Uint8Array)
     * @returns The signed message with signature and public key
     */
    signMessage(message: string | Uint8Array): Promise<SignedMessage>;
    /**
     * Register an event listener.
     */
    on(event: WalletAdapterEvent, callback: (data?: unknown) => void): void;
    /**
     * Remove an event listener.
     */
    off(event: WalletAdapterEvent, callback: (data?: unknown) => void): void;
    /**
     * Destroy the adapter and clean up SDK resources.
     */
    destroy(): void;
    private getSdk;
    /**
     * Emit an event to registered listeners.
     */
    private emit;
    /**
     * Resolve an xrpl-connect NetworkConfig to a Xyra SDK Network string.
     *
     * Xyra has no devnet or custom-network support. When omitted, this adapter
     * deliberately asks the SDK for testnet; the SDK response is still checked
     * below and remains authoritative for all subsequent signing operations.
     */
    private resolveXyraNetwork;
    /**
     * Map a Xyra SDK Network string back to an xrpl-connect NetworkInfo.
     *
     * This is not the same as the shared `resolveNetwork` helper from
     * `@xrpl-connect/core`: that helper resolves a user-supplied
     * `ConnectOptions['network']` (string id or `NetworkInfo`) to a
     * `NetworkInfo`, whereas this method translates a Xyra-SDK-native
     * network identifier returned by the wallet itself.
     */
    private xyraNetworkToInfo;
    /**
     * Map Xyra SDK errors to xrpl-connect WalletError instances.
     */
    private mapError;
}

/**
 * Xyra adapter constructor options
 */
export declare interface XyraAdapterOptions {
    /**
     * Custom wallet URL (defaults to 'https://wallet.xyra.now')
     * Useful for development or self-hosted instances.
     */
    walletUrl?: string;
    /**
     * Timeout for popup operations in milliseconds (default: 300000 / 5 minutes)
     */
    timeout?: number;
    /**
     * Custom popup width (default: 420)
     */
    popupWidth?: number;
    /**
     * Custom popup height for connect flow (default: 720)
     */
    popupHeight?: number;
    /**
     * Custom popup height for sign flow (default: 640)
     */
    signPopupHeight?: number;
}

/**
 * Xyra-specific connect options passed through WalletManager.connect()
 */
export declare type XyraConnectOptions = {
    /**
     * Override wallet URL for this connection
     */
    walletUrl?: string;
    /**
     * Override timeout for this connection
     */
    timeout?: number;
};

/** Networks supported by the Xyra SDK integration. */
declare type XyraSupportedNetworkId = Extract<StandardNetworkId, 'mainnet' | 'testnet'>;

/**
 * Z-Index layers
 */
export declare const Z_INDEX: {
    readonly OVERLAY: 9999;
    readonly LOADING_BORDER_AFTER: 1;
    readonly LOADING_LOGO: 2;
};

export { }

declare global {
    interface HTMLElementTagNameMap {
        'xrpl-wallet-connector': WalletConnectorElementInstance;
    }
}
