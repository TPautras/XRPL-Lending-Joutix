//#region ../../node_modules/.pnpm/@xyrawallet+sdk@0.1.4/node_modules/@xyrawallet/sdk/dist/index.mjs
var e = "https://wallet.xyra.now", t = {
	resizable: "yes",
	scrollbars: "yes",
	status: "no",
	toolbar: "no",
	menubar: "no",
	location: "no"
}, n = {
	CONNECT_RESPONSE: "CONNECT_RESPONSE",
	SIGN_RESPONSE: "SIGN_RESPONSE",
	SIGN_MESSAGE_RESPONSE: "SIGN_MESSAGE_RESPONSE"
}, r = class extends Error {
	constructor(e, t) {
		super(e), this.code = t, this.name = "XyraError";
	}
}, i = class extends r {
	constructor() {
		super("Popup was blocked by the browser. Please allow popups for this site.", "POPUP_BLOCKED"), this.name = "PopupBlockedError";
	}
}, a = class extends r {
	constructor() {
		super("User closed the popup before completing the action.", "POPUP_CLOSED"), this.name = "PopupClosedError";
	}
}, o = class extends r {
	constructor() {
		super("Request timed out. Please try again.", "TIMEOUT"), this.name = "TimeoutError";
	}
}, s = class extends r {
	constructor(e) {
		super(`Invalid network: ${e}`, "INVALID_NETWORK"), this.name = "InvalidNetworkError";
	}
}, c = class {
	constructor() {
		this.popup = null, this.checkInterval = null;
	}
	open(e, t, n = {}) {
		let r = n.width || 420, a = n.height || 720, o = this.buildFeatures(r, a, n.centered);
		if (this.popup = window.open(e, t, o), !this.popup) throw new i();
		return this.popup;
	}
	isOpen() {
		return this.popup !== null && !this.popup.closed;
	}
	close() {
		this.popup && !this.popup.closed && this.popup.close(), this.popup = null;
	}
	focus() {
		this.isOpen() && this.popup && this.popup.focus();
	}
	onClose(e) {
		this.stopMonitoring(), this.checkInterval = setInterval(() => {
			this.isOpen() || (this.stopMonitoring(), e());
		}, 500);
	}
	stopMonitoring() {
		this.checkInterval &&= (clearInterval(this.checkInterval), null);
	}
	buildFeatures(e, n, r = !0) {
		let i = Object.entries(t).map(([e, t]) => `${e}=${t}`).join(",");
		if (i += `,width=${e},height=${n}`, r) {
			let t = Math.round((window.screen.width - e) / 2), r = Math.round((window.screen.height - n) / 2);
			i += `,left=${t},top=${r}`;
		}
		return i;
	}
	destroy() {
		this.stopMonitoring(), this.close();
	}
}, l = class {
	constructor(t = e) {
		this.listeners = /* @__PURE__ */ new Map(), this.boundHandler = null, this.walletOrigin = new URL(t).origin;
	}
	startListening() {
		this.boundHandler || (this.boundHandler = this.handleMessage.bind(this), window.addEventListener("message", this.boundHandler));
	}
	stopListening() {
		this.boundHandler &&= (window.removeEventListener("message", this.boundHandler), null);
	}
	on(e, t) {
		this.listeners.has(e) || this.listeners.set(e, []), this.listeners.get(e).push(t);
	}
	off(e, t) {
		let n = this.listeners.get(e);
		if (n) {
			let e = n.indexOf(t);
			e > -1 && n.splice(e, 1);
		}
	}
	offAll(e) {
		this.listeners.delete(e);
	}
	handleMessage(e) {
		if (e.origin !== this.walletOrigin) return;
		let { type: t, ...n } = e.data || {};
		if (!t) return;
		let r = this.listeners.get(t);
		r && r.forEach((e) => e(n));
	}
	waitForMessage(e, t = 3e5) {
		return new Promise((n, r) => {
			let i = setTimeout(() => {
				this.off(e, a), r(/* @__PURE__ */ Error(`Timeout waiting for message: ${e}`));
			}, t), a = (t) => {
				clearTimeout(i), this.off(e, a), n(t);
			};
			this.on(e, a);
		});
	}
	destroy() {
		this.stopListening(), this.listeners.clear();
	}
};
async function u(e, t, r, i, s) {
	let { network: c, onProgress: l } = t;
	l?.("Opening wallet...");
	let u = `${e}/connect?network=${encodeURIComponent(c)}`;
	r.open(u, "xyra_connect", {
		height: 720,
		centered: !0
	}), l?.("Waiting for user approval...");
	let d = new Promise((e, t) => {
		r.onClose(() => {
			t(new a());
		});
	}), f = new Promise((e, t) => {
		setTimeout(() => t(new o()), s);
	}), p = i.waitForMessage(n.CONNECT_RESPONSE, s);
	try {
		let e = await Promise.race([
			p,
			d,
			f
		]);
		return l?.("Connected!"), r.close(), e;
	} catch (e) {
		throw r.close(), e;
	}
}
async function d(e, t, r, i, s) {
	let { transaction: c, network: l, submit: u = !1, onProgress: d } = t;
	d?.("Preparing transaction...");
	let f = btoa(JSON.stringify(c)), p = `${e}/sign?tx=${encodeURIComponent(f)}&network=${encodeURIComponent(l)}` + (u ? "&submit=true" : "");
	d?.("Opening wallet...");
	let m = r.open(p, "xyra_sign", {
		height: 640,
		centered: !0
	});
	u && setTimeout(() => {
		m.postMessage({
			type: "SIGN",
			network: l,
			tx: f,
			submit: !0
		}, new URL(e).origin);
	}, 500), d?.("Waiting for signature...");
	let h = new Promise((e, t) => {
		r.onClose(() => {
			t(new a());
		});
	}), g = new Promise((e, t) => {
		setTimeout(() => t(new o()), s);
	}), _ = i.waitForMessage(n.SIGN_RESPONSE, s);
	try {
		let e = await Promise.race([
			_,
			h,
			g
		]);
		return d?.(e.submitted ? "Transaction submitted!" : "Transaction signed!"), r.close(), e;
	} catch (e) {
		throw r.close(), e;
	}
}
async function f(e, t, r, i, s) {
	let { message: c, onProgress: l } = t;
	l?.("Preparing message...");
	let u = btoa(c), d = `${e}/sign-message?msg=${encodeURIComponent(u)}`;
	l?.("Opening wallet..."), r.open(d, "xyra_sign_message", {
		height: 640,
		centered: !0
	}), l?.("Waiting for signature...");
	let f = new Promise((e, t) => {
		r.onClose(() => {
			t(new a());
		});
	}), p = new Promise((e, t) => {
		setTimeout(() => t(new o()), s);
	}), m = i.waitForMessage(n.SIGN_MESSAGE_RESPONSE, s);
	try {
		let e = await Promise.race([
			m,
			f,
			p
		]);
		return l?.("Message signed!"), r.close(), e;
	} catch (e) {
		throw r.close(), e;
	}
}
var p = class {
	constructor(t = {}) {
		this.config = {
			walletUrl: t.walletUrl || e,
			popupWidth: t.popupWidth || 420,
			popupHeight: t.popupHeight || 720,
			signPopupHeight: t.signPopupHeight || 640,
			timeout: t.timeout || 3e5
		}, this.popupManager = new c(), this.messageManager = new l(this.config.walletUrl), this.messageManager.startListening();
	}
	async connect(e) {
		return this.validateNetwork(e.network), u(this.config.walletUrl, e, this.popupManager, this.messageManager, this.config.timeout);
	}
	async sign(e) {
		return this.validateNetwork(e.network), d(this.config.walletUrl, {
			...e,
			submit: !1
		}, this.popupManager, this.messageManager, this.config.timeout);
	}
	async signAndSubmit(e) {
		return this.validateNetwork(e.network), d(this.config.walletUrl, {
			...e,
			submit: !0
		}, this.popupManager, this.messageManager, this.config.timeout);
	}
	async signMessage(e) {
		return f(this.config.walletUrl, e, this.popupManager, this.messageManager, this.config.timeout);
	}
	validateNetwork(e) {
		if (![
			"xrpl-mainnet",
			"xrpl-testnet",
			"xahau-mainnet",
			"xahau-testnet"
		].includes(e)) throw new s(e);
	}
	destroy() {
		this.popupManager.destroy(), this.messageManager.destroy();
	}
};
new p();
//#endregion
export { p as XyraSDK };
