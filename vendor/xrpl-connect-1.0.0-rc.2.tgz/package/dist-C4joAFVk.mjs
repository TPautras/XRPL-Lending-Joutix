import { _ as e, a as t, c as n, d as r, i, l as a, n as o, o as s, r as c, s as l, t as u } from "./dist-CphEjI_t.mjs";
//#region ../../node_modules/.pnpm/@lit+reactive-element@1.6.3/node_modules/@lit/reactive-element/css-tag.js
var d = window, f = d.ShadowRoot && (d.ShadyCSS === void 0 || d.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, p = Symbol(), m = /* @__PURE__ */ new WeakMap(), h = class {
	constructor(e, t, n) {
		if (this._$cssResult$ = !0, n !== p) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
		this.cssText = e, this.t = t;
	}
	get styleSheet() {
		let e = this.o, t = this.t;
		if (f && e === void 0) {
			let n = t !== void 0 && t.length === 1;
			n && (e = m.get(t)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), n && m.set(t, e));
		}
		return e;
	}
	toString() {
		return this.cssText;
	}
}, g = (e) => new h(typeof e == "string" ? e : e + "", void 0, p), _ = (e, ...t) => new h(e.length === 1 ? e[0] : t.reduce(((t, n, r) => t + ((e) => {
	if (!0 === e._$cssResult$) return e.cssText;
	if (typeof e == "number") return e;
	throw Error("Value passed to 'css' function must be a 'css' function result: " + e + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
})(n) + e[r + 1]), e[0]), e, p), v = (e, t) => {
	f ? e.adoptedStyleSheets = t.map(((e) => e instanceof CSSStyleSheet ? e : e.styleSheet)) : t.forEach(((t) => {
		let n = document.createElement("style"), r = d.litNonce;
		r !== void 0 && n.setAttribute("nonce", r), n.textContent = t.cssText, e.appendChild(n);
	}));
}, y = f ? (e) => e : (e) => e instanceof CSSStyleSheet ? ((e) => {
	let t = "";
	for (let n of e.cssRules) t += n.cssText;
	return g(t);
})(e) : e, b = window, x = b.trustedTypes, S = x ? x.emptyScript : "", C = b.reactiveElementPolyfillSupport, w = {
	toAttribute(e, t) {
		switch (t) {
			case Boolean:
				e = e ? S : null;
				break;
			case Object:
			case Array: e = e == null ? e : JSON.stringify(e);
		}
		return e;
	},
	fromAttribute(e, t) {
		let n = e;
		switch (t) {
			case Boolean:
				n = e !== null;
				break;
			case Number:
				n = e === null ? null : Number(e);
				break;
			case Object:
			case Array: try {
				n = JSON.parse(e);
			} catch {
				n = null;
			}
		}
		return n;
	}
}, ee = (e, t) => t !== e && (t == t || e == e), te = {
	attribute: !0,
	type: String,
	converter: w,
	reflect: !1,
	hasChanged: ee
}, ne = "finalized", re = class extends HTMLElement {
	constructor() {
		super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = !1, this.hasUpdated = !1, this._$El = null, this._$Eu();
	}
	static addInitializer(e) {
		this.finalize(), (this.h ??= []).push(e);
	}
	static get observedAttributes() {
		this.finalize();
		let e = [];
		return this.elementProperties.forEach(((t, n) => {
			let r = this._$Ep(n, t);
			r !== void 0 && (this._$Ev.set(r, n), e.push(r));
		})), e;
	}
	static createProperty(e, t = te) {
		if (t.state && (t.attribute = !1), this.finalize(), this.elementProperties.set(e, t), !t.noAccessor && !this.prototype.hasOwnProperty(e)) {
			let n = typeof e == "symbol" ? Symbol() : "__" + e, r = this.getPropertyDescriptor(e, n, t);
			r !== void 0 && Object.defineProperty(this.prototype, e, r);
		}
	}
	static getPropertyDescriptor(e, t, n) {
		return {
			get() {
				return this[t];
			},
			set(r) {
				let i = this[e];
				this[t] = r, this.requestUpdate(e, i, n);
			},
			configurable: !0,
			enumerable: !0
		};
	}
	static getPropertyOptions(e) {
		return this.elementProperties.get(e) || te;
	}
	static finalize() {
		if (this.hasOwnProperty(ne)) return !1;
		this[ne] = !0;
		let e = Object.getPrototypeOf(this);
		if (e.finalize(), e.h !== void 0 && (this.h = [...e.h]), this.elementProperties = new Map(e.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
			let e = this.properties, t = [...Object.getOwnPropertyNames(e), ...Object.getOwnPropertySymbols(e)];
			for (let n of t) this.createProperty(n, e[n]);
		}
		return this.elementStyles = this.finalizeStyles(this.styles), !0;
	}
	static finalizeStyles(e) {
		let t = [];
		if (Array.isArray(e)) {
			let n = new Set(e.flat(Infinity).reverse());
			for (let e of n) t.unshift(y(e));
		} else e !== void 0 && t.push(y(e));
		return t;
	}
	static _$Ep(e, t) {
		let n = t.attribute;
		return !1 === n ? void 0 : typeof n == "string" ? n : typeof e == "string" ? e.toLowerCase() : void 0;
	}
	_$Eu() {
		var e;
		this._$E_ = new Promise(((e) => this.enableUpdating = e)), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), (e = this.constructor.h) == null || e.forEach(((e) => e(this)));
	}
	addController(e) {
		var t;
		(this._$ES ??= []).push(e), this.renderRoot !== void 0 && this.isConnected && ((t = e.hostConnected) == null || t.call(e));
	}
	removeController(e) {
		var t;
		(t = this._$ES) == null || t.splice(this._$ES.indexOf(e) >>> 0, 1);
	}
	_$Eg() {
		this.constructor.elementProperties.forEach(((e, t) => {
			this.hasOwnProperty(t) && (this._$Ei.set(t, this[t]), delete this[t]);
		}));
	}
	createRenderRoot() {
		let e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
		return v(e, this.constructor.elementStyles), e;
	}
	connectedCallback() {
		var e;
		this.renderRoot === void 0 && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (e = this._$ES) == null || e.forEach(((e) => e.hostConnected?.call(e)));
	}
	enableUpdating(e) {}
	disconnectedCallback() {
		var e;
		(e = this._$ES) == null || e.forEach(((e) => e.hostDisconnected?.call(e)));
	}
	attributeChangedCallback(e, t, n) {
		this._$AK(e, n);
	}
	_$EO(e, t, n = te) {
		let r = this.constructor._$Ep(e, n);
		if (r !== void 0 && !0 === n.reflect) {
			let i = (n.converter?.toAttribute === void 0 ? w : n.converter).toAttribute(t, n.type);
			this._$El = e, i == null ? this.removeAttribute(r) : this.setAttribute(r, i), this._$El = null;
		}
	}
	_$AK(e, t) {
		let n = this.constructor, r = n._$Ev.get(e);
		if (r !== void 0 && this._$El !== r) {
			let e = n.getPropertyOptions(r), i = typeof e.converter == "function" ? { fromAttribute: e.converter } : e.converter?.fromAttribute === void 0 ? w : e.converter;
			this._$El = r, this[r] = i.fromAttribute(t, e.type), this._$El = null;
		}
	}
	requestUpdate(e, t, n) {
		let r = !0;
		e !== void 0 && (((n ||= this.constructor.getPropertyOptions(e)).hasChanged || ee)(this[e], t) ? (this._$AL.has(e) || this._$AL.set(e, t), !0 === n.reflect && this._$El !== e && (this._$EC === void 0 && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(e, n))) : r = !1), !this.isUpdatePending && r && (this._$E_ = this._$Ej());
	}
	async _$Ej() {
		this.isUpdatePending = !0;
		try {
			await this._$E_;
		} catch (e) {
			Promise.reject(e);
		}
		let e = this.scheduleUpdate();
		return e != null && await e, !this.isUpdatePending;
	}
	scheduleUpdate() {
		return this.performUpdate();
	}
	performUpdate() {
		var e;
		if (!this.isUpdatePending) return;
		this.hasUpdated, this._$Ei &&= (this._$Ei.forEach(((e, t) => this[t] = e)), void 0);
		let t = !1, n = this._$AL;
		try {
			t = this.shouldUpdate(n), t ? (this.willUpdate(n), (e = this._$ES) == null || e.forEach(((e) => e.hostUpdate?.call(e))), this.update(n)) : this._$Ek();
		} catch (e) {
			throw t = !1, this._$Ek(), e;
		}
		t && this._$AE(n);
	}
	willUpdate(e) {}
	_$AE(e) {
		var t;
		(t = this._$ES) == null || t.forEach(((e) => e.hostUpdated?.call(e))), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
	}
	_$Ek() {
		this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
	}
	get updateComplete() {
		return this.getUpdateComplete();
	}
	getUpdateComplete() {
		return this._$E_;
	}
	shouldUpdate(e) {
		return !0;
	}
	update(e) {
		this._$EC !== void 0 && (this._$EC.forEach(((e, t) => this._$EO(t, this[t], e))), this._$EC = void 0), this._$Ek();
	}
	updated(e) {}
	firstUpdated(e) {}
};
re[ne] = !0, re.elementProperties = /* @__PURE__ */ new Map(), re.elementStyles = [], re.shadowRootOptions = { mode: "open" }, C?.({ ReactiveElement: re }), (b.reactiveElementVersions ??= []).push("1.6.3");
//#endregion
//#region ../../node_modules/.pnpm/lit-html@2.8.0/node_modules/lit-html/lit-html.js
var ie = window, ae = ie.trustedTypes, oe = ae ? ae.createPolicy("lit-html", { createHTML: (e) => e }) : void 0, se = "$lit$", T = `lit$${(Math.random() + "").slice(9)}$`, ce = "?" + T, le = `<${ce}>`, E = document, ue = () => E.createComment(""), de = (e) => e === null || typeof e != "object" && typeof e != "function", fe = Array.isArray, pe = (e) => fe(e) || typeof e?.[Symbol.iterator] == "function", me = "[ 	\n\f\r]", he = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ge = /-->/g, _e = />/g, D = RegExp(`>|${me}(?:([^\\s"'>=/]+)(${me}*=${me}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`, "g"), ve = /'/g, ye = /"/g, be = /^(?:script|style|textarea|title)$/i, xe = (e) => (t, ...n) => ({
	_$litType$: e,
	strings: t,
	values: n
}), O = xe(1), k = xe(2), A = Symbol.for("lit-noChange"), j = Symbol.for("lit-nothing"), Se = /* @__PURE__ */ new WeakMap(), M = E.createTreeWalker(E, 129, null, !1);
function Ce(e, t) {
	if (!Array.isArray(e) || !e.hasOwnProperty("raw")) throw Error("invalid template strings array");
	return oe === void 0 ? t : oe.createHTML(t);
}
var we = (e, t) => {
	let n = e.length - 1, r = [], i, a = t === 2 ? "<svg>" : "", o = he;
	for (let t = 0; t < n; t++) {
		let n = e[t], s, c, l = -1, u = 0;
		for (; u < n.length && (o.lastIndex = u, c = o.exec(n), c !== null);) u = o.lastIndex, o === he ? c[1] === "!--" ? o = ge : c[1] === void 0 ? c[2] === void 0 ? c[3] !== void 0 && (o = D) : (be.test(c[2]) && (i = RegExp("</" + c[2], "g")), o = D) : o = _e : o === D ? c[0] === ">" ? (o = i ?? he, l = -1) : c[1] === void 0 ? l = -2 : (l = o.lastIndex - c[2].length, s = c[1], o = c[3] === void 0 ? D : c[3] === "\"" ? ye : ve) : o === ye || o === ve ? o = D : o === ge || o === _e ? o = he : (o = D, i = void 0);
		let d = o === D && e[t + 1].startsWith("/>") ? " " : "";
		a += o === he ? n + le : l >= 0 ? (r.push(s), n.slice(0, l) + se + n.slice(l) + T + d) : n + T + (l === -2 ? (r.push(void 0), t) : d);
	}
	return [Ce(e, a + (e[n] || "<?>") + (t === 2 ? "</svg>" : "")), r];
}, Te = class e {
	constructor({ strings: t, _$litType$: n }, r) {
		let i;
		this.parts = [];
		let a = 0, o = 0, s = t.length - 1, c = this.parts, [l, u] = we(t, n);
		if (this.el = e.createElement(l, r), M.currentNode = this.el.content, n === 2) {
			let e = this.el.content, t = e.firstChild;
			t.remove(), e.append(...t.childNodes);
		}
		for (; (i = M.nextNode()) !== null && c.length < s;) {
			if (i.nodeType === 1) {
				if (i.hasAttributes()) {
					let e = [];
					for (let t of i.getAttributeNames()) if (t.endsWith(se) || t.startsWith(T)) {
						let n = u[o++];
						if (e.push(t), n !== void 0) {
							let e = i.getAttribute(n.toLowerCase() + se).split(T), t = /([.?@])?(.*)/.exec(n);
							c.push({
								type: 1,
								index: a,
								name: t[2],
								strings: e,
								ctor: t[1] === "." ? Ae : t[1] === "?" ? Me : t[1] === "@" ? Ne : ke
							});
						} else c.push({
							type: 6,
							index: a
						});
					}
					for (let t of e) i.removeAttribute(t);
				}
				if (be.test(i.tagName)) {
					let e = i.textContent.split(T), t = e.length - 1;
					if (t > 0) {
						i.textContent = ae ? ae.emptyScript : "";
						for (let n = 0; n < t; n++) i.append(e[n], ue()), M.nextNode(), c.push({
							type: 2,
							index: ++a
						});
						i.append(e[t], ue());
					}
				}
			} else if (i.nodeType === 8) if (i.data === ce) c.push({
				type: 2,
				index: a
			});
			else {
				let e = -1;
				for (; (e = i.data.indexOf(T, e + 1)) !== -1;) c.push({
					type: 7,
					index: a
				}), e += T.length - 1;
			}
			a++;
		}
	}
	static createElement(e, t) {
		let n = E.createElement("template");
		return n.innerHTML = e, n;
	}
};
function Ee(e, t, n = e, r) {
	var i, a;
	if (t === A) return t;
	let o = r === void 0 ? n._$Cl : n._$Co?.[r], s = de(t) ? void 0 : t._$litDirective$;
	return o?.constructor !== s && ((i = o?._$AO) == null || i.call(o, !1), s === void 0 ? o = void 0 : (o = new s(e), o._$AT(e, n, r)), r === void 0 ? n._$Cl = o : ((a = n)._$Co ?? (a._$Co = []))[r] = o), o !== void 0 && (t = Ee(e, o._$AS(e, t.values), o, r)), t;
}
var De = class {
	constructor(e, t) {
		this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = t;
	}
	get parentNode() {
		return this._$AM.parentNode;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	u(e) {
		let { el: { content: t }, parts: n } = this._$AD, r = (e?.creationScope ?? E).importNode(t, !0);
		M.currentNode = r;
		let i = M.nextNode(), a = 0, o = 0, s = n[0];
		for (; s !== void 0;) {
			if (a === s.index) {
				let t;
				s.type === 2 ? t = new Oe(i, i.nextSibling, this, e) : s.type === 1 ? t = new s.ctor(i, s.name, s.strings, this, e) : s.type === 6 && (t = new Pe(i, this, e)), this._$AV.push(t), s = n[++o];
			}
			a !== s?.index && (i = M.nextNode(), a++);
		}
		return M.currentNode = E, r;
	}
	v(e) {
		let t = 0;
		for (let n of this._$AV) n !== void 0 && (n.strings === void 0 ? n._$AI(e[t]) : (n._$AI(e, n, t), t += n.strings.length - 2)), t++;
	}
}, Oe = class e {
	constructor(e, t, n, r) {
		var i;
		this.type = 2, this._$AH = j, this._$AN = void 0, this._$AA = e, this._$AB = t, this._$AM = n, this.options = r, this._$Cp = (i = r?.isConnected) == null || i;
	}
	get _$AU() {
		return this._$AM?._$AU ?? this._$Cp;
	}
	get parentNode() {
		let e = this._$AA.parentNode, t = this._$AM;
		return t !== void 0 && e?.nodeType === 11 && (e = t.parentNode), e;
	}
	get startNode() {
		return this._$AA;
	}
	get endNode() {
		return this._$AB;
	}
	_$AI(e, t = this) {
		e = Ee(this, e, t), de(e) ? e === j || e == null || e === "" ? (this._$AH !== j && this._$AR(), this._$AH = j) : e !== this._$AH && e !== A && this._(e) : e._$litType$ === void 0 ? e.nodeType === void 0 ? pe(e) ? this.T(e) : this._(e) : this.$(e) : this.g(e);
	}
	k(e) {
		return this._$AA.parentNode.insertBefore(e, this._$AB);
	}
	$(e) {
		this._$AH !== e && (this._$AR(), this._$AH = this.k(e));
	}
	_(e) {
		this._$AH !== j && de(this._$AH) ? this._$AA.nextSibling.data = e : this.$(E.createTextNode(e)), this._$AH = e;
	}
	g(e) {
		let { values: t, _$litType$: n } = e, r = typeof n == "number" ? this._$AC(e) : (n.el === void 0 && (n.el = Te.createElement(Ce(n.h, n.h[0]), this.options)), n);
		if (this._$AH?._$AD === r) this._$AH.v(t);
		else {
			let e = new De(r, this), n = e.u(this.options);
			e.v(t), this.$(n), this._$AH = e;
		}
	}
	_$AC(e) {
		let t = Se.get(e.strings);
		return t === void 0 && Se.set(e.strings, t = new Te(e)), t;
	}
	T(t) {
		fe(this._$AH) || (this._$AH = [], this._$AR());
		let n = this._$AH, r, i = 0;
		for (let a of t) i === n.length ? n.push(r = new e(this.k(ue()), this.k(ue()), this, this.options)) : r = n[i], r._$AI(a), i++;
		i < n.length && (this._$AR(r && r._$AB.nextSibling, i), n.length = i);
	}
	_$AR(e = this._$AA.nextSibling, t) {
		var n;
		for ((n = this._$AP) == null || n.call(this, !1, !0, t); e && e !== this._$AB;) {
			let t = e.nextSibling;
			e.remove(), e = t;
		}
	}
	setConnected(e) {
		var t;
		this._$AM === void 0 && (this._$Cp = e, (t = this._$AP) == null || t.call(this, e));
	}
}, ke = class {
	constructor(e, t, n, r, i) {
		this.type = 1, this._$AH = j, this._$AN = void 0, this.element = e, this.name = t, this._$AM = r, this.options = i, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(/* @__PURE__ */ new String()), this.strings = n) : this._$AH = j;
	}
	get tagName() {
		return this.element.tagName;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	_$AI(e, t = this, n, r) {
		let i = this.strings, a = !1;
		if (i === void 0) e = Ee(this, e, t, 0), a = !de(e) || e !== this._$AH && e !== A, a && (this._$AH = e);
		else {
			let r = e, o, s;
			for (e = i[0], o = 0; o < i.length - 1; o++) s = Ee(this, r[n + o], t, o), s === A && (s = this._$AH[o]), a ||= !de(s) || s !== this._$AH[o], s === j ? e = j : e !== j && (e += (s ?? "") + i[o + 1]), this._$AH[o] = s;
		}
		a && !r && this.j(e);
	}
	j(e) {
		e === j ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
	}
}, Ae = class extends ke {
	constructor() {
		super(...arguments), this.type = 3;
	}
	j(e) {
		this.element[this.name] = e === j ? void 0 : e;
	}
}, je = ae ? ae.emptyScript : "", Me = class extends ke {
	constructor() {
		super(...arguments), this.type = 4;
	}
	j(e) {
		e && e !== j ? this.element.setAttribute(this.name, je) : this.element.removeAttribute(this.name);
	}
}, Ne = class extends ke {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i), this.type = 5;
	}
	_$AI(e, t = this) {
		if ((e = Ee(this, e, t, 0) ?? j) === A) return;
		let n = this._$AH, r = e === j && n !== j || e.capture !== n.capture || e.once !== n.once || e.passive !== n.passive, i = e !== j && (n === j || r);
		r && this.element.removeEventListener(this.name, this, n), i && this.element.addEventListener(this.name, this, e), this._$AH = e;
	}
	handleEvent(e) {
		typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
	}
}, Pe = class {
	constructor(e, t, n) {
		this.element = e, this.type = 6, this._$AN = void 0, this._$AM = t, this.options = n;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	_$AI(e) {
		Ee(this, e);
	}
}, Fe = ie.litHtmlPolyfillSupport;
Fe?.(Te, Oe), (ie.litHtmlVersions ??= []).push("2.8.0");
var Ie = (e, t, n) => {
	let r = n?.renderBefore ?? t, i = r._$litPart$;
	if (i === void 0) {
		let e = n?.renderBefore ?? null;
		r._$litPart$ = i = new Oe(t.insertBefore(ue(), e), e, void 0, n ?? {});
	}
	return i._$AI(e), i;
}, Le, N = class extends re {
	constructor() {
		super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
	}
	createRenderRoot() {
		var e;
		let t = super.createRenderRoot();
		return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
	}
	update(e) {
		let t = this.render();
		this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = Ie(t, this.renderRoot, this.renderOptions);
	}
	connectedCallback() {
		var e;
		super.connectedCallback(), (e = this._$Do) == null || e.setConnected(!0);
	}
	disconnectedCallback() {
		var e;
		super.disconnectedCallback(), (e = this._$Do) == null || e.setConnected(!1);
	}
	render() {
		return A;
	}
};
N.finalized = !0, N._$litElement$ = !0, (Le = globalThis.litElementHydrateSupport) == null || Le.call(globalThis, { LitElement: N });
var Re = globalThis.litElementPolyfillSupport;
Re?.({ LitElement: N }), (globalThis.litElementVersions ?? (globalThis.litElementVersions = [])).push("3.3.3");
//#endregion
//#region ../../node_modules/.pnpm/@lit+reactive-element@1.6.3/node_modules/@lit/reactive-element/decorators/custom-element.js
var P = (e) => (t) => typeof t == "function" ? ((e, t) => (customElements.define(e, t), t))(e, t) : ((e, t) => {
	let { kind: n, elements: r } = t;
	return {
		kind: n,
		elements: r,
		finisher(t) {
			customElements.define(e, t);
		}
	};
})(e, t), ze = (e, t) => t.kind === "method" && t.descriptor && !("value" in t.descriptor) ? {
	...t,
	finisher(n) {
		n.createProperty(t.key, e);
	}
} : {
	kind: "field",
	key: Symbol(),
	placement: "own",
	descriptor: {},
	originalKey: t.key,
	initializer() {
		typeof t.initializer == "function" && (this[t.key] = t.initializer.call(this));
	},
	finisher(n) {
		n.createProperty(t.key, e);
	}
}, Be = (e, t, n) => {
	t.constructor.createProperty(n, e);
};
function F(e) {
	return (t, n) => n === void 0 ? ze(e, t) : Be(e, t, n);
}
//#endregion
//#region ../../node_modules/.pnpm/@lit+reactive-element@1.6.3/node_modules/@lit/reactive-element/decorators/state.js
function I(e) {
	return F({
		...e,
		state: !0
	});
}
window.HTMLSlotElement?.prototype.assignedElements;
//#endregion
//#region ../../node_modules/.pnpm/lit-html@2.8.0/node_modules/lit-html/directive.js
var Ve = {
	ATTRIBUTE: 1,
	CHILD: 2,
	PROPERTY: 3,
	BOOLEAN_ATTRIBUTE: 4,
	EVENT: 5,
	ELEMENT: 6
}, He = (e) => (...t) => ({
	_$litDirective$: e,
	values: t
}), Ue = class {
	constructor(e) {}
	get _$AU() {
		return this._$AM._$AU;
	}
	_$AT(e, t, n) {
		this._$Ct = e, this._$AM = t, this._$Ci = n;
	}
	_$AS(e, t) {
		return this.update(e, t);
	}
	update(e, t) {
		return this.render(...t);
	}
}, L = He(class extends Ue {
	constructor(e) {
		if (super(e), e.type !== Ve.ATTRIBUTE || e.name !== "class" || e.strings?.length > 2) throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
	}
	render(e) {
		return " " + Object.keys(e).filter(((t) => e[t])).join(" ") + " ";
	}
	update(e, [t]) {
		var n;
		if (this.it === void 0) {
			this.it = /* @__PURE__ */ new Set(), e.strings !== void 0 && (this.nt = new Set(e.strings.join(" ").split(/\s/).filter(((e) => e !== ""))));
			for (let e in t) t[e] && !this.nt?.has(e) && this.it.add(e);
			return this.render(t);
		}
		let r = e.element.classList;
		this.it.forEach(((e) => {
			e in t || (r.remove(e), this.it.delete(e));
		}));
		for (let e in t) {
			let i = !!t[e];
			i === this.it.has(e) || (n = this.nt) != null && n.has(e) || (i ? (r.add(e), this.it.add(e)) : (r.remove(e), this.it.delete(e)));
		}
		return A;
	}
});
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/array.es.js
function We(e, t) {
	e.indexOf(t) === -1 && e.push(t);
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/clamp.es.js
var Ge = (e, t, n) => Math.min(Math.max(n, e), t), R = {
	duration: .3,
	delay: 0,
	endDelay: 0,
	repeat: 0,
	easing: "ease"
}, Ke = (e) => typeof e == "number", qe = (e) => Array.isArray(e) && !Ke(e[0]), Je = (e, t, n) => {
	let r = t - e;
	return ((n - e) % r + r) % r + e;
};
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/easing.es.js
function Ye(e, t) {
	return qe(e) ? e[Je(0, e.length, t)] : e;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/mix.es.js
var Xe = (e, t, n) => -n * e + n * t + e, Ze = () => {}, z = (e) => e, Qe = (e, t, n) => t - e === 0 ? 1 : (n - e) / (t - e);
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/offset.es.js
function $e(e, t) {
	let n = e[e.length - 1];
	for (let r = 1; r <= t; r++) {
		let i = Qe(0, t, r);
		e.push(Xe(n, 1, i));
	}
}
function et(e) {
	let t = [0];
	return $e(t, e - 1), t;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/interpolate.es.js
function tt(e, t = et(e.length), n = z) {
	let r = e.length, i = r - t.length;
	return i > 0 && $e(t, i), (i) => {
		let a = 0;
		for (; a < r - 2 && !(i < t[a + 1]); a++);
		let o = Ge(0, 1, Qe(t[a], t[a + 1], i));
		return o = Ye(n, a)(o), Xe(e[a], e[a + 1], o);
	};
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+utils@10.18.0/node_modules/@motionone/utils/dist/is-cubic-bezier.es.js
var nt = (e) => Array.isArray(e) && Ke(e[0]), rt = (e) => typeof e == "object" && !!e.createAnimation, it = (e) => typeof e == "function", at = (e) => typeof e == "string", ot = {
	ms: (e) => e * 1e3,
	s: (e) => e / 1e3
}, st = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e, ct = 1e-7, lt = 12;
function ut(e, t, n, r, i) {
	let a, o, s = 0;
	do
		o = t + (n - t) / 2, a = st(o, r, i) - e, a > 0 ? n = o : t = o;
	while (Math.abs(a) > ct && ++s < lt);
	return o;
}
function dt(e, t, n, r) {
	if (e === t && n === r) return z;
	let i = (t) => ut(t, 0, 1, e, n);
	return (e) => e === 0 || e === 1 ? e : st(i(e), t, r);
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+easing@10.18.0/node_modules/@motionone/easing/dist/steps.es.js
var ft = (e, t = "end") => (n) => {
	n = t === "end" ? Math.min(n, .999) : Math.max(n, .001);
	let r = n * e;
	return Ge(0, 1, (t === "end" ? Math.floor(r) : Math.ceil(r)) / e);
}, pt = {
	ease: dt(.25, .1, .25, 1),
	"ease-in": dt(.42, 0, 1, 1),
	"ease-in-out": dt(.42, 0, .58, 1),
	"ease-out": dt(0, 0, .58, 1)
}, mt = /\((.*?)\)/;
function ht(e) {
	if (it(e)) return e;
	if (nt(e)) return dt(...e);
	let t = pt[e];
	if (t) return t;
	if (e.startsWith("steps")) {
		let t = mt.exec(e);
		if (t) {
			let e = t[1].split(",");
			return ft(parseFloat(e[0]), e[1].trim());
		}
	}
	return z;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+animation@10.18.0/node_modules/@motionone/animation/dist/Animation.es.js
var gt = class {
	constructor(e, t = [0, 1], { easing: n, duration: r = R.duration, delay: i = R.delay, endDelay: a = R.endDelay, repeat: o = R.repeat, offset: s, direction: c = "normal", autoplay: l = !0 } = {}) {
		if (this.startTime = null, this.rate = 1, this.t = 0, this.cancelTimestamp = null, this.easing = z, this.duration = 0, this.totalDuration = 0, this.repeat = 0, this.playState = "idle", this.finished = new Promise((e, t) => {
			this.resolve = e, this.reject = t;
		}), n ||= R.easing, rt(n)) {
			let e = n.createAnimation(t);
			n = e.easing, t = e.keyframes || t, r = e.duration || r;
		}
		this.repeat = o, this.easing = qe(n) ? z : ht(n), this.updateDuration(r);
		let u = tt(t, s, qe(n) ? n.map(ht) : z);
		this.tick = (t) => {
			var n;
			i = i;
			let r = 0;
			r = this.pauseTime === void 0 ? (t - this.startTime) * this.rate : this.pauseTime, this.t = r, r /= 1e3, r = Math.max(r - i, 0), this.playState === "finished" && this.pauseTime === void 0 && (r = this.totalDuration);
			let o = r / this.duration, s = Math.floor(o), l = o % 1;
			!l && o >= 1 && (l = 1), l === 1 && s--;
			let d = s % 2;
			(c === "reverse" || c === "alternate" && d || c === "alternate-reverse" && !d) && (l = 1 - l);
			let f = r >= this.totalDuration ? 1 : Math.min(l, 1), p = u(this.easing(f));
			e(p), this.pauseTime === void 0 && (this.playState === "finished" || r >= this.totalDuration + a) ? (this.playState = "finished", (n = this.resolve) == null || n.call(this, p)) : this.playState !== "idle" && (this.frameRequestId = requestAnimationFrame(this.tick));
		}, l && this.play();
	}
	play() {
		let e = performance.now();
		this.playState = "running", this.pauseTime === void 0 ? this.startTime ||= e : this.startTime = e - this.pauseTime, this.cancelTimestamp = this.startTime, this.pauseTime = void 0, this.frameRequestId = requestAnimationFrame(this.tick);
	}
	pause() {
		this.playState = "paused", this.pauseTime = this.t;
	}
	finish() {
		this.playState = "finished", this.tick(0);
	}
	stop() {
		var e;
		this.playState = "idle", this.frameRequestId !== void 0 && cancelAnimationFrame(this.frameRequestId), (e = this.reject) == null || e.call(this, !1);
	}
	cancel() {
		this.stop(), this.tick(this.cancelTimestamp);
	}
	reverse() {
		this.rate *= -1;
	}
	commitStyles() {}
	updateDuration(e) {
		this.duration = e, this.totalDuration = e * (this.repeat + 1);
	}
	get currentTime() {
		return this.t;
	}
	set currentTime(e) {
		this.pauseTime !== void 0 || this.rate === 0 ? this.pauseTime = e : this.startTime = performance.now() - e / this.rate;
	}
	get playbackRate() {
		return this.rate;
	}
	set playbackRate(e) {
		this.rate = e;
	}
}, _t = function() {};
process.env.NODE_ENV !== "production" && (_t = function(e, t) {
	if (!e) throw Error(t);
});
//#endregion
//#region ../../node_modules/.pnpm/@motionone+types@10.17.1/node_modules/@motionone/types/dist/MotionValue.es.js
var vt = class {
	setAnimation(e) {
		this.animation = e, e?.finished.then(() => this.clearAnimation()).catch(() => {});
	}
	clearAnimation() {
		this.animation = this.generator = void 0;
	}
}, yt = /* @__PURE__ */ new WeakMap();
function bt(e) {
	return yt.has(e) || yt.set(e, {
		transforms: [],
		values: /* @__PURE__ */ new Map()
	}), yt.get(e);
}
function xt(e, t) {
	return e.has(t) || e.set(t, new vt()), e.get(t);
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/transforms.es.js
var St = [
	"",
	"X",
	"Y",
	"Z"
], Ct = [
	"translate",
	"scale",
	"rotate",
	"skew"
], wt = {
	x: "translateX",
	y: "translateY",
	z: "translateZ"
}, Tt = {
	syntax: "<angle>",
	initialValue: "0deg",
	toDefaultUnit: (e) => e + "deg"
}, Et = {
	translate: {
		syntax: "<length-percentage>",
		initialValue: "0px",
		toDefaultUnit: (e) => e + "px"
	},
	rotate: Tt,
	scale: {
		syntax: "<number>",
		initialValue: 1,
		toDefaultUnit: z
	},
	skew: Tt
}, Dt = /* @__PURE__ */ new Map(), Ot = (e) => `--motion-${e}`, kt = [
	"x",
	"y",
	"z"
];
Ct.forEach((e) => {
	St.forEach((t) => {
		kt.push(e + t), Dt.set(Ot(e + t), Et[e]);
	});
});
var At = (e, t) => kt.indexOf(e) - kt.indexOf(t), jt = new Set(kt), Mt = (e) => jt.has(e), Nt = (e, t) => {
	wt[t] && (t = wt[t]);
	let { transforms: n } = bt(e);
	We(n, t), e.style.transform = Pt(n);
}, Pt = (e) => e.sort(At).reduce(Ft, "").trim(), Ft = (e, t) => `${e} ${t}(var(${Ot(t)}))`, It = (e) => e.startsWith("--"), Lt = /* @__PURE__ */ new Set();
function Rt(e) {
	if (!Lt.has(e)) {
		Lt.add(e);
		try {
			let { syntax: t, initialValue: n } = Dt.has(e) ? Dt.get(e) : {};
			CSS.registerProperty({
				name: e,
				inherits: !1,
				syntax: t,
				initialValue: n
			});
		} catch {}
	}
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/feature-detection.es.js
var zt = (e, t) => document.createElement("div").animate(e, t), Bt = {
	cssRegisterProperty: () => typeof CSS < "u" && Object.hasOwnProperty.call(CSS, "registerProperty"),
	waapi: () => Object.hasOwnProperty.call(Element.prototype, "animate"),
	partialKeyframes: () => {
		try {
			zt({ opacity: [1] });
		} catch {
			return !1;
		}
		return !0;
	},
	finished: () => !!zt({ opacity: [0, 1] }, { duration: .001 }).finished,
	linearEasing: () => {
		try {
			zt({ opacity: 0 }, { easing: "linear(0, 1)" });
		} catch {
			return !1;
		}
		return !0;
	}
}, Vt = {}, Ht = {};
for (let e in Bt) Ht[e] = () => (Vt[e] === void 0 && (Vt[e] = Bt[e]()), Vt[e]);
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/easing.es.js
var Ut = .015, Wt = (e, t) => {
	let n = "", r = Math.round(t / Ut);
	for (let t = 0; t < r; t++) n += e(Qe(0, r - 1, t)) + ", ";
	return n.substring(0, n.length - 2);
}, Gt = (e, t) => it(e) ? Ht.linearEasing() ? `linear(${Wt(e, t)})` : R.easing : nt(e) ? Kt(e) : e, Kt = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`;
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/keyframes.es.js
function qt(e, t) {
	for (let n = 0; n < e.length; n++) e[n] === null && (e[n] = n ? e[n - 1] : t());
	return e;
}
var Jt = (e) => Array.isArray(e) ? e : [e];
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/get-style-name.es.js
function Yt(e) {
	return wt[e] && (e = wt[e]), Mt(e) ? Ot(e) : e;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/style.es.js
var Xt = {
	get: (e, t) => {
		t = Yt(t);
		let n = It(t) ? e.style.getPropertyValue(t) : getComputedStyle(e)[t];
		if (!n && n !== 0) {
			let e = Dt.get(t);
			e && (n = e.initialValue);
		}
		return n;
	},
	set: (e, t, n) => {
		t = Yt(t), It(t) ? e.style.setProperty(t, n) : e.style[t] = n;
	}
};
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/stop-animation.es.js
function Zt(e, t = !0) {
	if (!(!e || e.playState === "finished")) try {
		e.stop ? e.stop() : (t && e.commitStyles(), e.cancel());
	} catch {}
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/get-unit.es.js
function Qt(e, t) {
	let n = t?.toDefaultUnit || z, r = e[e.length - 1];
	if (at(r)) {
		let e = r.match(/(-?[\d.]+)([a-z%]*)/)?.[2] || "";
		e && (n = (t) => t + e);
	}
	return n;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/animate-style.es.js
function $t() {
	return window.__MOTION_DEV_TOOLS_RECORD;
}
function en(e, t, n, r = {}, i) {
	let a = $t(), o = r.record !== !1 && a, s, { duration: c = R.duration, delay: l = R.delay, endDelay: u = R.endDelay, repeat: d = R.repeat, easing: f = R.easing, persist: p = !1, direction: m, offset: h, allowWebkitAcceleration: g = !1, autoplay: _ = !0 } = r, v = bt(e), y = Mt(t), b = Ht.waapi();
	y && Nt(e, t);
	let x = Yt(t), S = xt(v.values, x), C = Dt.get(x);
	return Zt(S.animation, !(rt(f) && S.generator) && r.record !== !1), () => {
		let v = () => Xt.get(e, x) ?? C?.initialValue ?? 0, w = qt(Jt(n), v), ee = Qt(w, C);
		if (rt(f)) {
			let e = f.createAnimation(w, t !== "opacity", v, x, S);
			f = e.easing, w = e.keyframes || w, c = e.duration || c;
		}
		if (It(x) && (Ht.cssRegisterProperty() ? Rt(x) : b = !1), y && !Ht.linearEasing() && (it(f) || qe(f) && f.some(it)) && (b = !1), b) {
			C && (w = w.map((e) => Ke(e) ? C.toDefaultUnit(e) : e)), w.length === 1 && (!Ht.partialKeyframes() || o) && w.unshift(v());
			let t = {
				delay: ot.ms(l),
				duration: ot.ms(c),
				endDelay: ot.ms(u),
				easing: qe(f) ? void 0 : Gt(f, c),
				direction: m,
				iterations: d + 1,
				fill: "both"
			};
			s = e.animate({
				[x]: w,
				offset: h,
				easing: qe(f) ? f.map((e) => Gt(e, c)) : void 0
			}, t), s.finished ||= new Promise((e, t) => {
				s.onfinish = e, s.oncancel = t;
			});
			let n = w[w.length - 1];
			s.finished.then(() => {
				p || (Xt.set(e, x, n), s.cancel());
			}).catch(Ze), g || (s.playbackRate = 1.000001);
		} else if (i && y) w = w.map((e) => typeof e == "string" ? parseFloat(e) : e), w.length === 1 && w.unshift(parseFloat(v())), s = new i((t) => {
			Xt.set(e, x, ee ? ee(t) : t);
		}, w, Object.assign(Object.assign({}, r), {
			duration: c,
			easing: f
		}));
		else {
			let t = w[w.length - 1];
			Xt.set(e, x, C && Ke(t) ? C.toDefaultUnit(t) : t);
		}
		return o && a(e, t, w, {
			duration: c,
			delay: l,
			easing: f,
			repeat: d,
			offset: h
		}, "motion-one"), S.setAnimation(s), s && !_ && s.pause(), s;
	};
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/options.es.js
var tn = (e, t) => e[t] ? Object.assign(Object.assign({}, e), e[t]) : Object.assign({}, e);
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/utils/resolve-elements.es.js
function nn(e, t) {
	return typeof e == "string" ? t ? (t[e] ?? (t[e] = document.querySelectorAll(e)), e = t[e]) : e = document.querySelectorAll(e) : e instanceof Element && (e = [e]), Array.from(e || []);
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/utils/controls.es.js
var rn = (e) => e(), an = (e, t, n = R.duration) => new Proxy({
	animations: e.map(rn).filter(Boolean),
	duration: n,
	options: t
}, sn), on = (e) => e.animations[0], sn = {
	get: (e, t) => {
		let n = on(e);
		switch (t) {
			case "duration": return e.duration;
			case "currentTime": return ot.s(n?.[t] || 0);
			case "playbackRate":
			case "playState": return n?.[t];
			case "finished": return e.finished ||= Promise.all(e.animations.map(cn)).catch(Ze), e.finished;
			case "stop": return () => {
				e.animations.forEach((e) => Zt(e));
			};
			case "forEachNative": return (t) => {
				e.animations.forEach((n) => t(n, e));
			};
			default: return n?.[t] === void 0 ? void 0 : () => e.animations.forEach((e) => e[t]());
		}
	},
	set: (e, t, n) => {
		switch (t) {
			case "currentTime": n = ot.ms(n);
			case "playbackRate":
				for (let r = 0; r < e.animations.length; r++) e.animations[r][t] = n;
				return !0;
		}
		return !1;
	}
}, cn = (e) => e.finished;
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/utils/stagger.es.js
function ln(e, t, n) {
	return it(e) ? e(t, n) : e;
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/create-animate.es.js
function un(e) {
	return function(t, n, r = {}) {
		t = nn(t);
		let i = t.length;
		_t(!!i, "No valid element provided."), _t(!!n, "No keyframes defined.");
		let a = [];
		for (let o = 0; o < i; o++) {
			let s = t[o];
			for (let t in n) {
				let c = tn(r, t);
				c.delay = ln(c.delay, o, i);
				let l = en(s, t, n[t], c, e);
				a.push(l);
			}
		}
		return an(a, r, r.duration);
	};
}
//#endregion
//#region ../../node_modules/.pnpm/@motionone+dom@10.18.0/node_modules/@motionone/dom/dist/animate/index.es.js
var dn = un(gt);
//#endregion
//#region ../../node_modules/.pnpm/motion@10.16.2/node_modules/motion/dist/animate.es.js
function fn(e, t = {}) {
	return an([() => {
		let n = new gt(e, [0, 1], t);
		return n.finished.catch(() => {}), n;
	}], t, t.duration);
}
function B(e, t, n) {
	return (it(e) ? fn : dn)(e, t, n);
}
//#endregion
//#region ../../node_modules/.pnpm/lit-html@2.8.0/node_modules/lit-html/directives/if-defined.js
var V = (e) => e ?? j, pn = /* @__PURE__ */ r(((e, t) => {
	t.exports = function() {
		return typeof Promise == "function" && Promise.prototype && Promise.prototype.then;
	};
})), H = /* @__PURE__ */ r(((e) => {
	var t, n = [
		0,
		26,
		44,
		70,
		100,
		134,
		172,
		196,
		242,
		292,
		346,
		404,
		466,
		532,
		581,
		655,
		733,
		815,
		901,
		991,
		1085,
		1156,
		1258,
		1364,
		1474,
		1588,
		1706,
		1828,
		1921,
		2051,
		2185,
		2323,
		2465,
		2611,
		2761,
		2876,
		3034,
		3196,
		3362,
		3532,
		3706
	];
	e.getSymbolSize = function(e) {
		if (!e) throw Error("\"version\" cannot be null or undefined");
		if (e < 1 || e > 40) throw Error("\"version\" should be in range from 1 to 40");
		return e * 4 + 17;
	}, e.getSymbolTotalCodewords = function(e) {
		return n[e];
	}, e.getBCHDigit = function(e) {
		let t = 0;
		for (; e !== 0;) t++, e >>>= 1;
		return t;
	}, e.setToSJISFunction = function(e) {
		if (typeof e != "function") throw Error("\"toSJISFunc\" is not a valid function.");
		t = e;
	}, e.isKanjiModeEnabled = function() {
		return t !== void 0;
	}, e.toSJIS = function(e) {
		return t(e);
	};
})), mn = /* @__PURE__ */ r(((e) => {
	e.L = { bit: 1 }, e.M = { bit: 0 }, e.Q = { bit: 3 }, e.H = { bit: 2 };
	function t(t) {
		if (typeof t != "string") throw Error("Param is not a string");
		switch (t.toLowerCase()) {
			case "l":
			case "low": return e.L;
			case "m":
			case "medium": return e.M;
			case "q":
			case "quartile": return e.Q;
			case "h":
			case "high": return e.H;
			default: throw Error("Unknown EC Level: " + t);
		}
	}
	e.isValid = function(e) {
		return e && e.bit !== void 0 && e.bit >= 0 && e.bit < 4;
	}, e.from = function(n, r) {
		if (e.isValid(n)) return n;
		try {
			return t(n);
		} catch {
			return r;
		}
	};
})), hn = /* @__PURE__ */ r(((e, t) => {
	function n() {
		this.buffer = [], this.length = 0;
	}
	n.prototype = {
		get: function(e) {
			let t = Math.floor(e / 8);
			return (this.buffer[t] >>> 7 - e % 8 & 1) == 1;
		},
		put: function(e, t) {
			for (let n = 0; n < t; n++) this.putBit((e >>> t - n - 1 & 1) == 1);
		},
		getLengthInBits: function() {
			return this.length;
		},
		putBit: function(e) {
			let t = Math.floor(this.length / 8);
			this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), this.length++;
		}
	}, t.exports = n;
})), gn = /* @__PURE__ */ r(((e, t) => {
	function n(e) {
		if (!e || e < 1) throw Error("BitMatrix size must be defined and greater than 0");
		this.size = e, this.data = new Uint8Array(e * e), this.reservedBit = new Uint8Array(e * e);
	}
	n.prototype.set = function(e, t, n, r) {
		let i = e * this.size + t;
		this.data[i] = n, r && (this.reservedBit[i] = !0);
	}, n.prototype.get = function(e, t) {
		return this.data[e * this.size + t];
	}, n.prototype.xor = function(e, t, n) {
		this.data[e * this.size + t] ^= n;
	}, n.prototype.isReserved = function(e, t) {
		return this.reservedBit[e * this.size + t];
	}, t.exports = n;
})), _n = /* @__PURE__ */ r(((e) => {
	var t = H().getSymbolSize;
	e.getRowColCoords = function(e) {
		if (e === 1) return [];
		let n = Math.floor(e / 7) + 2, r = t(e), i = r === 145 ? 26 : Math.ceil((r - 13) / (2 * n - 2)) * 2, a = [r - 7];
		for (let e = 1; e < n - 1; e++) a[e] = a[e - 1] - i;
		return a.push(6), a.reverse();
	}, e.getPositions = function(t) {
		let n = [], r = e.getRowColCoords(t), i = r.length;
		for (let e = 0; e < i; e++) for (let t = 0; t < i; t++) e === 0 && t === 0 || e === 0 && t === i - 1 || e === i - 1 && t === 0 || n.push([r[e], r[t]]);
		return n;
	};
})), vn = /* @__PURE__ */ r(((e) => {
	var t = H().getSymbolSize, n = 7;
	e.getPositions = function(e) {
		let r = t(e);
		return [
			[0, 0],
			[r - n, 0],
			[0, r - n]
		];
	};
})), yn = /* @__PURE__ */ r(((e) => {
	e.Patterns = {
		PATTERN000: 0,
		PATTERN001: 1,
		PATTERN010: 2,
		PATTERN011: 3,
		PATTERN100: 4,
		PATTERN101: 5,
		PATTERN110: 6,
		PATTERN111: 7
	};
	var t = {
		N1: 3,
		N2: 3,
		N3: 40,
		N4: 10
	};
	e.isValid = function(e) {
		return e != null && e !== "" && !isNaN(e) && e >= 0 && e <= 7;
	}, e.from = function(t) {
		return e.isValid(t) ? parseInt(t, 10) : void 0;
	}, e.getPenaltyN1 = function(e) {
		let n = e.size, r = 0, i = 0, a = 0, o = null, s = null;
		for (let c = 0; c < n; c++) {
			i = a = 0, o = s = null;
			for (let l = 0; l < n; l++) {
				let n = e.get(c, l);
				n === o ? i++ : (i >= 5 && (r += t.N1 + (i - 5)), o = n, i = 1), n = e.get(l, c), n === s ? a++ : (a >= 5 && (r += t.N1 + (a - 5)), s = n, a = 1);
			}
			i >= 5 && (r += t.N1 + (i - 5)), a >= 5 && (r += t.N1 + (a - 5));
		}
		return r;
	}, e.getPenaltyN2 = function(e) {
		let n = e.size, r = 0;
		for (let t = 0; t < n - 1; t++) for (let i = 0; i < n - 1; i++) {
			let n = e.get(t, i) + e.get(t, i + 1) + e.get(t + 1, i) + e.get(t + 1, i + 1);
			(n === 4 || n === 0) && r++;
		}
		return r * t.N2;
	}, e.getPenaltyN3 = function(e) {
		let n = e.size, r = 0, i = 0, a = 0;
		for (let t = 0; t < n; t++) {
			i = a = 0;
			for (let o = 0; o < n; o++) i = i << 1 & 2047 | e.get(t, o), o >= 10 && (i === 1488 || i === 93) && r++, a = a << 1 & 2047 | e.get(o, t), o >= 10 && (a === 1488 || a === 93) && r++;
		}
		return r * t.N3;
	}, e.getPenaltyN4 = function(e) {
		let n = 0, r = e.data.length;
		for (let t = 0; t < r; t++) n += e.data[t];
		return Math.abs(Math.ceil(n * 100 / r / 5) - 10) * t.N4;
	};
	function n(t, n, r) {
		switch (t) {
			case e.Patterns.PATTERN000: return (n + r) % 2 == 0;
			case e.Patterns.PATTERN001: return n % 2 == 0;
			case e.Patterns.PATTERN010: return r % 3 == 0;
			case e.Patterns.PATTERN011: return (n + r) % 3 == 0;
			case e.Patterns.PATTERN100: return (Math.floor(n / 2) + Math.floor(r / 3)) % 2 == 0;
			case e.Patterns.PATTERN101: return n * r % 2 + n * r % 3 == 0;
			case e.Patterns.PATTERN110: return (n * r % 2 + n * r % 3) % 2 == 0;
			case e.Patterns.PATTERN111: return (n * r % 3 + (n + r) % 2) % 2 == 0;
			default: throw Error("bad maskPattern:" + t);
		}
	}
	e.applyMask = function(e, t) {
		let r = t.size;
		for (let i = 0; i < r; i++) for (let a = 0; a < r; a++) t.isReserved(a, i) || t.xor(a, i, n(e, a, i));
	}, e.getBestMask = function(t, n) {
		let r = Object.keys(e.Patterns).length, i = 0, a = Infinity;
		for (let o = 0; o < r; o++) {
			n(o), e.applyMask(o, t);
			let r = e.getPenaltyN1(t) + e.getPenaltyN2(t) + e.getPenaltyN3(t) + e.getPenaltyN4(t);
			e.applyMask(o, t), r < a && (a = r, i = o);
		}
		return i;
	};
})), bn = /* @__PURE__ */ r(((e) => {
	var t = mn(), n = [
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		2,
		2,
		1,
		2,
		2,
		4,
		1,
		2,
		4,
		4,
		2,
		4,
		4,
		4,
		2,
		4,
		6,
		5,
		2,
		4,
		6,
		6,
		2,
		5,
		8,
		8,
		4,
		5,
		8,
		8,
		4,
		5,
		8,
		11,
		4,
		8,
		10,
		11,
		4,
		9,
		12,
		16,
		4,
		9,
		16,
		16,
		6,
		10,
		12,
		18,
		6,
		10,
		17,
		16,
		6,
		11,
		16,
		19,
		6,
		13,
		18,
		21,
		7,
		14,
		21,
		25,
		8,
		16,
		20,
		25,
		8,
		17,
		23,
		25,
		9,
		17,
		23,
		34,
		9,
		18,
		25,
		30,
		10,
		20,
		27,
		32,
		12,
		21,
		29,
		35,
		12,
		23,
		34,
		37,
		12,
		25,
		34,
		40,
		13,
		26,
		35,
		42,
		14,
		28,
		38,
		45,
		15,
		29,
		40,
		48,
		16,
		31,
		43,
		51,
		17,
		33,
		45,
		54,
		18,
		35,
		48,
		57,
		19,
		37,
		51,
		60,
		19,
		38,
		53,
		63,
		20,
		40,
		56,
		66,
		21,
		43,
		59,
		70,
		22,
		45,
		62,
		74,
		24,
		47,
		65,
		77,
		25,
		49,
		68,
		81
	], r = [
		7,
		10,
		13,
		17,
		10,
		16,
		22,
		28,
		15,
		26,
		36,
		44,
		20,
		36,
		52,
		64,
		26,
		48,
		72,
		88,
		36,
		64,
		96,
		112,
		40,
		72,
		108,
		130,
		48,
		88,
		132,
		156,
		60,
		110,
		160,
		192,
		72,
		130,
		192,
		224,
		80,
		150,
		224,
		264,
		96,
		176,
		260,
		308,
		104,
		198,
		288,
		352,
		120,
		216,
		320,
		384,
		132,
		240,
		360,
		432,
		144,
		280,
		408,
		480,
		168,
		308,
		448,
		532,
		180,
		338,
		504,
		588,
		196,
		364,
		546,
		650,
		224,
		416,
		600,
		700,
		224,
		442,
		644,
		750,
		252,
		476,
		690,
		816,
		270,
		504,
		750,
		900,
		300,
		560,
		810,
		960,
		312,
		588,
		870,
		1050,
		336,
		644,
		952,
		1110,
		360,
		700,
		1020,
		1200,
		390,
		728,
		1050,
		1260,
		420,
		784,
		1140,
		1350,
		450,
		812,
		1200,
		1440,
		480,
		868,
		1290,
		1530,
		510,
		924,
		1350,
		1620,
		540,
		980,
		1440,
		1710,
		570,
		1036,
		1530,
		1800,
		570,
		1064,
		1590,
		1890,
		600,
		1120,
		1680,
		1980,
		630,
		1204,
		1770,
		2100,
		660,
		1260,
		1860,
		2220,
		720,
		1316,
		1950,
		2310,
		750,
		1372,
		2040,
		2430
	];
	e.getBlocksCount = function(e, r) {
		switch (r) {
			case t.L: return n[(e - 1) * 4 + 0];
			case t.M: return n[(e - 1) * 4 + 1];
			case t.Q: return n[(e - 1) * 4 + 2];
			case t.H: return n[(e - 1) * 4 + 3];
			default: return;
		}
	}, e.getTotalCodewordsCount = function(e, n) {
		switch (n) {
			case t.L: return r[(e - 1) * 4 + 0];
			case t.M: return r[(e - 1) * 4 + 1];
			case t.Q: return r[(e - 1) * 4 + 2];
			case t.H: return r[(e - 1) * 4 + 3];
			default: return;
		}
	};
})), xn = /* @__PURE__ */ r(((e) => {
	var t = /* @__PURE__ */ new Uint8Array(512), n = /* @__PURE__ */ new Uint8Array(256);
	(function() {
		let e = 1;
		for (let r = 0; r < 255; r++) t[r] = e, n[e] = r, e <<= 1, e & 256 && (e ^= 285);
		for (let e = 255; e < 512; e++) t[e] = t[e - 255];
	})(), e.log = function(e) {
		if (e < 1) throw Error("log(" + e + ")");
		return n[e];
	}, e.exp = function(e) {
		return t[e];
	}, e.mul = function(e, r) {
		return e === 0 || r === 0 ? 0 : t[n[e] + n[r]];
	};
})), Sn = /* @__PURE__ */ r(((e) => {
	var t = xn();
	e.mul = function(e, n) {
		let r = new Uint8Array(e.length + n.length - 1);
		for (let i = 0; i < e.length; i++) for (let a = 0; a < n.length; a++) r[i + a] ^= t.mul(e[i], n[a]);
		return r;
	}, e.mod = function(e, n) {
		let r = new Uint8Array(e);
		for (; r.length - n.length >= 0;) {
			let e = r[0];
			for (let i = 0; i < n.length; i++) r[i] ^= t.mul(n[i], e);
			let i = 0;
			for (; i < r.length && r[i] === 0;) i++;
			r = r.slice(i);
		}
		return r;
	}, e.generateECPolynomial = function(n) {
		let r = new Uint8Array([1]);
		for (let i = 0; i < n; i++) r = e.mul(r, new Uint8Array([1, t.exp(i)]));
		return r;
	};
})), Cn = /* @__PURE__ */ r(((e, t) => {
	var n = Sn();
	function r(e) {
		this.genPoly = void 0, this.degree = e, this.degree && this.initialize(this.degree);
	}
	r.prototype.initialize = function(e) {
		this.degree = e, this.genPoly = n.generateECPolynomial(this.degree);
	}, r.prototype.encode = function(e) {
		if (!this.genPoly) throw Error("Encoder not initialized");
		let t = new Uint8Array(e.length + this.degree);
		t.set(e);
		let r = n.mod(t, this.genPoly), i = this.degree - r.length;
		if (i > 0) {
			let e = new Uint8Array(this.degree);
			return e.set(r, i), e;
		}
		return r;
	}, t.exports = r;
})), wn = /* @__PURE__ */ r(((e) => {
	e.isValid = function(e) {
		return !isNaN(e) && e >= 1 && e <= 40;
	};
})), Tn = /* @__PURE__ */ r(((e) => {
	var t = "[0-9]+", n = "[A-Z $%*+\\-./:]+", r = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
	r = r.replace(/u/g, "\\u");
	var i = "(?:(?![A-Z0-9 $%*+\\-./:]|" + r + ")(?:.|[\r\n]))+";
	e.KANJI = new RegExp(r, "g"), e.BYTE_KANJI = /* @__PURE__ */ RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), e.BYTE = new RegExp(i, "g"), e.NUMERIC = new RegExp(t, "g"), e.ALPHANUMERIC = new RegExp(n, "g");
	var a = RegExp("^" + r + "$"), o = /* @__PURE__ */ RegExp("^[0-9]+$"), s = /* @__PURE__ */ RegExp("^[A-Z0-9 $%*+\\-./:]+$");
	e.testKanji = function(e) {
		return a.test(e);
	}, e.testNumeric = function(e) {
		return o.test(e);
	}, e.testAlphanumeric = function(e) {
		return s.test(e);
	};
})), U = /* @__PURE__ */ r(((e) => {
	var t = wn(), n = Tn();
	e.NUMERIC = {
		id: "Numeric",
		bit: 1,
		ccBits: [
			10,
			12,
			14
		]
	}, e.ALPHANUMERIC = {
		id: "Alphanumeric",
		bit: 2,
		ccBits: [
			9,
			11,
			13
		]
	}, e.BYTE = {
		id: "Byte",
		bit: 4,
		ccBits: [
			8,
			16,
			16
		]
	}, e.KANJI = {
		id: "Kanji",
		bit: 8,
		ccBits: [
			8,
			10,
			12
		]
	}, e.MIXED = { bit: -1 }, e.getCharCountIndicator = function(e, n) {
		if (!e.ccBits) throw Error("Invalid mode: " + e);
		if (!t.isValid(n)) throw Error("Invalid version: " + n);
		return n >= 1 && n < 10 ? e.ccBits[0] : n < 27 ? e.ccBits[1] : e.ccBits[2];
	}, e.getBestModeForData = function(t) {
		return n.testNumeric(t) ? e.NUMERIC : n.testAlphanumeric(t) ? e.ALPHANUMERIC : n.testKanji(t) ? e.KANJI : e.BYTE;
	}, e.toString = function(e) {
		if (e && e.id) return e.id;
		throw Error("Invalid mode");
	}, e.isValid = function(e) {
		return e && e.bit && e.ccBits;
	};
	function r(t) {
		if (typeof t != "string") throw Error("Param is not a string");
		switch (t.toLowerCase()) {
			case "numeric": return e.NUMERIC;
			case "alphanumeric": return e.ALPHANUMERIC;
			case "kanji": return e.KANJI;
			case "byte": return e.BYTE;
			default: throw Error("Unknown mode: " + t);
		}
	}
	e.from = function(t, n) {
		if (e.isValid(t)) return t;
		try {
			return r(t);
		} catch {
			return n;
		}
	};
})), En = /* @__PURE__ */ r(((e) => {
	var t = H(), n = bn(), r = mn(), i = U(), a = wn(), o = 7973, s = t.getBCHDigit(o);
	function c(t, n, r) {
		for (let i = 1; i <= 40; i++) if (n <= e.getCapacity(i, r, t)) return i;
	}
	function l(e, t) {
		return i.getCharCountIndicator(e, t) + 4;
	}
	function u(e, t) {
		let n = 0;
		return e.forEach(function(e) {
			let r = l(e.mode, t);
			n += r + e.getBitsLength();
		}), n;
	}
	function d(t, n) {
		for (let r = 1; r <= 40; r++) if (u(t, r) <= e.getCapacity(r, n, i.MIXED)) return r;
	}
	e.from = function(e, t) {
		return a.isValid(e) ? parseInt(e, 10) : t;
	}, e.getCapacity = function(e, r, o) {
		if (!a.isValid(e)) throw Error("Invalid QR Code version");
		o === void 0 && (o = i.BYTE);
		let s = (t.getSymbolTotalCodewords(e) - n.getTotalCodewordsCount(e, r)) * 8;
		if (o === i.MIXED) return s;
		let c = s - l(o, e);
		switch (o) {
			case i.NUMERIC: return Math.floor(c / 10 * 3);
			case i.ALPHANUMERIC: return Math.floor(c / 11 * 2);
			case i.KANJI: return Math.floor(c / 13);
			case i.BYTE:
			default: return Math.floor(c / 8);
		}
	}, e.getBestVersionForData = function(e, t) {
		let n, i = r.from(t, r.M);
		if (Array.isArray(e)) {
			if (e.length > 1) return d(e, i);
			if (e.length === 0) return 1;
			n = e[0];
		} else n = e;
		return c(n.mode, n.getLength(), i);
	}, e.getEncodedBits = function(e) {
		if (!a.isValid(e) || e < 7) throw Error("Invalid QR Code version");
		let n = e << 12;
		for (; t.getBCHDigit(n) - s >= 0;) n ^= o << t.getBCHDigit(n) - s;
		return e << 12 | n;
	};
})), Dn = /* @__PURE__ */ r(((e) => {
	var t = H(), n = 1335, r = 21522, i = t.getBCHDigit(n);
	e.getEncodedBits = function(e, a) {
		let o = e.bit << 3 | a, s = o << 10;
		for (; t.getBCHDigit(s) - i >= 0;) s ^= n << t.getBCHDigit(s) - i;
		return (o << 10 | s) ^ r;
	};
})), On = /* @__PURE__ */ r(((e, t) => {
	var n = U();
	function r(e) {
		this.mode = n.NUMERIC, this.data = e.toString();
	}
	r.getBitsLength = function(e) {
		return 10 * Math.floor(e / 3) + (e % 3 ? e % 3 * 3 + 1 : 0);
	}, r.prototype.getLength = function() {
		return this.data.length;
	}, r.prototype.getBitsLength = function() {
		return r.getBitsLength(this.data.length);
	}, r.prototype.write = function(e) {
		let t, n, r;
		for (t = 0; t + 3 <= this.data.length; t += 3) n = this.data.substr(t, 3), r = parseInt(n, 10), e.put(r, 10);
		let i = this.data.length - t;
		i > 0 && (n = this.data.substr(t), r = parseInt(n, 10), e.put(r, i * 3 + 1));
	}, t.exports = r;
})), kn = /* @__PURE__ */ r(((e, t) => {
	var n = U(), r = /* @__PURE__ */ "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:".split("");
	function i(e) {
		this.mode = n.ALPHANUMERIC, this.data = e;
	}
	i.getBitsLength = function(e) {
		return 11 * Math.floor(e / 2) + e % 2 * 6;
	}, i.prototype.getLength = function() {
		return this.data.length;
	}, i.prototype.getBitsLength = function() {
		return i.getBitsLength(this.data.length);
	}, i.prototype.write = function(e) {
		let t;
		for (t = 0; t + 2 <= this.data.length; t += 2) {
			let n = r.indexOf(this.data[t]) * 45;
			n += r.indexOf(this.data[t + 1]), e.put(n, 11);
		}
		this.data.length % 2 && e.put(r.indexOf(this.data[t]), 6);
	}, t.exports = i;
})), An = /* @__PURE__ */ r(((e, t) => {
	t.exports = function(e) {
		for (var t = [], n = e.length, r = 0; r < n; r++) {
			var i = e.charCodeAt(r);
			if (i >= 55296 && i <= 56319 && n > r + 1) {
				var a = e.charCodeAt(r + 1);
				a >= 56320 && a <= 57343 && (i = (i - 55296) * 1024 + a - 56320 + 65536, r += 1);
			}
			if (i < 128) {
				t.push(i);
				continue;
			}
			if (i < 2048) {
				t.push(i >> 6 | 192), t.push(i & 63 | 128);
				continue;
			}
			if (i < 55296 || i >= 57344 && i < 65536) {
				t.push(i >> 12 | 224), t.push(i >> 6 & 63 | 128), t.push(i & 63 | 128);
				continue;
			}
			if (i >= 65536 && i <= 1114111) {
				t.push(i >> 18 | 240), t.push(i >> 12 & 63 | 128), t.push(i >> 6 & 63 | 128), t.push(i & 63 | 128);
				continue;
			}
			t.push(239, 191, 189);
		}
		return new Uint8Array(t).buffer;
	};
})), jn = /* @__PURE__ */ r(((e, t) => {
	var n = An(), r = U();
	function i(e) {
		this.mode = r.BYTE, typeof e == "string" && (e = n(e)), this.data = new Uint8Array(e);
	}
	i.getBitsLength = function(e) {
		return e * 8;
	}, i.prototype.getLength = function() {
		return this.data.length;
	}, i.prototype.getBitsLength = function() {
		return i.getBitsLength(this.data.length);
	}, i.prototype.write = function(e) {
		for (let t = 0, n = this.data.length; t < n; t++) e.put(this.data[t], 8);
	}, t.exports = i;
})), Mn = /* @__PURE__ */ r(((e, t) => {
	var n = U(), r = H();
	function i(e) {
		this.mode = n.KANJI, this.data = e;
	}
	i.getBitsLength = function(e) {
		return e * 13;
	}, i.prototype.getLength = function() {
		return this.data.length;
	}, i.prototype.getBitsLength = function() {
		return i.getBitsLength(this.data.length);
	}, i.prototype.write = function(e) {
		let t;
		for (t = 0; t < this.data.length; t++) {
			let n = r.toSJIS(this.data[t]);
			if (n >= 33088 && n <= 40956) n -= 33088;
			else if (n >= 57408 && n <= 60351) n -= 49472;
			else throw Error("Invalid SJIS character: " + this.data[t] + "\nMake sure your charset is UTF-8");
			n = (n >>> 8 & 255) * 192 + (n & 255), e.put(n, 13);
		}
	}, t.exports = i;
})), Nn = /* @__PURE__ */ r(((e, t) => {
	var n = {
		single_source_shortest_paths: function(e, t, r) {
			var i = {}, a = {};
			a[t] = 0;
			var o = n.PriorityQueue.make();
			o.push(t, 0);
			for (var s, c, l, u, d, f, p, m, h; !o.empty();) for (l in s = o.pop(), c = s.value, u = s.cost, d = e[c] || {}, d) d.hasOwnProperty(l) && (f = d[l], p = u + f, m = a[l], h = a[l] === void 0, (h || m > p) && (a[l] = p, o.push(l, p), i[l] = c));
			if (r !== void 0 && a[r] === void 0) {
				var g = [
					"Could not find a path from ",
					t,
					" to ",
					r,
					"."
				].join("");
				throw Error(g);
			}
			return i;
		},
		extract_shortest_path_from_predecessor_list: function(e, t) {
			for (var n = [], r = t; r;) n.push(r), e[r], r = e[r];
			return n.reverse(), n;
		},
		find_path: function(e, t, r) {
			var i = n.single_source_shortest_paths(e, t, r);
			return n.extract_shortest_path_from_predecessor_list(i, r);
		},
		PriorityQueue: {
			make: function(e) {
				var t = n.PriorityQueue, r = {}, i;
				for (i in e ||= {}, t) t.hasOwnProperty(i) && (r[i] = t[i]);
				return r.queue = [], r.sorter = e.sorter || t.default_sorter, r;
			},
			default_sorter: function(e, t) {
				return e.cost - t.cost;
			},
			push: function(e, t) {
				var n = {
					value: e,
					cost: t
				};
				this.queue.push(n), this.queue.sort(this.sorter);
			},
			pop: function() {
				return this.queue.shift();
			},
			empty: function() {
				return this.queue.length === 0;
			}
		}
	};
	t !== void 0 && (t.exports = n);
})), Pn = /* @__PURE__ */ r(((e) => {
	var t = U(), n = On(), r = kn(), i = jn(), a = Mn(), o = Tn(), s = H(), c = Nn();
	function l(e) {
		return unescape(encodeURIComponent(e)).length;
	}
	function u(e, t, n) {
		let r = [], i;
		for (; (i = e.exec(n)) !== null;) r.push({
			data: i[0],
			index: i.index,
			mode: t,
			length: i[0].length
		});
		return r;
	}
	function d(e) {
		let n = u(o.NUMERIC, t.NUMERIC, e), r = u(o.ALPHANUMERIC, t.ALPHANUMERIC, e), i, a;
		return s.isKanjiModeEnabled() ? (i = u(o.BYTE, t.BYTE, e), a = u(o.KANJI, t.KANJI, e)) : (i = u(o.BYTE_KANJI, t.BYTE, e), a = []), n.concat(r, i, a).sort(function(e, t) {
			return e.index - t.index;
		}).map(function(e) {
			return {
				data: e.data,
				mode: e.mode,
				length: e.length
			};
		});
	}
	function f(e, o) {
		switch (o) {
			case t.NUMERIC: return n.getBitsLength(e);
			case t.ALPHANUMERIC: return r.getBitsLength(e);
			case t.KANJI: return a.getBitsLength(e);
			case t.BYTE: return i.getBitsLength(e);
		}
	}
	function p(e) {
		return e.reduce(function(e, t) {
			let n = e.length - 1 >= 0 ? e[e.length - 1] : null;
			return n && n.mode === t.mode ? (e[e.length - 1].data += t.data, e) : (e.push(t), e);
		}, []);
	}
	function m(e) {
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r];
			switch (i.mode) {
				case t.NUMERIC:
					n.push([
						i,
						{
							data: i.data,
							mode: t.ALPHANUMERIC,
							length: i.length
						},
						{
							data: i.data,
							mode: t.BYTE,
							length: i.length
						}
					]);
					break;
				case t.ALPHANUMERIC:
					n.push([i, {
						data: i.data,
						mode: t.BYTE,
						length: i.length
					}]);
					break;
				case t.KANJI:
					n.push([i, {
						data: i.data,
						mode: t.BYTE,
						length: l(i.data)
					}]);
					break;
				case t.BYTE: n.push([{
					data: i.data,
					mode: t.BYTE,
					length: l(i.data)
				}]);
			}
		}
		return n;
	}
	function h(e, n) {
		let r = {}, i = { start: {} }, a = ["start"];
		for (let o = 0; o < e.length; o++) {
			let s = e[o], c = [];
			for (let e = 0; e < s.length; e++) {
				let l = s[e], u = "" + o + e;
				c.push(u), r[u] = {
					node: l,
					lastCount: 0
				}, i[u] = {};
				for (let e = 0; e < a.length; e++) {
					let o = a[e];
					r[o] && r[o].node.mode === l.mode ? (i[o][u] = f(r[o].lastCount + l.length, l.mode) - f(r[o].lastCount, l.mode), r[o].lastCount += l.length) : (r[o] && (r[o].lastCount = l.length), i[o][u] = f(l.length, l.mode) + 4 + t.getCharCountIndicator(l.mode, n));
				}
			}
			a = c;
		}
		for (let e = 0; e < a.length; e++) i[a[e]].end = 0;
		return {
			map: i,
			table: r
		};
	}
	function g(e, o) {
		let c, l = t.getBestModeForData(e);
		if (c = t.from(o, l), c !== t.BYTE && c.bit < l.bit) throw Error("\"" + e + "\" cannot be encoded with mode " + t.toString(c) + ".\n Suggested mode is: " + t.toString(l));
		switch (c === t.KANJI && !s.isKanjiModeEnabled() && (c = t.BYTE), c) {
			case t.NUMERIC: return new n(e);
			case t.ALPHANUMERIC: return new r(e);
			case t.KANJI: return new a(e);
			case t.BYTE: return new i(e);
		}
	}
	e.fromArray = function(e) {
		return e.reduce(function(e, t) {
			return typeof t == "string" ? e.push(g(t, null)) : t.data && e.push(g(t.data, t.mode)), e;
		}, []);
	}, e.fromString = function(t, n) {
		let r = h(m(d(t, s.isKanjiModeEnabled())), n), i = c.find_path(r.map, "start", "end"), a = [];
		for (let e = 1; e < i.length - 1; e++) a.push(r.table[i[e]].node);
		return e.fromArray(p(a));
	}, e.rawSplit = function(t) {
		return e.fromArray(d(t, s.isKanjiModeEnabled()));
	};
})), Fn = /* @__PURE__ */ r(((e) => {
	var t = H(), n = mn(), r = hn(), i = gn(), a = _n(), o = vn(), s = yn(), c = bn(), l = Cn(), u = En(), d = Dn(), f = U(), p = Pn();
	function m(e, t) {
		let n = e.size, r = o.getPositions(t);
		for (let t = 0; t < r.length; t++) {
			let i = r[t][0], a = r[t][1];
			for (let t = -1; t <= 7; t++) if (!(i + t <= -1 || n <= i + t)) for (let r = -1; r <= 7; r++) a + r <= -1 || n <= a + r || (t >= 0 && t <= 6 && (r === 0 || r === 6) || r >= 0 && r <= 6 && (t === 0 || t === 6) || t >= 2 && t <= 4 && r >= 2 && r <= 4 ? e.set(i + t, a + r, !0, !0) : e.set(i + t, a + r, !1, !0));
		}
	}
	function h(e) {
		let t = e.size;
		for (let n = 8; n < t - 8; n++) {
			let t = n % 2 == 0;
			e.set(n, 6, t, !0), e.set(6, n, t, !0);
		}
	}
	function g(e, t) {
		let n = a.getPositions(t);
		for (let t = 0; t < n.length; t++) {
			let r = n[t][0], i = n[t][1];
			for (let t = -2; t <= 2; t++) for (let n = -2; n <= 2; n++) t === -2 || t === 2 || n === -2 || n === 2 || t === 0 && n === 0 ? e.set(r + t, i + n, !0, !0) : e.set(r + t, i + n, !1, !0);
		}
	}
	function _(e, t) {
		let n = e.size, r = u.getEncodedBits(t), i, a, o;
		for (let t = 0; t < 18; t++) i = Math.floor(t / 3), a = t % 3 + n - 8 - 3, o = (r >> t & 1) == 1, e.set(i, a, o, !0), e.set(a, i, o, !0);
	}
	function v(e, t, n) {
		let r = e.size, i = d.getEncodedBits(t, n), a, o;
		for (a = 0; a < 15; a++) o = (i >> a & 1) == 1, a < 6 ? e.set(a, 8, o, !0) : a < 8 ? e.set(a + 1, 8, o, !0) : e.set(r - 15 + a, 8, o, !0), a < 8 ? e.set(8, r - a - 1, o, !0) : a < 9 ? e.set(8, 15 - a - 1 + 1, o, !0) : e.set(8, 15 - a - 1, o, !0);
		e.set(r - 8, 8, 1, !0);
	}
	function y(e, t) {
		let n = e.size, r = -1, i = n - 1, a = 7, o = 0;
		for (let s = n - 1; s > 0; s -= 2) for (s === 6 && s--;;) {
			for (let n = 0; n < 2; n++) if (!e.isReserved(i, s - n)) {
				let r = !1;
				o < t.length && (r = (t[o] >>> a & 1) == 1), e.set(i, s - n, r), a--, a === -1 && (o++, a = 7);
			}
			if (i += r, i < 0 || n <= i) {
				i -= r, r = -r;
				break;
			}
		}
	}
	function b(e, n, i) {
		let a = new r();
		i.forEach(function(t) {
			a.put(t.mode.bit, 4), a.put(t.getLength(), f.getCharCountIndicator(t.mode, e)), t.write(a);
		});
		let o = (t.getSymbolTotalCodewords(e) - c.getTotalCodewordsCount(e, n)) * 8;
		for (a.getLengthInBits() + 4 <= o && a.put(0, 4); a.getLengthInBits() % 8 != 0;) a.putBit(0);
		let s = (o - a.getLengthInBits()) / 8;
		for (let e = 0; e < s; e++) a.put(e % 2 ? 17 : 236, 8);
		return x(a, e, n);
	}
	function x(e, n, r) {
		let i = t.getSymbolTotalCodewords(n), a = i - c.getTotalCodewordsCount(n, r), o = c.getBlocksCount(n, r), s = o - i % o, u = Math.floor(i / o), d = Math.floor(a / o), f = d + 1, p = u - d, m = new l(p), h = 0, g = Array(o), _ = Array(o), v = 0, y = new Uint8Array(e.buffer);
		for (let e = 0; e < o; e++) {
			let t = e < s ? d : f;
			g[e] = y.slice(h, h + t), _[e] = m.encode(g[e]), h += t, v = Math.max(v, t);
		}
		let b = new Uint8Array(i), x = 0, S, C;
		for (S = 0; S < v; S++) for (C = 0; C < o; C++) S < g[C].length && (b[x++] = g[C][S]);
		for (S = 0; S < p; S++) for (C = 0; C < o; C++) b[x++] = _[C][S];
		return b;
	}
	function S(e, n, r, a) {
		let o;
		if (Array.isArray(e)) o = p.fromArray(e);
		else if (typeof e == "string") {
			let t = n;
			if (!t) {
				let n = p.rawSplit(e);
				t = u.getBestVersionForData(n, r);
			}
			o = p.fromString(e, t || 40);
		} else throw Error("Invalid data");
		let c = u.getBestVersionForData(o, r);
		if (!c) throw Error("The amount of data is too big to be stored in a QR Code");
		if (!n) n = c;
		else if (n < c) throw Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + c + ".\n");
		let l = b(n, r, o), d = new i(t.getSymbolSize(n));
		return m(d, n), h(d), g(d, n), v(d, r, 0), n >= 7 && _(d, n), y(d, l), isNaN(a) && (a = s.getBestMask(d, v.bind(null, d, r))), s.applyMask(a, d), v(d, r, a), {
			modules: d,
			version: n,
			errorCorrectionLevel: r,
			maskPattern: a,
			segments: o
		};
	}
	e.create = function(e, r) {
		if (e === void 0 || e === "") throw Error("No input text");
		let i = n.M, a, o;
		return r !== void 0 && (i = n.from(r.errorCorrectionLevel, n.M), a = u.from(r.version), o = s.from(r.maskPattern), r.toSJISFunc && t.setToSJISFunction(r.toSJISFunc)), S(e, a, i, o);
	};
})), In = /* @__PURE__ */ r(((e) => {
	function t(e) {
		if (typeof e == "number" && (e = e.toString()), typeof e != "string") throw Error("Color should be defined as hex string");
		let t = e.slice().replace("#", "").split("");
		if (t.length < 3 || t.length === 5 || t.length > 8) throw Error("Invalid hex color: " + e);
		(t.length === 3 || t.length === 4) && (t = Array.prototype.concat.apply([], t.map(function(e) {
			return [e, e];
		}))), t.length === 6 && t.push("F", "F");
		let n = parseInt(t.join(""), 16);
		return {
			r: n >> 24 & 255,
			g: n >> 16 & 255,
			b: n >> 8 & 255,
			a: n & 255,
			hex: "#" + t.slice(0, 6).join("")
		};
	}
	e.getOptions = function(e) {
		e ||= {}, e.color ||= {};
		let n = e.margin === void 0 || e.margin === null || e.margin < 0 ? 4 : e.margin, r = e.width && e.width >= 21 ? e.width : void 0, i = e.scale || 4;
		return {
			width: r,
			scale: r ? 4 : i,
			margin: n,
			color: {
				dark: t(e.color.dark || "#000000ff"),
				light: t(e.color.light || "#ffffffff")
			},
			type: e.type,
			rendererOpts: e.rendererOpts || {}
		};
	}, e.getScale = function(e, t) {
		return t.width && t.width >= e + t.margin * 2 ? t.width / (e + t.margin * 2) : t.scale;
	}, e.getImageWidth = function(t, n) {
		let r = e.getScale(t, n);
		return Math.floor((t + n.margin * 2) * r);
	}, e.qrToImageData = function(t, n, r) {
		let i = n.modules.size, a = n.modules.data, o = e.getScale(i, r), s = Math.floor((i + r.margin * 2) * o), c = r.margin * o, l = [r.color.light, r.color.dark];
		for (let e = 0; e < s; e++) for (let n = 0; n < s; n++) {
			let u = (e * s + n) * 4, d = r.color.light;
			if (e >= c && n >= c && e < s - c && n < s - c) {
				let t = Math.floor((e - c) / o), r = Math.floor((n - c) / o);
				d = l[+!!a[t * i + r]];
			}
			t[u++] = d.r, t[u++] = d.g, t[u++] = d.b, t[u] = d.a;
		}
	};
})), Ln = /* @__PURE__ */ r(((e) => {
	var t = In();
	function n(e, t, n) {
		e.clearRect(0, 0, t.width, t.height), t.style ||= {}, t.height = n, t.width = n, t.style.height = n + "px", t.style.width = n + "px";
	}
	function r() {
		try {
			return document.createElement("canvas");
		} catch {
			throw Error("You need to specify a canvas element");
		}
	}
	e.render = function(e, i, a) {
		let o = a, s = i;
		o === void 0 && (!i || !i.getContext) && (o = i, i = void 0), i || (s = r()), o = t.getOptions(o);
		let c = t.getImageWidth(e.modules.size, o), l = s.getContext("2d"), u = l.createImageData(c, c);
		return t.qrToImageData(u.data, e, o), n(l, s, c), l.putImageData(u, 0, 0), s;
	}, e.renderToDataURL = function(t, n, r) {
		let i = r;
		i === void 0 && (!n || !n.getContext) && (i = n, n = void 0), i ||= {};
		let a = e.render(t, n, i), o = i.type || "image/png", s = i.rendererOpts || {};
		return a.toDataURL(o, s.quality);
	};
})), Rn = /* @__PURE__ */ r(((e) => {
	var t = In();
	function n(e, t) {
		let n = e.a / 255, r = t + "=\"" + e.hex + "\"";
		return n < 1 ? r + " " + t + "-opacity=\"" + n.toFixed(2).slice(1) + "\"" : r;
	}
	function r(e, t, n) {
		let r = e + t;
		return n !== void 0 && (r += " " + n), r;
	}
	function i(e, t, n) {
		let i = "", a = 0, o = !1, s = 0;
		for (let c = 0; c < e.length; c++) {
			let l = Math.floor(c % t), u = Math.floor(c / t);
			!l && !o && (o = !0), e[c] ? (s++, c > 0 && l > 0 && e[c - 1] || (i += o ? r("M", l + n, .5 + u + n) : r("m", a, 0), a = 0, o = !1), l + 1 < t && e[c + 1] || (i += r("h", s), s = 0)) : a++;
		}
		return i;
	}
	e.render = function(e, r, a) {
		let o = t.getOptions(r), s = e.modules.size, c = e.modules.data, l = s + o.margin * 2, u = o.color.light.a ? "<path " + n(o.color.light, "fill") + " d=\"M0 0h" + l + "v" + l + "H0z\"/>" : "", d = "<path " + n(o.color.dark, "stroke") + " d=\"" + i(c, s, o.margin) + "\"/>", f = "viewBox=\"0 0 " + l + " " + l + "\"", p = "<svg xmlns=\"http://www.w3.org/2000/svg\" " + (o.width ? "width=\"" + o.width + "\" height=\"" + o.width + "\" " : "") + f + " shape-rendering=\"crispEdges\">" + u + d + "</svg>\n";
		return typeof a == "function" && a(null, p), p;
	};
})), zn = /* @__PURE__ */ e((/* @__PURE__ */ r(((e) => {
	var t = pn(), n = Fn(), r = Ln(), i = Rn();
	function a(e, r, i, a, o) {
		let s = [].slice.call(arguments, 1), c = s.length, l = typeof s[c - 1] == "function";
		if (!l && !t()) throw Error("Callback required as last argument");
		if (l) {
			if (c < 2) throw Error("Too few arguments provided");
			c === 2 ? (o = i, i = r, r = a = void 0) : c === 3 && (r.getContext && o === void 0 ? (o = a, a = void 0) : (o = a, a = i, i = r, r = void 0));
		} else {
			if (c < 1) throw Error("Too few arguments provided");
			return c === 1 ? (i = r, r = a = void 0) : c === 2 && !r.getContext && (a = i, i = r, r = void 0), new Promise(function(t, o) {
				try {
					t(e(n.create(i, a), r, a));
				} catch (e) {
					o(e);
				}
			});
		}
		try {
			let t = n.create(i, a);
			o(null, e(t, r, a));
		} catch (e) {
			o(e);
		}
	}
	e.create = n.create, e.toCanvas = a.bind(null, r.render), e.toDataURL = a.bind(null, r.renderToDataURL), e.toString = a.bind(null, function(e, t, n) {
		return i.render(e, n);
	});
})))(), 1), Bn = Object.defineProperty, Vn = Object.getOwnPropertySymbols, Hn = Object.prototype.hasOwnProperty, Un = Object.prototype.propertyIsEnumerable, Wn = (e, t, n) => t in e ? Bn(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, Gn = (e, t) => {
	for (var n in t ||= {}) Hn.call(t, n) && Wn(e, n, t[n]);
	if (Vn) for (var n of Vn(t)) Un.call(t, n) && Wn(e, n, t[n]);
	return e;
};
function Kn() {
	let e = {
		light: {
			foreground: {
				1: "rgb(20,20,20)",
				2: "rgb(121,134,134)",
				3: "rgb(158,169,169)"
			},
			background: {
				1: "rgb(255,255,255)",
				2: "rgb(241,243,243)",
				3: "rgb(228,231,231)"
			},
			overlay: "rgba(0,0,0,0.1)"
		},
		dark: {
			foreground: {
				1: "rgb(228,231,231)",
				2: "rgb(148,158,158)",
				3: "rgb(110,119,119)"
			},
			background: {
				1: "rgb(20,20,20)",
				2: "rgb(39,42,42)",
				3: "rgb(59,64,64)"
			},
			overlay: "rgba(255,255,255,0.1)"
		}
	}[n.state.themeMode ?? "dark"];
	return {
		"--wcm-color-fg-1": e.foreground[1],
		"--wcm-color-fg-2": e.foreground[2],
		"--wcm-color-fg-3": e.foreground[3],
		"--wcm-color-bg-1": e.background[1],
		"--wcm-color-bg-2": e.background[2],
		"--wcm-color-bg-3": e.background[3],
		"--wcm-color-overlay": e.overlay
	};
}
function qn() {
	return {
		"--wcm-accent-color": "#3396FF",
		"--wcm-accent-fill-color": "#FFFFFF",
		"--wcm-z-index": "89",
		"--wcm-background-color": "#3396FF",
		"--wcm-background-border-radius": "8px",
		"--wcm-container-border-radius": "30px",
		"--wcm-wallet-icon-border-radius": "15px",
		"--wcm-wallet-icon-large-border-radius": "30px",
		"--wcm-wallet-icon-small-border-radius": "7px",
		"--wcm-input-border-radius": "28px",
		"--wcm-button-border-radius": "10px",
		"--wcm-notification-border-radius": "36px",
		"--wcm-secondary-button-border-radius": "28px",
		"--wcm-icon-button-border-radius": "50%",
		"--wcm-button-hover-highlight-border-radius": "10px",
		"--wcm-text-big-bold-size": "20px",
		"--wcm-text-big-bold-weight": "600",
		"--wcm-text-big-bold-line-height": "24px",
		"--wcm-text-big-bold-letter-spacing": "-0.03em",
		"--wcm-text-big-bold-text-transform": "none",
		"--wcm-text-xsmall-bold-size": "10px",
		"--wcm-text-xsmall-bold-weight": "700",
		"--wcm-text-xsmall-bold-line-height": "12px",
		"--wcm-text-xsmall-bold-letter-spacing": "0.02em",
		"--wcm-text-xsmall-bold-text-transform": "uppercase",
		"--wcm-text-xsmall-regular-size": "12px",
		"--wcm-text-xsmall-regular-weight": "600",
		"--wcm-text-xsmall-regular-line-height": "14px",
		"--wcm-text-xsmall-regular-letter-spacing": "-0.03em",
		"--wcm-text-xsmall-regular-text-transform": "none",
		"--wcm-text-small-thin-size": "14px",
		"--wcm-text-small-thin-weight": "500",
		"--wcm-text-small-thin-line-height": "16px",
		"--wcm-text-small-thin-letter-spacing": "-0.03em",
		"--wcm-text-small-thin-text-transform": "none",
		"--wcm-text-small-regular-size": "14px",
		"--wcm-text-small-regular-weight": "600",
		"--wcm-text-small-regular-line-height": "16px",
		"--wcm-text-small-regular-letter-spacing": "-0.03em",
		"--wcm-text-small-regular-text-transform": "none",
		"--wcm-text-medium-regular-size": "16px",
		"--wcm-text-medium-regular-weight": "600",
		"--wcm-text-medium-regular-line-height": "20px",
		"--wcm-text-medium-regular-letter-spacing": "-0.03em",
		"--wcm-text-medium-regular-text-transform": "none",
		"--wcm-font-family": "-apple-system, system-ui, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', sans-serif",
		"--wcm-font-feature-settings": "'tnum' on, 'lnum' on, 'case' on",
		"--wcm-success-color": "rgb(38,181,98)",
		"--wcm-error-color": "rgb(242, 90, 103)",
		"--wcm-overlay-background-color": "rgba(0, 0, 0, 0.3)",
		"--wcm-overlay-backdrop-filter": "none"
	};
}
var W = {
	getPreset(e) {
		return qn()[e];
	},
	setTheme() {
		let e = document.querySelector(":root"), { themeVariables: t } = n.state;
		if (e) {
			let n = Gn(Gn(Gn({}, Kn()), qn()), t);
			Object.entries(n).forEach(([t, n]) => e.style.setProperty(t, n));
		}
	},
	globalCss: _`*,::after,::before{margin:0;padding:0;box-sizing:border-box;font-style:normal;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;-webkit-tap-highlight-color:transparent;backface-visibility:hidden}button{cursor:pointer;display:flex;justify-content:center;align-items:center;position:relative;border:none;background-color:transparent;transition:all .2s ease}@media (hover:hover) and (pointer:fine){button:active{transition:all .1s ease;transform:scale(.93)}}button::after{content:'';position:absolute;top:0;bottom:0;left:0;right:0;transition:background-color,.2s ease}button:disabled{cursor:not-allowed}button svg,button wcm-text{position:relative;z-index:1}input{border:none;outline:0;appearance:none}img{display:block}::selection{color:var(--wcm-accent-fill-color);background:var(--wcm-accent-color)}`
}, Jn = _`button{border-radius:var(--wcm-secondary-button-border-radius);height:28px;padding:0 10px;background-color:var(--wcm-accent-color)}button path{fill:var(--wcm-accent-fill-color)}button::after{border-radius:inherit;border:1px solid var(--wcm-color-overlay)}button:disabled::after{background-color:transparent}.wcm-icon-left svg{margin-right:5px}.wcm-icon-right svg{margin-left:5px}button:active::after{background-color:var(--wcm-color-overlay)}.wcm-ghost,.wcm-ghost:active::after,.wcm-outline{background-color:transparent}.wcm-ghost:active{opacity:.5}@media(hover:hover){button:hover::after{background-color:var(--wcm-color-overlay)}.wcm-ghost:hover::after{background-color:transparent}.wcm-ghost:hover{opacity:.5}}button:disabled{background-color:var(--wcm-color-bg-3);pointer-events:none}.wcm-ghost::after{border-color:transparent}.wcm-ghost path{fill:var(--wcm-color-fg-2)}.wcm-outline path{fill:var(--wcm-accent-color)}.wcm-outline:disabled{background-color:transparent;opacity:.5}`, Yn = Object.defineProperty, Xn = Object.getOwnPropertyDescriptor, Zn = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Xn(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Yn(t, n, i), i;
}, G = class extends N {
	constructor() {
		super(...arguments), this.disabled = !1, this.iconLeft = void 0, this.iconRight = void 0, this.onClick = () => null, this.variant = "default";
	}
	render() {
		let e = {
			"wcm-icon-left": this.iconLeft !== void 0,
			"wcm-icon-right": this.iconRight !== void 0,
			"wcm-ghost": this.variant === "ghost",
			"wcm-outline": this.variant === "outline"
		}, t = "inverse";
		return this.variant === "ghost" && (t = "secondary"), this.variant === "outline" && (t = "accent"), O`<button class="${L(e)}" ?disabled="${this.disabled}" @click="${this.onClick}">${this.iconLeft}<wcm-text variant="small-regular" color="${t}"><slot></slot></wcm-text>${this.iconRight}</button>`;
	}
};
G.styles = [W.globalCss, Jn], Zn([F({ type: Boolean })], G.prototype, "disabled", 2), Zn([F()], G.prototype, "iconLeft", 2), Zn([F()], G.prototype, "iconRight", 2), Zn([F()], G.prototype, "onClick", 2), Zn([F()], G.prototype, "variant", 2), G = Zn([P("wcm-button")], G);
var Qn = _`:host{display:inline-block}button{padding:0 15px 1px;height:40px;border-radius:var(--wcm-button-border-radius);color:var(--wcm-accent-fill-color);background-color:var(--wcm-accent-color)}button::after{content:'';top:0;bottom:0;left:0;right:0;position:absolute;background-color:transparent;border-radius:inherit;transition:background-color .2s ease;border:1px solid var(--wcm-color-overlay)}button:active::after{background-color:var(--wcm-color-overlay)}button:disabled{padding-bottom:0;background-color:var(--wcm-color-bg-3);color:var(--wcm-color-fg-3)}.wcm-secondary{color:var(--wcm-accent-color);background-color:transparent}.wcm-secondary::after{display:none}@media(hover:hover){button:hover::after{background-color:var(--wcm-color-overlay)}}`, $n = Object.defineProperty, er = Object.getOwnPropertyDescriptor, tr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? er(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && $n(t, n, i), i;
}, nr = class extends N {
	constructor() {
		super(...arguments), this.disabled = !1, this.variant = "primary";
	}
	render() {
		let e = { "wcm-secondary": this.variant === "secondary" };
		return O`<button ?disabled="${this.disabled}" class="${L(e)}"><slot></slot></button>`;
	}
};
nr.styles = [W.globalCss, Qn], tr([F({ type: Boolean })], nr.prototype, "disabled", 2), tr([F()], nr.prototype, "variant", 2), nr = tr([P("wcm-button-big")], nr);
var rr = _`:host{background-color:var(--wcm-color-bg-2);border-top:1px solid var(--wcm-color-bg-3)}div{padding:10px 20px;display:inherit;flex-direction:inherit;align-items:inherit;width:inherit;justify-content:inherit}`, ir = Object.defineProperty, ar = Object.getOwnPropertyDescriptor, or = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ar(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && ir(t, n, i), i;
}, sr = class extends N {
	render() {
		return O`<div><slot></slot></div>`;
	}
};
sr.styles = [W.globalCss, rr], sr = or([P("wcm-info-footer")], sr);
var K = {
	CROSS_ICON: k`<svg width="12" height="12" viewBox="0 0 12 12"><path d="M9.94 11A.75.75 0 1 0 11 9.94L7.414 6.353a.5.5 0 0 1 0-.708L11 2.061A.75.75 0 1 0 9.94 1L6.353 4.586a.5.5 0 0 1-.708 0L2.061 1A.75.75 0 0 0 1 2.06l3.586 3.586a.5.5 0 0 1 0 .708L1 9.939A.75.75 0 1 0 2.06 11l3.586-3.586a.5.5 0 0 1 .708 0L9.939 11Z" fill="#fff"/></svg>`,
	WALLET_CONNECT_LOGO: k`<svg width="178" height="29" viewBox="0 0 178 29" id="wcm-wc-logo"><path d="M10.683 7.926c5.284-5.17 13.85-5.17 19.134 0l.636.623a.652.652 0 0 1 0 .936l-2.176 2.129a.343.343 0 0 1-.478 0l-.875-.857c-3.686-3.607-9.662-3.607-13.348 0l-.937.918a.343.343 0 0 1-.479 0l-2.175-2.13a.652.652 0 0 1 0-.936l.698-.683Zm23.633 4.403 1.935 1.895a.652.652 0 0 1 0 .936l-8.73 8.543a.687.687 0 0 1-.956 0L20.37 17.64a.172.172 0 0 0-.239 0l-6.195 6.063a.687.687 0 0 1-.957 0l-8.73-8.543a.652.652 0 0 1 0-.936l1.936-1.895a.687.687 0 0 1 .957 0l6.196 6.064a.172.172 0 0 0 .239 0l6.195-6.064a.687.687 0 0 1 .957 0l6.196 6.064a.172.172 0 0 0 .24 0l6.195-6.064a.687.687 0 0 1 .956 0ZM48.093 20.948l2.338-9.355c.139-.515.258-1.07.416-1.942.12.872.258 1.427.357 1.942l2.022 9.355h4.181l3.528-13.874h-3.21l-1.943 8.523a24.825 24.825 0 0 0-.456 2.457c-.158-.931-.317-1.625-.495-2.438l-1.883-8.542h-4.201l-2.042 8.542a41.204 41.204 0 0 0-.475 2.438 41.208 41.208 0 0 0-.476-2.438l-1.903-8.542h-3.349l3.508 13.874h4.083ZM63.33 21.304c1.585 0 2.596-.654 3.11-1.605-.059.297-.078.595-.078.892v.357h2.655V15.22c0-2.735-1.248-4.32-4.3-4.32-2.636 0-4.36 1.466-4.52 3.487h2.914c.1-.891.734-1.426 1.705-1.426.911 0 1.407.515 1.407 1.11 0 .435-.258.693-1.03.792l-1.388.159c-2.061.257-3.825 1.01-3.825 3.19 0 1.982 1.645 3.092 3.35 3.092Zm.891-2.041c-.773 0-1.348-.436-1.348-1.19 0-.733.655-1.09 1.645-1.268l.674-.119c.575-.118.892-.218 1.09-.396v.912c0 1.228-.892 2.06-2.06 2.06ZM70.398 7.074v13.874h2.874V7.074h-2.874ZM74.934 7.074v13.874h2.874V7.074h-2.874ZM84.08 21.304c2.735 0 4.5-1.546 4.697-3.567h-2.893c-.139.892-.892 1.387-1.804 1.387-1.228 0-2.12-.99-2.14-2.358h6.897v-.555c0-3.21-1.764-5.312-4.816-5.312-2.933 0-4.994 2.062-4.994 5.173 0 3.37 2.12 5.232 5.053 5.232Zm-2.16-6.421c.119-1.11.932-1.922 2.081-1.922 1.11 0 1.883.772 1.903 1.922H81.92ZM94.92 21.146c.633 0 1.248-.1 1.525-.179v-2.18c-.218.04-.475.06-.693.06-1.05 0-1.427-.595-1.427-1.566v-3.805h2.338v-2.24h-2.338V7.788H91.47v3.448H89.37v2.24h2.1v4.201c0 2.3 1.15 3.469 3.45 3.469ZM104.62 21.304c3.924 0 6.302-2.299 6.599-5.608h-3.111c-.238 1.803-1.506 3.032-3.369 3.032-2.2 0-3.746-1.784-3.746-4.796 0-2.953 1.605-4.638 3.805-4.638 1.883 0 2.953 1.15 3.171 2.834h3.191c-.317-3.448-2.854-5.41-6.342-5.41-3.984 0-7.036 2.695-7.036 7.214 0 4.677 2.676 7.372 6.838 7.372ZM117.449 21.304c2.993 0 5.114-1.882 5.114-5.172 0-3.23-2.121-5.233-5.114-5.233-2.972 0-5.093 2.002-5.093 5.233 0 3.29 2.101 5.172 5.093 5.172Zm0-2.22c-1.327 0-2.18-1.09-2.18-2.952 0-1.903.892-2.973 2.18-2.973 1.308 0 2.2 1.07 2.2 2.973 0 1.862-.872 2.953-2.2 2.953ZM126.569 20.948v-5.689c0-1.208.753-2.1 1.823-2.1 1.011 0 1.606.773 1.606 2.06v5.729h2.873v-6.144c0-2.339-1.229-3.905-3.428-3.905-1.526 0-2.458.734-2.953 1.606a5.31 5.31 0 0 0 .079-.892v-.377h-2.874v9.712h2.874ZM137.464 20.948v-5.689c0-1.208.753-2.1 1.823-2.1 1.011 0 1.606.773 1.606 2.06v5.729h2.873v-6.144c0-2.339-1.228-3.905-3.428-3.905-1.526 0-2.458.734-2.953 1.606a5.31 5.31 0 0 0 .079-.892v-.377h-2.874v9.712h2.874ZM149.949 21.304c2.735 0 4.499-1.546 4.697-3.567h-2.893c-.139.892-.892 1.387-1.804 1.387-1.228 0-2.12-.99-2.14-2.358h6.897v-.555c0-3.21-1.764-5.312-4.816-5.312-2.933 0-4.994 2.062-4.994 5.173 0 3.37 2.12 5.232 5.053 5.232Zm-2.16-6.421c.119-1.11.932-1.922 2.081-1.922 1.11 0 1.883.772 1.903 1.922h-3.984ZM160.876 21.304c3.013 0 4.658-1.645 4.975-4.201h-2.874c-.099 1.07-.713 1.982-2.001 1.982-1.309 0-2.2-1.21-2.2-2.993 0-1.942 1.03-2.933 2.259-2.933 1.209 0 1.803.872 1.883 1.882h2.873c-.218-2.358-1.823-4.142-4.776-4.142-2.874 0-5.153 1.903-5.153 5.193 0 3.25 1.923 5.212 5.014 5.212ZM172.067 21.146c.634 0 1.248-.1 1.526-.179v-2.18c-.218.04-.476.06-.694.06-1.05 0-1.427-.595-1.427-1.566v-3.805h2.339v-2.24h-2.339V7.788h-2.854v3.448h-2.1v2.24h2.1v4.201c0 2.3 1.15 3.469 3.449 3.469Z" fill="#fff"/></svg>`,
	WALLET_CONNECT_ICON: k`<svg width="28" height="20" viewBox="0 0 28 20"><g clip-path="url(#a)"><path d="M7.386 6.482c3.653-3.576 9.575-3.576 13.228 0l.44.43a.451.451 0 0 1 0 .648L19.55 9.033a.237.237 0 0 1-.33 0l-.606-.592c-2.548-2.496-6.68-2.496-9.228 0l-.648.634a.237.237 0 0 1-.33 0L6.902 7.602a.451.451 0 0 1 0-.647l.483-.473Zm16.338 3.046 1.339 1.31a.451.451 0 0 1 0 .648l-6.035 5.909a.475.475 0 0 1-.662 0L14.083 13.2a.119.119 0 0 0-.166 0l-4.283 4.194a.475.475 0 0 1-.662 0l-6.035-5.91a.451.451 0 0 1 0-.647l1.338-1.31a.475.475 0 0 1 .662 0l4.283 4.194c.046.044.12.044.166 0l4.283-4.194a.475.475 0 0 1 .662 0l4.283 4.194c.046.044.12.044.166 0l4.283-4.194a.475.475 0 0 1 .662 0Z" fill="#000000"/></g><defs><clipPath id="a"><path fill="#ffffff" d="M0 0h28v20H0z"/></clipPath></defs></svg>`,
	WALLET_CONNECT_ICON_COLORED: k`<svg width="96" height="96" fill="none"><path fill="#fff" d="M25.322 33.597c12.525-12.263 32.83-12.263 45.355 0l1.507 1.476a1.547 1.547 0 0 1 0 2.22l-5.156 5.048a.814.814 0 0 1-1.134 0l-2.074-2.03c-8.737-8.555-22.903-8.555-31.64 0l-2.222 2.175a.814.814 0 0 1-1.134 0l-5.156-5.049a1.547 1.547 0 0 1 0-2.22l1.654-1.62Zm56.019 10.44 4.589 4.494a1.547 1.547 0 0 1 0 2.22l-20.693 20.26a1.628 1.628 0 0 1-2.267 0L48.283 56.632a.407.407 0 0 0-.567 0L33.03 71.012a1.628 1.628 0 0 1-2.268 0L10.07 50.75a1.547 1.547 0 0 1 0-2.22l4.59-4.494a1.628 1.628 0 0 1 2.267 0l14.687 14.38c.156.153.41.153.567 0l14.685-14.38a1.628 1.628 0 0 1 2.268 0l14.687 14.38c.156.153.41.153.567 0l14.686-14.38a1.628 1.628 0 0 1 2.268 0Z"/><path stroke="#000" d="M25.672 33.954c12.33-12.072 32.325-12.072 44.655 0l1.508 1.476a1.047 1.047 0 0 1 0 1.506l-5.157 5.048a.314.314 0 0 1-.434 0l-2.074-2.03c-8.932-8.746-23.409-8.746-32.34 0l-2.222 2.174a.314.314 0 0 1-.434 0l-5.157-5.048a1.047 1.047 0 0 1 0-1.506l1.655-1.62Zm55.319 10.44 4.59 4.494a1.047 1.047 0 0 1 0 1.506l-20.694 20.26a1.128 1.128 0 0 1-1.568 0l-14.686-14.38a.907.907 0 0 0-1.267 0L32.68 70.655a1.128 1.128 0 0 1-1.568 0L10.42 50.394a1.047 1.047 0 0 1 0-1.506l4.59-4.493a1.128 1.128 0 0 1 1.567 0l14.687 14.379a.907.907 0 0 0 1.266 0l-.35-.357.35.357 14.686-14.38a1.128 1.128 0 0 1 1.568 0l14.687 14.38a.907.907 0 0 0 1.267 0l14.686-14.38a1.128 1.128 0 0 1 1.568 0Z"/></svg>`,
	BACK_ICON: k`<svg width="10" height="18" viewBox="0 0 10 18"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.735.179a.75.75 0 0 1 .087 1.057L2.92 8.192a1.25 1.25 0 0 0 0 1.617l5.902 6.956a.75.75 0 1 1-1.144.97L1.776 10.78a2.75 2.75 0 0 1 0-3.559L7.678.265A.75.75 0 0 1 8.735.18Z" fill="#fff"/></svg>`,
	COPY_ICON: k`<svg width="24" height="24" fill="none"><path fill="#fff" fill-rule="evenodd" d="M7.01 7.01c.03-1.545.138-2.5.535-3.28A5 5 0 0 1 9.73 1.545C10.8 1 12.2 1 15 1c2.8 0 4.2 0 5.27.545a5 5 0 0 1 2.185 2.185C23 4.8 23 6.2 23 9c0 2.8 0 4.2-.545 5.27a5 5 0 0 1-2.185 2.185c-.78.397-1.735.505-3.28.534l-.001.01c-.03 1.54-.138 2.493-.534 3.27a5 5 0 0 1-2.185 2.186C13.2 23 11.8 23 9 23c-2.8 0-4.2 0-5.27-.545a5 5 0 0 1-2.185-2.185C1 19.2 1 17.8 1 15c0-2.8 0-4.2.545-5.27A5 5 0 0 1 3.73 7.545C4.508 7.149 5.46 7.04 7 7.01h.01ZM15 15.5c-1.425 0-2.403-.001-3.162-.063-.74-.06-1.139-.172-1.427-.319a3.5 3.5 0 0 1-1.53-1.529c-.146-.288-.257-.686-.318-1.427C8.501 11.403 8.5 10.425 8.5 9c0-1.425.001-2.403.063-3.162.06-.74.172-1.139.318-1.427a3.5 3.5 0 0 1 1.53-1.53c.288-.146.686-.257 1.427-.318.759-.062 1.737-.063 3.162-.063 1.425 0 2.403.001 3.162.063.74.06 1.139.172 1.427.318a3.5 3.5 0 0 1 1.53 1.53c.146.288.257.686.318 1.427.062.759.063 1.737.063 3.162 0 1.425-.001 2.403-.063 3.162-.06.74-.172 1.139-.319 1.427a3.5 3.5 0 0 1-1.529 1.53c-.288.146-.686.257-1.427.318-.759.062-1.737.063-3.162.063ZM7 8.511c-.444.009-.825.025-1.162.052-.74.06-1.139.172-1.427.318a3.5 3.5 0 0 0-1.53 1.53c-.146.288-.257.686-.318 1.427-.062.759-.063 1.737-.063 3.162 0 1.425.001 2.403.063 3.162.06.74.172 1.139.318 1.427a3.5 3.5 0 0 0 1.53 1.53c.288.146.686.257 1.427.318.759.062 1.737.063 3.162.063 1.425 0 2.403-.001 3.162-.063.74-.06 1.139-.172 1.427-.319a3.5 3.5 0 0 0 1.53-1.53c.146-.287.257-.685.318-1.426.027-.337.043-.718.052-1.162H15c-2.8 0-4.2 0-5.27-.545a5 5 0 0 1-2.185-2.185C7 13.2 7 11.8 7 9v-.489Z" clip-rule="evenodd"/></svg>`,
	RETRY_ICON: k`<svg width="15" height="16" viewBox="0 0 15 16"><path d="M6.464 2.03A.75.75 0 0 0 5.403.97L2.08 4.293a1 1 0 0 0 0 1.414L5.403 9.03a.75.75 0 0 0 1.06-1.06L4.672 6.177a.25.25 0 0 1 .177-.427h2.085a4 4 0 1 1-3.93 4.746c-.077-.407-.405-.746-.82-.746-.414 0-.755.338-.7.748a5.501 5.501 0 1 0 5.45-6.248H4.848a.25.25 0 0 1-.177-.427L6.464 2.03Z" fill="#fff"/></svg>`,
	DESKTOP_ICON: k`<svg width="16" height="16" viewBox="0 0 16 16"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 5.98c0-1.85 0-2.775.394-3.466a3 3 0 0 1 1.12-1.12C2.204 1 3.13 1 4.98 1h6.04c1.85 0 2.775 0 3.466.394a3 3 0 0 1 1.12 1.12C16 3.204 16 4.13 16 5.98v1.04c0 1.85 0 2.775-.394 3.466a3 3 0 0 1-1.12 1.12C13.796 12 12.87 12 11.02 12H4.98c-1.85 0-2.775 0-3.466-.394a3 3 0 0 1-1.12-1.12C0 9.796 0 8.87 0 7.02V5.98ZM4.98 2.5h6.04c.953 0 1.568.001 2.034.043.446.04.608.108.69.154a1.5 1.5 0 0 1 .559.56c.046.08.114.243.154.69.042.465.043 1.08.043 2.033v1.04c0 .952-.001 1.568-.043 2.034-.04.446-.108.608-.154.69a1.499 1.499 0 0 1-.56.559c-.08.046-.243.114-.69.154-.466.042-1.08.043-2.033.043H4.98c-.952 0-1.568-.001-2.034-.043-.446-.04-.608-.108-.69-.154a1.5 1.5 0 0 1-.559-.56c-.046-.08-.114-.243-.154-.69-.042-.465-.043-1.08-.043-2.033V5.98c0-.952.001-1.568.043-2.034.04-.446.108-.608.154-.69a1.5 1.5 0 0 1 .56-.559c.08-.046.243-.114.69-.154.465-.042 1.08-.043 2.033-.043Z" fill="#fff"/><path d="M4 14.25a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5a.75.75 0 0 1-.75-.75Z" fill="#fff"/></svg>`,
	MOBILE_ICON: k`<svg width="16" height="16" viewBox="0 0 16 16"><path d="M6.75 5a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z" fill="#fff"/><path fill-rule="evenodd" clip-rule="evenodd" d="M3 4.98c0-1.85 0-2.775.394-3.466a3 3 0 0 1 1.12-1.12C5.204 0 6.136 0 8 0s2.795 0 3.486.394a3 3 0 0 1 1.12 1.12C13 2.204 13 3.13 13 4.98v6.04c0 1.85 0 2.775-.394 3.466a3 3 0 0 1-1.12 1.12C10.796 16 9.864 16 8 16s-2.795 0-3.486-.394a3 3 0 0 1-1.12-1.12C3 13.796 3 12.87 3 11.02V4.98Zm8.5 0v6.04c0 .953-.001 1.568-.043 2.034-.04.446-.108.608-.154.69a1.499 1.499 0 0 1-.56.559c-.08.045-.242.113-.693.154-.47.042-1.091.043-2.05.043-.959 0-1.58-.001-2.05-.043-.45-.04-.613-.109-.693-.154a1.5 1.5 0 0 1-.56-.56c-.046-.08-.114-.243-.154-.69-.042-.466-.043-1.08-.043-2.033V4.98c0-.952.001-1.568.043-2.034.04-.446.108-.608.154-.69a1.5 1.5 0 0 1 .56-.559c.08-.045.243-.113.693-.154C6.42 1.501 7.041 1.5 8 1.5c.959 0 1.58.001 2.05.043.45.04.613.109.693.154a1.5 1.5 0 0 1 .56.56c.046.08.114.243.154.69.042.465.043 1.08.043 2.033Z" fill="#fff"/></svg>`,
	ARROW_DOWN_ICON: k`<svg width="14" height="14" viewBox="0 0 14 14"><path d="M2.28 7.47a.75.75 0 0 0-1.06 1.06l5.25 5.25a.75.75 0 0 0 1.06 0l5.25-5.25a.75.75 0 0 0-1.06-1.06l-3.544 3.543a.25.25 0 0 1-.426-.177V.75a.75.75 0 0 0-1.5 0v10.086a.25.25 0 0 1-.427.176L2.28 7.47Z" fill="#fff"/></svg>`,
	ARROW_UP_RIGHT_ICON: k`<svg width="15" height="14" fill="none"><path d="M4.5 1.75A.75.75 0 0 1 5.25 1H12a1.5 1.5 0 0 1 1.5 1.5v6.75a.75.75 0 0 1-1.5 0V4.164a.25.25 0 0 0-.427-.176L4.061 11.5A.75.75 0 0 1 3 10.44l7.513-7.513a.25.25 0 0 0-.177-.427H5.25a.75.75 0 0 1-.75-.75Z" fill="#fff"/></svg>`,
	ARROW_RIGHT_ICON: k`<svg width="6" height="14" viewBox="0 0 6 14"><path fill-rule="evenodd" clip-rule="evenodd" d="M2.181 1.099a.75.75 0 0 1 1.024.279l2.433 4.258a2.75 2.75 0 0 1 0 2.729l-2.433 4.257a.75.75 0 1 1-1.303-.744L4.335 7.62a1.25 1.25 0 0 0 0-1.24L1.902 2.122a.75.75 0 0 1 .28-1.023Z" fill="#fff"/></svg>`,
	QRCODE_ICON: k`<svg width="25" height="24" viewBox="0 0 25 24"><path d="M23.748 9a.748.748 0 0 0 .748-.752c-.018-2.596-.128-4.07-.784-5.22a6 6 0 0 0-2.24-2.24c-1.15-.656-2.624-.766-5.22-.784a.748.748 0 0 0-.752.748c0 .414.335.749.748.752 1.015.007 1.82.028 2.494.088.995.09 1.561.256 1.988.5.7.398 1.28.978 1.679 1.678.243.427.41.993.498 1.988.061.675.082 1.479.09 2.493a.753.753 0 0 0 .75.749ZM3.527.788C4.677.132 6.152.022 8.747.004A.748.748 0 0 1 9.5.752a.753.753 0 0 1-.749.752c-1.014.007-1.818.028-2.493.088-.995.09-1.561.256-1.988.5-.7.398-1.28.978-1.679 1.678-.243.427-.41.993-.499 1.988-.06.675-.081 1.479-.088 2.493A.753.753 0 0 1 1.252 9a.748.748 0 0 1-.748-.752c.018-2.596.128-4.07.784-5.22a6 6 0 0 1 2.24-2.24ZM1.252 15a.748.748 0 0 0-.748.752c.018 2.596.128 4.07.784 5.22a6 6 0 0 0 2.24 2.24c1.15.656 2.624.766 5.22.784a.748.748 0 0 0 .752-.748.753.753 0 0 0-.749-.752c-1.014-.007-1.818-.028-2.493-.089-.995-.089-1.561-.255-1.988-.498a4.5 4.5 0 0 1-1.679-1.68c-.243-.426-.41-.992-.499-1.987-.06-.675-.081-1.479-.088-2.493A.753.753 0 0 0 1.252 15ZM22.996 15.749a.753.753 0 0 1 .752-.749c.415 0 .751.338.748.752-.018 2.596-.128 4.07-.784 5.22a6 6 0 0 1-2.24 2.24c-1.15.656-2.624.766-5.22.784a.748.748 0 0 1-.752-.748c0-.414.335-.749.748-.752 1.015-.007 1.82-.028 2.494-.089.995-.089 1.561-.255 1.988-.498a4.5 4.5 0 0 0 1.679-1.68c.243-.426.41-.992.498-1.987.061-.675.082-1.479.09-2.493Z" fill="#fff"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7 4a2.5 2.5 0 0 0-2.5 2.5v2A2.5 2.5 0 0 0 7 11h2a2.5 2.5 0 0 0 2.5-2.5v-2A2.5 2.5 0 0 0 9 4H7Zm2 1.5H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1ZM13.5 6.5A2.5 2.5 0 0 1 16 4h2a2.5 2.5 0 0 1 2.5 2.5v2A2.5 2.5 0 0 1 18 11h-2a2.5 2.5 0 0 1-2.5-2.5v-2Zm2.5-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1ZM7 13a2.5 2.5 0 0 0-2.5 2.5v2A2.5 2.5 0 0 0 7 20h2a2.5 2.5 0 0 0 2.5-2.5v-2A2.5 2.5 0 0 0 9 13H7Zm2 1.5H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1Z" fill="#fff"/><path d="M13.5 15.5c0-.465 0-.697.038-.89a2 2 0 0 1 1.572-1.572C15.303 13 15.535 13 16 13v2.5h-2.5ZM18 13c.465 0 .697 0 .89.038a2 2 0 0 1 1.572 1.572c.038.193.038.425.038.89H18V13ZM18 17.5h2.5c0 .465 0 .697-.038.89a2 2 0 0 1-1.572 1.572C18.697 20 18.465 20 18 20v-2.5ZM13.5 17.5H16V20c-.465 0-.697 0-.89-.038a2 2 0 0 1-1.572-1.572c-.038-.193-.038-.425-.038-.89Z" fill="#fff"/></svg>`,
	SCAN_ICON: k`<svg width="16" height="16" fill="none"><path fill="#fff" d="M10 15.216c0 .422.347.763.768.74 1.202-.064 2.025-.222 2.71-.613a5.001 5.001 0 0 0 1.865-1.866c.39-.684.549-1.507.613-2.709a.735.735 0 0 0-.74-.768.768.768 0 0 0-.76.732c-.009.157-.02.306-.032.447-.073.812-.206 1.244-.384 1.555-.31.545-.761.996-1.306 1.306-.311.178-.743.311-1.555.384-.141.013-.29.023-.447.032a.768.768 0 0 0-.732.76ZM10 .784c0 .407.325.737.732.76.157.009.306.02.447.032.812.073 1.244.206 1.555.384a3.5 3.5 0 0 1 1.306 1.306c.178.311.311.743.384 1.555.013.142.023.29.032.447a.768.768 0 0 0 .76.732.734.734 0 0 0 .74-.768c-.064-1.202-.222-2.025-.613-2.71A5 5 0 0 0 13.477.658c-.684-.39-1.507-.549-2.709-.613a.735.735 0 0 0-.768.74ZM5.232.044A.735.735 0 0 1 6 .784a.768.768 0 0 1-.732.76c-.157.009-.305.02-.447.032-.812.073-1.244.206-1.555.384A3.5 3.5 0 0 0 1.96 3.266c-.178.311-.311.743-.384 1.555-.013.142-.023.29-.032.447A.768.768 0 0 1 .784 6a.735.735 0 0 1-.74-.768c.064-1.202.222-2.025.613-2.71A5 5 0 0 1 2.523.658C3.207.267 4.03.108 5.233.044ZM5.268 14.456a.768.768 0 0 1 .732.76.734.734 0 0 1-.768.74c-1.202-.064-2.025-.222-2.71-.613a5 5 0 0 1-1.865-1.866c-.39-.684-.549-1.507-.613-2.709A.735.735 0 0 1 .784 10c.407 0 .737.325.76.732.009.157.02.306.032.447.073.812.206 1.244.384 1.555a3.5 3.5 0 0 0 1.306 1.306c.311.178.743.311 1.555.384.142.013.29.023.447.032Z"/></svg>`,
	CHECKMARK_ICON: k`<svg width="13" height="12" viewBox="0 0 13 12"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.155.132a.75.75 0 0 1 .232 1.035L5.821 11.535a1 1 0 0 1-1.626.09L.665 7.21a.75.75 0 1 1 1.17-.937L4.71 9.867a.25.25 0 0 0 .406-.023L11.12.364a.75.75 0 0 1 1.035-.232Z" fill="#fff"/></svg>`,
	SEARCH_ICON: k`<svg width="20" height="21"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.432 13.992c-.354-.353-.91-.382-1.35-.146a5.5 5.5 0 1 1 2.265-2.265c-.237.441-.208.997.145 1.35l3.296 3.296a.75.75 0 1 1-1.06 1.061l-3.296-3.296Zm.06-5a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z" fill="#949E9E"/></svg>`,
	WALLET_PLACEHOLDER: k`<svg width="60" height="60" fill="none" viewBox="0 0 60 60"><g clip-path="url(#q)"><path id="wallet-placeholder-fill" fill="#fff" d="M0 24.9c0-9.251 0-13.877 1.97-17.332a15 15 0 0 1 5.598-5.597C11.023 0 15.648 0 24.9 0h10.2c9.252 0 13.877 0 17.332 1.97a15 15 0 0 1 5.597 5.598C60 11.023 60 15.648 60 24.9v10.2c0 9.252 0 13.877-1.97 17.332a15.001 15.001 0 0 1-5.598 5.597C48.977 60 44.352 60 35.1 60H24.9c-9.251 0-13.877 0-17.332-1.97a15 15 0 0 1-5.597-5.598C0 48.977 0 44.352 0 35.1V24.9Z"/><path id="wallet-placeholder-dash" stroke="#000" stroke-dasharray="4 4" stroke-width="1.5" d="M.04 41.708a231.598 231.598 0 0 1-.039-4.403l.75-.001L.75 35.1v-2.55H0v-5.1h.75V24.9l.001-2.204h-.75c.003-1.617.011-3.077.039-4.404l.75.016c.034-1.65.099-3.08.218-4.343l-.746-.07c.158-1.678.412-3.083.82-4.316l.713.236c.224-.679.497-1.296.827-1.875a14.25 14.25 0 0 1 1.05-1.585L3.076 5.9A15 15 0 0 1 5.9 3.076l.455.596a14.25 14.25 0 0 1 1.585-1.05c.579-.33 1.196-.603 1.875-.827l-.236-.712C10.812.674 12.217.42 13.895.262l.07.746C15.23.89 16.66.824 18.308.79l-.016-.75C19.62.012 21.08.004 22.695.001l.001.75L24.9.75h2.55V0h5.1v.75h2.55l2.204.001v-.75c1.617.003 3.077.011 4.404.039l-.016.75c1.65.034 3.08.099 4.343.218l.07-.746c1.678.158 3.083.412 4.316.82l-.236.713c.679.224 1.296.497 1.875.827a14.24 14.24 0 0 1 1.585 1.05l.455-.596A14.999 14.999 0 0 1 56.924 5.9l-.596.455c.384.502.735 1.032 1.05 1.585.33.579.602 1.196.827 1.875l.712-.236c.409 1.233.663 2.638.822 4.316l-.747.07c.119 1.264.184 2.694.218 4.343l.75-.016c.028 1.327.036 2.787.039 4.403l-.75.001.001 2.204v2.55H60v5.1h-.75v2.55l-.001 2.204h.75a231.431 231.431 0 0 1-.039 4.404l-.75-.016c-.034 1.65-.099 3.08-.218 4.343l.747.07c-.159 1.678-.413 3.083-.822 4.316l-.712-.236a10.255 10.255 0 0 1-.827 1.875 14.242 14.242 0 0 1-1.05 1.585l.596.455a14.997 14.997 0 0 1-2.824 2.824l-.455-.596c-.502.384-1.032.735-1.585 1.05-.579.33-1.196.602-1.875.827l.236.712c-1.233.409-2.638.663-4.316.822l-.07-.747c-1.264.119-2.694.184-4.343.218l.016.75c-1.327.028-2.787.036-4.403.039l-.001-.75-2.204.001h-2.55V60h-5.1v-.75H24.9l-2.204-.001v.75a231.431 231.431 0 0 1-4.404-.039l.016-.75c-1.65-.034-3.08-.099-4.343-.218l-.07.747c-1.678-.159-3.083-.413-4.316-.822l.236-.712a10.258 10.258 0 0 1-1.875-.827 14.252 14.252 0 0 1-1.585-1.05l-.455.596A14.999 14.999 0 0 1 3.076 54.1l.596-.455a14.24 14.24 0 0 1-1.05-1.585 10.259 10.259 0 0 1-.827-1.875l-.712.236C.674 49.188.42 47.783.262 46.105l.746-.07C.89 44.77.824 43.34.79 41.692l-.75.016Z"/><path fill="#fff" fill-rule="evenodd" d="M35.643 32.145c-.297-.743-.445-1.114-.401-1.275a.42.42 0 0 1 .182-.27c.134-.1.463-.1 1.123-.1.742 0 1.499.046 2.236-.05a6 6 0 0 0 5.166-5.166c.051-.39.051-.855.051-1.784 0-.928 0-1.393-.051-1.783a6 6 0 0 0-5.166-5.165c-.39-.052-.854-.052-1.783-.052h-7.72c-4.934 0-7.401 0-9.244 1.051a8 8 0 0 0-2.985 2.986C16.057 22.28 16.003 24.58 16 29 15.998 31.075 16 33.15 16 35.224A7.778 7.778 0 0 0 23.778 43H28.5c1.394 0 2.09 0 2.67-.116a6 6 0 0 0 4.715-4.714c.115-.58.115-1.301.115-2.744 0-1.31 0-1.964-.114-2.49a4.998 4.998 0 0 0-.243-.792Z" clip-rule="evenodd"/><path fill="#9EA9A9" fill-rule="evenodd" d="M37 18h-7.72c-2.494 0-4.266.002-5.647.126-1.361.122-2.197.354-2.854.728a6.5 6.5 0 0 0-2.425 2.426c-.375.657-.607 1.492-.729 2.853-.11 1.233-.123 2.777-.125 4.867 0 .7 0 1.05.097 1.181.096.13.182.181.343.2.163.02.518-.18 1.229-.581a6.195 6.195 0 0 1 3.053-.8H37c.977 0 1.32-.003 1.587-.038a4.5 4.5 0 0 0 3.874-3.874c.036-.268.039-.611.039-1.588 0-.976-.003-1.319-.038-1.587a4.5 4.5 0 0 0-3.875-3.874C38.32 18.004 37.977 18 37 18Zm-7.364 12.5h-7.414a4.722 4.722 0 0 0-4.722 4.723 6.278 6.278 0 0 0 6.278 6.278H28.5c1.466 0 1.98-.008 2.378-.087a4.5 4.5 0 0 0 3.535-3.536c.08-.397.087-.933.087-2.451 0-1.391-.009-1.843-.08-2.17a3.5 3.5 0 0 0-2.676-2.676c-.328-.072-.762-.08-2.108-.08Z" clip-rule="evenodd"/></g><defs><clipPath id="q"><path fill="#fff" d="M0 0h60v60H0z"/></clipPath></defs></svg>`,
	GLOBE_ICON: k`<svg width="16" height="16" fill="none" viewBox="0 0 16 16"><path fill="#fff" fill-rule="evenodd" d="M15.5 8a7.5 7.5 0 1 1-15 0 7.5 7.5 0 0 1 15 0Zm-2.113.75c.301 0 .535.264.47.558a6.01 6.01 0 0 1-2.867 3.896c-.203.116-.42-.103-.334-.32.409-1.018.691-2.274.797-3.657a.512.512 0 0 1 .507-.477h1.427Zm.47-2.058c.065.294-.169.558-.47.558H11.96a.512.512 0 0 1-.507-.477c-.106-1.383-.389-2.638-.797-3.656-.087-.217.13-.437.333-.32a6.01 6.01 0 0 1 2.868 3.895Zm-4.402.558c.286 0 .515-.24.49-.525-.121-1.361-.429-2.534-.83-3.393-.279-.6-.549-.93-.753-1.112a.535.535 0 0 0-.724 0c-.204.182-.474.513-.754 1.112-.4.859-.708 2.032-.828 3.393a.486.486 0 0 0 .49.525h2.909Zm-5.415 0c.267 0 .486-.21.507-.477.106-1.383.389-2.638.797-3.656.087-.217-.13-.437-.333-.32a6.01 6.01 0 0 0-2.868 3.895c-.065.294.169.558.47.558H4.04ZM2.143 9.308c-.065-.294.169-.558.47-.558H4.04c.267 0 .486.21.507.477.106 1.383.389 2.639.797 3.657.087.217-.13.436-.333.32a6.01 6.01 0 0 1-2.868-3.896Zm3.913-.033a.486.486 0 0 1 .49-.525h2.909c.286 0 .515.24.49.525-.121 1.361-.428 2.535-.83 3.394-.279.6-.549.93-.753 1.112a.535.535 0 0 1-.724 0c-.204-.182-.474-.513-.754-1.112-.4-.859-.708-2.033-.828-3.394Z" clip-rule="evenodd"/></svg>`
}, cr = _`.wcm-toolbar-placeholder{top:0;bottom:0;left:0;right:0;width:100%;position:absolute;display:block;pointer-events:none;height:100px;border-radius:calc(var(--wcm-background-border-radius) * .9);background-color:var(--wcm-background-color);background-position:center;background-size:cover}.wcm-toolbar{height:38px;display:flex;position:relative;margin:5px 15px 5px 5px;justify-content:space-between;align-items:center}.wcm-toolbar img,.wcm-toolbar svg{height:28px;object-position:left center;object-fit:contain}#wcm-wc-logo path{fill:var(--wcm-accent-fill-color)}button{width:28px;height:28px;border-radius:var(--wcm-icon-button-border-radius);border:0;display:flex;justify-content:center;align-items:center;cursor:pointer;background-color:var(--wcm-color-bg-1);box-shadow:0 0 0 1px var(--wcm-color-overlay)}button:active{background-color:var(--wcm-color-bg-2)}button svg{display:block;object-position:center}button path{fill:var(--wcm-color-fg-1)}.wcm-toolbar div{display:flex}@media(hover:hover){button:hover{background-color:var(--wcm-color-bg-2)}}`, lr = Object.defineProperty, ur = Object.getOwnPropertyDescriptor, dr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ur(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && lr(t, n, i), i;
}, fr = class extends N {
	render() {
		return O`<div class="wcm-toolbar-placeholder"></div><div class="wcm-toolbar">${K.WALLET_CONNECT_LOGO} <button @click="${t.close}">${K.CROSS_ICON}</button></div>`;
	}
};
fr.styles = [W.globalCss, cr], fr = dr([P("wcm-modal-backcard")], fr);
var pr = _`main{padding:20px;padding-top:0;width:100%}`, mr = Object.defineProperty, hr = Object.getOwnPropertyDescriptor, gr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? hr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && mr(t, n, i), i;
}, _r = class extends N {
	render() {
		return O`<main><slot></slot></main>`;
	}
};
_r.styles = [W.globalCss, pr], _r = gr([P("wcm-modal-content")], _r);
var vr = _`footer{padding:10px;display:flex;flex-direction:column;align-items:inherit;justify-content:inherit;border-top:1px solid var(--wcm-color-bg-2)}`, yr = Object.defineProperty, br = Object.getOwnPropertyDescriptor, xr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? br(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && yr(t, n, i), i;
}, Sr = class extends N {
	render() {
		return O`<footer><slot></slot></footer>`;
	}
};
Sr.styles = [W.globalCss, vr], Sr = xr([P("wcm-modal-footer")], Sr);
var Cr = _`header{display:flex;justify-content:center;align-items:center;padding:20px;position:relative}.wcm-border{border-bottom:1px solid var(--wcm-color-bg-2);margin-bottom:20px}header button{padding:15px 20px}header button:active{opacity:.5}@media(hover:hover){header button:hover{opacity:.5}}.wcm-back-btn{position:absolute;left:0}.wcm-action-btn{position:absolute;right:0}path{fill:var(--wcm-accent-color)}`, wr = Object.defineProperty, Tr = Object.getOwnPropertyDescriptor, Er = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Tr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && wr(t, n, i), i;
}, q = class extends N {
	constructor() {
		super(...arguments), this.title = "", this.onAction = void 0, this.actionIcon = void 0, this.border = !1;
	}
	backBtnTemplate() {
		return O`<button class="wcm-back-btn" @click="${l.goBack}">${K.BACK_ICON}</button>`;
	}
	actionBtnTemplate() {
		return O`<button class="wcm-action-btn" @click="${this.onAction}">${this.actionIcon}</button>`;
	}
	render() {
		let e = { "wcm-border": this.border }, t = l.state.history.length > 1, n = this.title ? O`<wcm-text variant="big-bold">${this.title}</wcm-text>` : O`<slot></slot>`;
		return O`<header class="${L(e)}">${t ? this.backBtnTemplate() : null} ${n} ${this.onAction ? this.actionBtnTemplate() : null}</header>`;
	}
};
q.styles = [W.globalCss, Cr], Er([F()], q.prototype, "title", 2), Er([F()], q.prototype, "onAction", 2), Er([F()], q.prototype, "actionIcon", 2), Er([F({ type: Boolean })], q.prototype, "border", 2), q = Er([P("wcm-modal-header")], q);
var J = {
	MOBILE_BREAKPOINT: 600,
	WCM_RECENT_WALLET_DATA: "WCM_RECENT_WALLET_DATA",
	EXPLORER_WALLET_URL: "https://explorer.walletconnect.com/?type=wallet",
	getShadowRootElement(e, t) {
		let n = e.renderRoot.querySelector(t);
		if (!n) throw Error(`${t} not found`);
		return n;
	},
	getWalletIcon({ id: e, image_id: t }) {
		let { walletImages: n } = u.state;
		return n?.[e] ? n[e] : t ? i.getWalletImageUrl(t) : "";
	},
	getWalletName(e, t = !1) {
		return t && e.length > 8 ? `${e.substring(0, 8)}..` : e;
	},
	isMobileAnimation() {
		return window.innerWidth <= J.MOBILE_BREAKPOINT;
	},
	async preloadImage(e) {
		let t = new Promise((t, n) => {
			let r = new Image();
			r.onload = t, r.onerror = n, r.crossOrigin = "anonymous", r.src = e;
		});
		return Promise.race([t, o.wait(3e3)]);
	},
	getErrorMessage(e) {
		return e instanceof Error ? e.message : "Unknown Error";
	},
	debounce(e, t = 500) {
		let n;
		return (...r) => {
			function i() {
				e(...r);
			}
			n && clearTimeout(n), n = setTimeout(i, t);
		};
	},
	handleMobileLinking(e, t = "_self") {
		let { walletConnectUri: n } = s.state, { mobile: r, name: i } = e, a = r?.native, c = r?.universal;
		J.setRecentWallet(e);
		function l(e) {
			if (a) {
				let n = o.formatNativeUrl(a, e, i);
				o.openHref(n, t);
			} else if (c) {
				let n = o.formatUniversalUrl(c, e, i);
				o.openHref(n, t);
			}
		}
		n && l(n);
	},
	handleAndroidLinking() {
		let { walletConnectUri: e } = s.state;
		e && (o.setWalletConnectAndroidDeepLink(e), o.openHref(e, o.isTelegram() ? "_blank" : "_self"));
	},
	async handleUriCopy() {
		let { walletConnectUri: e } = s.state;
		if (e) try {
			await navigator.clipboard.writeText(e), a.openToast("Link copied", "success");
		} catch {
			a.openToast("Failed to copy", "error");
		}
	},
	getCustomImageUrls() {
		let { walletImages: e } = u.state, t = Object.values(e ?? {});
		return Object.values(t);
	},
	truncate(e, t = 8) {
		return e.length <= t ? e : `${e.substring(0, 4)}...${e.substring(e.length - 4)}`;
	},
	setRecentWallet(e) {
		try {
			localStorage.setItem(J.WCM_RECENT_WALLET_DATA, JSON.stringify(e));
		} catch {
			console.info("Unable to set recent wallet");
		}
	},
	getRecentWallet() {
		try {
			let e = localStorage.getItem(J.WCM_RECENT_WALLET_DATA);
			return e ? JSON.parse(e) : void 0;
		} catch {
			console.info("Unable to get recent wallet");
		}
	},
	caseSafeIncludes(e, t) {
		return e.toUpperCase().includes(t.toUpperCase());
	},
	openWalletExplorerUrl() {
		o.openHref(J.EXPLORER_WALLET_URL, "_blank");
	},
	getCachedRouterWalletPlatforms() {
		let { desktop: e, mobile: t } = o.getWalletRouterData(), n = !!e?.native, r = !!e?.universal;
		return {
			isDesktop: n,
			isMobile: !!t?.native || !!t?.universal,
			isWeb: r
		};
	},
	goToConnectingView(e) {
		l.setData({ Wallet: e });
		let t = o.isMobile(), { isDesktop: n, isWeb: r, isMobile: i } = J.getCachedRouterWalletPlatforms();
		t ? i ? (l.push("MobileConnecting"), !o.isAndroid() && o.isTelegram() && this.handleMobileLinking(e, "_blank")) : r ? l.push("WebConnecting") : l.push("InstallWallet") : n ? l.push("DesktopConnecting") : r ? l.push("WebConnecting") : i ? l.push("MobileQrcodeConnecting") : l.push("InstallWallet");
	}
}, Dr = _`.wcm-router{overflow:hidden;will-change:transform}.wcm-content{display:flex;flex-direction:column}`, Or = Object.defineProperty, kr = Object.getOwnPropertyDescriptor, Ar = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? kr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Or(t, n, i), i;
}, jr = class extends N {
	constructor() {
		super(), this.view = l.state.view, this.prevView = l.state.view, this.unsubscribe = void 0, this.oldHeight = "0px", this.resizeObserver = void 0, this.unsubscribe = l.subscribe((e) => {
			this.view !== e.view && this.onChangeRoute();
		});
	}
	firstUpdated() {
		this.resizeObserver = new ResizeObserver(([e]) => {
			let t = `${e.contentRect.height}px`;
			this.oldHeight !== "0px" && B(this.routerEl, { height: [this.oldHeight, t] }, { duration: .2 }), this.oldHeight = t;
		}), this.resizeObserver.observe(this.contentEl);
	}
	disconnectedCallback() {
		var e, t;
		(e = this.unsubscribe) == null || e.call(this), (t = this.resizeObserver) == null || t.disconnect();
	}
	get routerEl() {
		return J.getShadowRootElement(this, ".wcm-router");
	}
	get contentEl() {
		return J.getShadowRootElement(this, ".wcm-content");
	}
	viewTemplate() {
		switch (this.view) {
			case "ConnectWallet": return O`<wcm-connect-wallet-view></wcm-connect-wallet-view>`;
			case "DesktopConnecting": return O`<wcm-desktop-connecting-view></wcm-desktop-connecting-view>`;
			case "MobileConnecting": return O`<wcm-mobile-connecting-view></wcm-mobile-connecting-view>`;
			case "WebConnecting": return O`<wcm-web-connecting-view></wcm-web-connecting-view>`;
			case "MobileQrcodeConnecting": return O`<wcm-mobile-qr-connecting-view></wcm-mobile-qr-connecting-view>`;
			case "WalletExplorer": return O`<wcm-wallet-explorer-view></wcm-wallet-explorer-view>`;
			case "Qrcode": return O`<wcm-qrcode-view></wcm-qrcode-view>`;
			case "InstallWallet": return O`<wcm-install-wallet-view></wcm-install-wallet-view>`;
			default: return O`<div>Not Found</div>`;
		}
	}
	async onChangeRoute() {
		await B(this.routerEl, {
			opacity: [1, 0],
			scale: [1, 1.02]
		}, {
			duration: .15,
			delay: .1
		}).finished, this.view = l.state.view, B(this.routerEl, {
			opacity: [0, 1],
			scale: [.99, 1]
		}, {
			duration: .37,
			delay: .05
		});
	}
	render() {
		return O`<div class="wcm-router"><div class="wcm-content">${this.viewTemplate()}</div></div>`;
	}
};
jr.styles = [W.globalCss, Dr], Ar([I()], jr.prototype, "view", 2), Ar([I()], jr.prototype, "prevView", 2), jr = Ar([P("wcm-modal-router")], jr);
var Mr = _`div{height:36px;width:max-content;display:flex;justify-content:center;align-items:center;padding:9px 15px 11px;position:absolute;top:12px;box-shadow:0 6px 14px -6px rgba(10,16,31,.3),0 10px 32px -4px rgba(10,16,31,.15);z-index:2;left:50%;transform:translateX(-50%);pointer-events:none;backdrop-filter:blur(20px) saturate(1.8);-webkit-backdrop-filter:blur(20px) saturate(1.8);border-radius:var(--wcm-notification-border-radius);border:1px solid var(--wcm-color-overlay);background-color:var(--wcm-color-overlay)}svg{margin-right:5px}@-moz-document url-prefix(){div{background-color:var(--wcm-color-bg-3)}}.wcm-success path{fill:var(--wcm-accent-color)}.wcm-error path{fill:var(--wcm-error-color)}`, Nr = Object.defineProperty, Pr = Object.getOwnPropertyDescriptor, Fr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Pr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Nr(t, n, i), i;
}, Ir = class extends N {
	constructor() {
		super(), this.open = !1, this.unsubscribe = void 0, this.timeout = void 0, this.unsubscribe = a.subscribe((e) => {
			e.open ? (this.open = !0, this.timeout = setTimeout(() => a.closeToast(), 2200)) : (this.open = !1, clearTimeout(this.timeout));
		});
	}
	disconnectedCallback() {
		var e;
		(e = this.unsubscribe) == null || e.call(this), clearTimeout(this.timeout), a.closeToast();
	}
	render() {
		let { message: e, variant: t } = a.state, n = {
			"wcm-success": t === "success",
			"wcm-error": t === "error"
		};
		return this.open ? O`<div class="${L(n)}">${t === "success" ? K.CHECKMARK_ICON : null} ${t === "error" ? K.CROSS_ICON : null}<wcm-text variant="small-regular">${e}</wcm-text></div>` : null;
	}
};
Ir.styles = [W.globalCss, Mr], Fr([I()], Ir.prototype, "open", 2), Ir = Fr([P("wcm-modal-toast")], Ir);
var Lr = .1, Rr = 2.5, zr = 7;
function Br(e, t, n) {
	return e !== t && (e - t < 0 ? t - e : e - t) <= n + Lr;
}
function Vr(e, t) {
	let n = Array.prototype.slice.call(zn.create(e, { errorCorrectionLevel: t }).modules.data, 0), r = Math.sqrt(n.length);
	return n.reduce((e, t, n) => (n % r === 0 ? e.push([t]) : e[e.length - 1].push(t)) && e, []);
}
var Hr = { generate(e, t, n) {
	let r = "#141414", i = [], a = Vr(e, "Q"), o = t / a.length, s = [
		{
			x: 0,
			y: 0
		},
		{
			x: 1,
			y: 0
		},
		{
			x: 0,
			y: 1
		}
	];
	s.forEach(({ x: e, y: t }) => {
		let n = (a.length - zr) * o * e, c = (a.length - zr) * o * t, l = .45;
		for (let e = 0; e < s.length; e += 1) {
			let t = o * (zr - e * 2);
			i.push(k`<rect fill="${e % 2 == 0 ? r : "#ffffff"}" height="${t}" rx="${t * l}" ry="${t * l}" width="${t}" x="${n + o * e}" y="${c + o * e}">`);
		}
	});
	let c = Math.floor((n + 25) / o), l = a.length / 2 - c / 2, u = a.length / 2 + c / 2 - 1, d = [];
	a.forEach((e, t) => {
		e.forEach((e, n) => {
			if (a[t][n] && !(t < zr && n < zr || t > a.length - 8 && n < zr || t < zr && n > a.length - 8) && !(t > l && t < u && n > l && n < u)) {
				let e = t * o + o / 2, r = n * o + o / 2;
				d.push([e, r]);
			}
		});
	});
	let f = {};
	return d.forEach(([e, t]) => {
		f[e] ? f[e].push(t) : f[e] = [t];
	}), Object.entries(f).map(([e, t]) => {
		let n = t.filter((e) => t.every((t) => !Br(e, t, o)));
		return [Number(e), n];
	}).forEach(([e, t]) => {
		t.forEach((t) => {
			i.push(k`<circle cx="${e}" cy="${t}" fill="${r}" r="${o / Rr}">`);
		});
	}), Object.entries(f).filter(([e, t]) => t.length > 1).map(([e, t]) => {
		let n = t.filter((e) => t.some((t) => Br(e, t, o)));
		return [Number(e), n];
	}).map(([e, t]) => {
		t.sort((e, t) => e < t ? -1 : 1);
		let n = [];
		for (let e of t) {
			let t = n.find((t) => t.some((t) => Br(e, t, o)));
			t ? t.push(e) : n.push([e]);
		}
		return [e, n.map((e) => [e[0], e[e.length - 1]])];
	}).forEach(([e, t]) => {
		t.forEach(([t, n]) => {
			i.push(k`<line x1="${e}" x2="${e}" y1="${t}" y2="${n}" stroke="${r}" stroke-width="${o / (Rr / 2)}" stroke-linecap="round">`);
		});
	}), i;
} }, Ur = _`@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}div{position:relative;user-select:none;display:block;overflow:hidden;aspect-ratio:1/1;animation:fadeIn ease .2s}.wcm-dark{background-color:#fff;border-radius:var(--wcm-container-border-radius);padding:18px;box-shadow:0 2px 5px #000}svg:first-child,wcm-wallet-image{position:absolute;top:50%;left:50%;transform:translateY(-50%) translateX(-50%)}wcm-wallet-image{transform:translateY(-50%) translateX(-50%)}wcm-wallet-image{width:25%;height:25%;border-radius:var(--wcm-wallet-icon-border-radius)}svg:first-child{transform:translateY(-50%) translateX(-50%) scale(.9)}svg:first-child path:first-child{fill:var(--wcm-accent-color)}svg:first-child path:last-child{stroke:var(--wcm-color-overlay)}`, Wr = Object.defineProperty, Gr = Object.getOwnPropertyDescriptor, Kr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Gr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Wr(t, n, i), i;
}, Y = class extends N {
	constructor() {
		super(...arguments), this.uri = "", this.size = 0, this.imageId = void 0, this.walletId = void 0, this.imageUrl = void 0;
	}
	svgTemplate() {
		let e = n.state.themeMode === "light" ? this.size : this.size - 36;
		return k`<svg height="${e}" width="${e}">${Hr.generate(this.uri, e, e / 4)}</svg>`;
	}
	render() {
		let e = { "wcm-dark": n.state.themeMode === "dark" };
		return O`<div style="${`width: ${this.size}px`}" class="${L(e)}">${this.walletId || this.imageUrl ? O`<wcm-wallet-image walletId="${V(this.walletId)}" imageId="${V(this.imageId)}" imageUrl="${V(this.imageUrl)}"></wcm-wallet-image>` : K.WALLET_CONNECT_ICON_COLORED} ${this.svgTemplate()}</div>`;
	}
};
Y.styles = [W.globalCss, Ur], Kr([F()], Y.prototype, "uri", 2), Kr([F({ type: Number })], Y.prototype, "size", 2), Kr([F()], Y.prototype, "imageId", 2), Kr([F()], Y.prototype, "walletId", 2), Kr([F()], Y.prototype, "imageUrl", 2), Y = Kr([P("wcm-qrcode")], Y);
var qr = _`:host{position:relative;height:28px;width:80%}input{width:100%;height:100%;line-height:28px!important;border-radius:var(--wcm-input-border-radius);font-style:normal;font-family:-apple-system,system-ui,BlinkMacSystemFont,'Segoe UI',Roboto,Ubuntu,'Helvetica Neue',sans-serif;font-feature-settings:'case' on;font-weight:500;font-size:16px;letter-spacing:-.03em;padding:0 10px 0 34px;transition:.2s all ease;color:var(--wcm-color-fg-1);background-color:var(--wcm-color-bg-3);box-shadow:inset 0 0 0 1px var(--wcm-color-overlay);caret-color:var(--wcm-accent-color)}input::placeholder{color:var(--wcm-color-fg-2)}svg{left:10px;top:4px;pointer-events:none;position:absolute;width:20px;height:20px}input:focus-within{box-shadow:inset 0 0 0 1px var(--wcm-accent-color)}path{fill:var(--wcm-color-fg-2)}`, Jr = Object.defineProperty, Yr = Object.getOwnPropertyDescriptor, Xr = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Yr(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Jr(t, n, i), i;
}, Zr = class extends N {
	constructor() {
		super(...arguments), this.onChange = () => null;
	}
	render() {
		return O`<input type="text" @input="${this.onChange}" placeholder="Search wallets"> ${K.SEARCH_ICON}`;
	}
};
Zr.styles = [W.globalCss, qr], Xr([F()], Zr.prototype, "onChange", 2), Zr = Xr([P("wcm-search-input")], Zr);
var Qr = _`@keyframes rotate{100%{transform:rotate(360deg)}}@keyframes dash{0%{stroke-dasharray:1,150;stroke-dashoffset:0}50%{stroke-dasharray:90,150;stroke-dashoffset:-35}100%{stroke-dasharray:90,150;stroke-dashoffset:-124}}svg{animation:rotate 2s linear infinite;display:flex;justify-content:center;align-items:center}svg circle{stroke-linecap:round;animation:dash 1.5s ease infinite;stroke:var(--wcm-accent-color)}`, $r = Object.defineProperty, ei = Object.getOwnPropertyDescriptor, ti = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ei(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && $r(t, n, i), i;
}, ni = class extends N {
	render() {
		return O`<svg viewBox="0 0 50 50" width="24" height="24"><circle cx="25" cy="25" r="20" fill="none" stroke-width="4" stroke="#fff"/></svg>`;
	}
};
ni.styles = [W.globalCss, Qr], ni = ti([P("wcm-spinner")], ni);
var ri = _`span{font-style:normal;font-family:var(--wcm-font-family);font-feature-settings:var(--wcm-font-feature-settings)}.wcm-xsmall-bold{font-family:var(--wcm-text-xsmall-bold-font-family);font-weight:var(--wcm-text-xsmall-bold-weight);font-size:var(--wcm-text-xsmall-bold-size);line-height:var(--wcm-text-xsmall-bold-line-height);letter-spacing:var(--wcm-text-xsmall-bold-letter-spacing);text-transform:var(--wcm-text-xsmall-bold-text-transform)}.wcm-xsmall-regular{font-family:var(--wcm-text-xsmall-regular-font-family);font-weight:var(--wcm-text-xsmall-regular-weight);font-size:var(--wcm-text-xsmall-regular-size);line-height:var(--wcm-text-xsmall-regular-line-height);letter-spacing:var(--wcm-text-xsmall-regular-letter-spacing);text-transform:var(--wcm-text-xsmall-regular-text-transform)}.wcm-small-thin{font-family:var(--wcm-text-small-thin-font-family);font-weight:var(--wcm-text-small-thin-weight);font-size:var(--wcm-text-small-thin-size);line-height:var(--wcm-text-small-thin-line-height);letter-spacing:var(--wcm-text-small-thin-letter-spacing);text-transform:var(--wcm-text-small-thin-text-transform)}.wcm-small-regular{font-family:var(--wcm-text-small-regular-font-family);font-weight:var(--wcm-text-small-regular-weight);font-size:var(--wcm-text-small-regular-size);line-height:var(--wcm-text-small-regular-line-height);letter-spacing:var(--wcm-text-small-regular-letter-spacing);text-transform:var(--wcm-text-small-regular-text-transform)}.wcm-medium-regular{font-family:var(--wcm-text-medium-regular-font-family);font-weight:var(--wcm-text-medium-regular-weight);font-size:var(--wcm-text-medium-regular-size);line-height:var(--wcm-text-medium-regular-line-height);letter-spacing:var(--wcm-text-medium-regular-letter-spacing);text-transform:var(--wcm-text-medium-regular-text-transform)}.wcm-big-bold{font-family:var(--wcm-text-big-bold-font-family);font-weight:var(--wcm-text-big-bold-weight);font-size:var(--wcm-text-big-bold-size);line-height:var(--wcm-text-big-bold-line-height);letter-spacing:var(--wcm-text-big-bold-letter-spacing);text-transform:var(--wcm-text-big-bold-text-transform)}:host(*){color:var(--wcm-color-fg-1)}.wcm-color-primary{color:var(--wcm-color-fg-1)}.wcm-color-secondary{color:var(--wcm-color-fg-2)}.wcm-color-tertiary{color:var(--wcm-color-fg-3)}.wcm-color-inverse{color:var(--wcm-accent-fill-color)}.wcm-color-accnt{color:var(--wcm-accent-color)}.wcm-color-error{color:var(--wcm-error-color)}`, ii = Object.defineProperty, ai = Object.getOwnPropertyDescriptor, oi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ai(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && ii(t, n, i), i;
}, si = class extends N {
	constructor() {
		super(...arguments), this.variant = "medium-regular", this.color = "primary";
	}
	render() {
		return O`<span><slot class="${L({
			"wcm-big-bold": this.variant === "big-bold",
			"wcm-medium-regular": this.variant === "medium-regular",
			"wcm-small-regular": this.variant === "small-regular",
			"wcm-small-thin": this.variant === "small-thin",
			"wcm-xsmall-regular": this.variant === "xsmall-regular",
			"wcm-xsmall-bold": this.variant === "xsmall-bold",
			"wcm-color-primary": this.color === "primary",
			"wcm-color-secondary": this.color === "secondary",
			"wcm-color-tertiary": this.color === "tertiary",
			"wcm-color-inverse": this.color === "inverse",
			"wcm-color-accnt": this.color === "accent",
			"wcm-color-error": this.color === "error"
		})}"></slot></span>`;
	}
};
si.styles = [W.globalCss, ri], oi([F()], si.prototype, "variant", 2), oi([F()], si.prototype, "color", 2), si = oi([P("wcm-text")], si);
var ci = _`button{width:100%;height:100%;border-radius:var(--wcm-button-hover-highlight-border-radius);display:flex;align-items:flex-start}button:active{background-color:var(--wcm-color-overlay)}@media(hover:hover){button:hover{background-color:var(--wcm-color-overlay)}}button>div{width:80px;padding:5px 0;display:flex;flex-direction:column;align-items:center}wcm-text{width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}wcm-wallet-image{height:60px;width:60px;transition:all .2s ease;border-radius:var(--wcm-wallet-icon-border-radius);margin-bottom:5px}.wcm-sublabel{margin-top:2px}`, li = Object.defineProperty, ui = Object.getOwnPropertyDescriptor, X = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ui(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && li(t, n, i), i;
}, Z = class extends N {
	constructor() {
		super(...arguments), this.onClick = () => null, this.name = "", this.walletId = "", this.label = void 0, this.imageId = void 0, this.installed = !1, this.recent = !1;
	}
	sublabelTemplate() {
		return this.recent ? O`<wcm-text class="wcm-sublabel" variant="xsmall-bold" color="tertiary">RECENT</wcm-text>` : this.installed ? O`<wcm-text class="wcm-sublabel" variant="xsmall-bold" color="tertiary">INSTALLED</wcm-text>` : null;
	}
	handleClick() {
		c.click({
			name: "WALLET_BUTTON",
			walletId: this.walletId
		}), this.onClick();
	}
	render() {
		return O`<button @click="${this.handleClick.bind(this)}"><div><wcm-wallet-image walletId="${this.walletId}" imageId="${V(this.imageId)}"></wcm-wallet-image><wcm-text variant="xsmall-regular">${this.label ?? J.getWalletName(this.name, !0)}</wcm-text>${this.sublabelTemplate()}</div></button>`;
	}
};
Z.styles = [W.globalCss, ci], X([F()], Z.prototype, "onClick", 2), X([F()], Z.prototype, "name", 2), X([F()], Z.prototype, "walletId", 2), X([F()], Z.prototype, "label", 2), X([F()], Z.prototype, "imageId", 2), X([F({ type: Boolean })], Z.prototype, "installed", 2), X([F({ type: Boolean })], Z.prototype, "recent", 2), Z = X([P("wcm-wallet-button")], Z);
var di = _`:host{display:block}div{overflow:hidden;position:relative;border-radius:inherit;width:100%;height:100%;background-color:var(--wcm-color-overlay)}svg{position:relative;width:100%;height:100%}div::after{content:'';position:absolute;top:0;bottom:0;left:0;right:0;border-radius:inherit;border:1px solid var(--wcm-color-overlay)}div img{width:100%;height:100%;object-fit:cover;object-position:center}#wallet-placeholder-fill{fill:var(--wcm-color-bg-3)}#wallet-placeholder-dash{stroke:var(--wcm-color-overlay)}`, fi = Object.defineProperty, pi = Object.getOwnPropertyDescriptor, mi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? pi(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && fi(t, n, i), i;
}, hi = class extends N {
	constructor() {
		super(...arguments), this.walletId = "", this.imageId = void 0, this.imageUrl = void 0;
	}
	render() {
		let e = this.imageUrl?.length ? this.imageUrl : J.getWalletIcon({
			id: this.walletId,
			image_id: this.imageId
		});
		return O`${e.length ? O`<div><img crossorigin="anonymous" src="${e}" alt="${this.id}"></div>` : K.WALLET_PLACEHOLDER}`;
	}
};
hi.styles = [W.globalCss, di], mi([F()], hi.prototype, "walletId", 2), mi([F()], hi.prototype, "imageId", 2), mi([F()], hi.prototype, "imageUrl", 2), hi = mi([P("wcm-wallet-image")], hi);
var gi = Object.defineProperty, _i = Object.getOwnPropertyDescriptor, vi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? _i(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && gi(t, n, i), i;
}, yi = class extends N {
	constructor() {
		super(), this.preload = !0, this.preloadData();
	}
	async loadImages(e) {
		try {
			e?.length && await Promise.all(e.map(async (e) => J.preloadImage(e)));
		} catch {
			console.info("Unsuccessful attempt at preloading some images", e);
		}
	}
	async preloadListings() {
		if (u.state.enableExplorer) {
			await i.getRecomendedWallets(), s.setIsDataLoaded(!0);
			let { recomendedWallets: e } = i.state, t = e.map((e) => J.getWalletIcon(e));
			await this.loadImages(t);
		} else s.setIsDataLoaded(!0);
	}
	async preloadCustomImages() {
		let e = J.getCustomImageUrls();
		await this.loadImages(e);
	}
	async preloadData() {
		try {
			this.preload && (this.preload = !1, await Promise.all([this.preloadListings(), this.preloadCustomImages()]));
		} catch (e) {
			console.error(e), a.openToast("Failed preloading", "error");
		}
	}
};
vi([I()], yi.prototype, "preload", 2), yi = vi([P("wcm-explorer-context")], yi);
var bi = Object.defineProperty, xi = Object.getOwnPropertyDescriptor, Si = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? xi(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && bi(t, n, i), i;
}, Ci = class extends N {
	constructor() {
		super(), this.unsubscribeTheme = void 0, W.setTheme(), this.unsubscribeTheme = n.subscribe(W.setTheme);
	}
	disconnectedCallback() {
		var e;
		(e = this.unsubscribeTheme) == null || e.call(this);
	}
};
Ci = Si([P("wcm-theme-context")], Ci);
var wi = _`@keyframes scroll{0%{transform:translate3d(0,0,0)}100%{transform:translate3d(calc(-70px * 9),0,0)}}.wcm-slider{position:relative;overflow-x:hidden;padding:10px 0;margin:0 -20px;width:calc(100% + 40px)}.wcm-track{display:flex;width:calc(70px * 18);animation:scroll 20s linear infinite;opacity:.7}.wcm-track svg{margin:0 5px}wcm-wallet-image{width:60px;height:60px;margin:0 5px;border-radius:var(--wcm-wallet-icon-border-radius)}.wcm-grid{display:grid;grid-template-columns:repeat(4,80px);justify-content:space-between}.wcm-title{display:flex;align-items:center;margin-bottom:10px}.wcm-title svg{margin-right:6px}.wcm-title path{fill:var(--wcm-accent-color)}wcm-modal-footer .wcm-title{padding:0 10px}wcm-button-big{position:absolute;top:50%;left:50%;transform:translateY(-50%) translateX(-50%);filter:drop-shadow(0 0 17px var(--wcm-color-bg-1))}wcm-info-footer{flex-direction:column;align-items:center;display:flex;width:100%;padding:5px 0}wcm-info-footer wcm-text{text-align:center;margin-bottom:15px}#wallet-placeholder-fill{fill:var(--wcm-color-bg-3)}#wallet-placeholder-dash{stroke:var(--wcm-color-overlay)}`, Ti = Object.defineProperty, Ei = Object.getOwnPropertyDescriptor, Di = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ei(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Ti(t, n, i), i;
}, Oi = class extends N {
	onGoToQrcode() {
		l.push("Qrcode");
	}
	render() {
		let { recomendedWallets: e } = i.state, t = [...e, ...e], n = o.RECOMMENDED_WALLET_AMOUNT * 2;
		return O`<wcm-modal-header title="Connect your wallet" .onAction="${this.onGoToQrcode}" .actionIcon="${K.QRCODE_ICON}"></wcm-modal-header><wcm-modal-content><div class="wcm-title">${K.MOBILE_ICON}<wcm-text variant="small-regular" color="accent">WalletConnect</wcm-text></div><div class="wcm-slider"><div class="wcm-track">${[...Array(n)].map((e, n) => {
			let r = t[n % t.length];
			return r ? O`<wcm-wallet-image walletId="${r.id}" imageId="${r.image_id}"></wcm-wallet-image>` : K.WALLET_PLACEHOLDER;
		})}</div><wcm-button-big @click="${J.handleAndroidLinking}"><wcm-text variant="medium-regular" color="inverse">Select Wallet</wcm-text></wcm-button-big></div></wcm-modal-content><wcm-info-footer><wcm-text color="secondary" variant="small-thin">Choose WalletConnect to see supported apps on your device</wcm-text></wcm-info-footer>`;
	}
};
Oi.styles = [W.globalCss, wi], Oi = Di([P("wcm-android-wallet-selection")], Oi);
var ki = _`@keyframes loading{to{stroke-dashoffset:0}}@keyframes shake{10%,90%{transform:translate3d(-1px,0,0)}20%,80%{transform:translate3d(1px,0,0)}30%,50%,70%{transform:translate3d(-2px,0,0)}40%,60%{transform:translate3d(2px,0,0)}}:host{display:flex;flex-direction:column;align-items:center}div{position:relative;width:110px;height:110px;display:flex;justify-content:center;align-items:center;margin:40px 0 20px 0;transform:translate3d(0,0,0)}svg{position:absolute;width:110px;height:110px;fill:none;stroke:transparent;stroke-linecap:round;stroke-width:2px;top:0;left:0}use{stroke:var(--wcm-accent-color);animation:loading 1s linear infinite}wcm-wallet-image{border-radius:var(--wcm-wallet-icon-large-border-radius);width:90px;height:90px}wcm-text{margin-bottom:40px}.wcm-error svg{stroke:var(--wcm-error-color)}.wcm-error use{display:none}.wcm-error{animation:shake .4s cubic-bezier(.36,.07,.19,.97) both}.wcm-stale svg,.wcm-stale use{display:none}`, Ai = Object.defineProperty, ji = Object.getOwnPropertyDescriptor, Mi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ji(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Ai(t, n, i), i;
}, Q = class extends N {
	constructor() {
		super(...arguments), this.walletId = void 0, this.imageId = void 0, this.isError = !1, this.isStale = !1, this.label = "";
	}
	svgLoaderTemplate() {
		let e = n.state.themeVariables?.["--wcm-wallet-icon-large-border-radius"] ?? W.getPreset("--wcm-wallet-icon-large-border-radius"), t = 0;
		t = e.includes("%") ? 88 / 100 * parseInt(e, 10) : parseInt(e, 10), t *= 1.17;
		let r = 317 - t * 1.57, i = 425 - t * 1.8;
		return O`<svg viewBox="0 0 110 110" width="110" height="110"><rect id="wcm-loader" x="2" y="2" width="106" height="106" rx="${t}"/><use xlink:href="#wcm-loader" stroke-dasharray="106 ${r}" stroke-dashoffset="${i}"></use></svg>`;
	}
	render() {
		return O`<div class="${L({
			"wcm-error": this.isError,
			"wcm-stale": this.isStale
		})}">${this.svgLoaderTemplate()}<wcm-wallet-image walletId="${V(this.walletId)}" imageId="${V(this.imageId)}"></wcm-wallet-image></div><wcm-text variant="medium-regular" color="${this.isError ? "error" : "primary"}">${this.isError ? "Connection declined" : this.label}</wcm-text>`;
	}
};
Q.styles = [W.globalCss, ki], Mi([F()], Q.prototype, "walletId", 2), Mi([F()], Q.prototype, "imageId", 2), Mi([F({ type: Boolean })], Q.prototype, "isError", 2), Mi([F({ type: Boolean })], Q.prototype, "isStale", 2), Mi([F()], Q.prototype, "label", 2), Q = Mi([P("wcm-connector-waiting")], Q);
var Ni = {
	manualWallets() {
		let { mobileWallets: e, desktopWallets: t } = u.state, n = Ni.recentWallet()?.id, r = (o.isMobile() ? e : t)?.filter((e) => n !== e.id);
		return (o.isMobile() ? r?.map(({ id: e, name: t, links: n }) => ({
			id: e,
			name: t,
			mobile: n,
			links: n
		})) : r?.map(({ id: e, name: t, links: n }) => ({
			id: e,
			name: t,
			desktop: n,
			links: n
		}))) ?? [];
	},
	recentWallet() {
		return J.getRecentWallet();
	},
	recomendedWallets(e = !1) {
		let t = e ? void 0 : Ni.recentWallet()?.id, { recomendedWallets: n } = i.state;
		return n.filter((e) => t !== e.id);
	}
}, $ = {
	onConnecting(e) {
		J.goToConnectingView(e);
	},
	manualWalletsTemplate() {
		return Ni.manualWallets().map((e) => O`<wcm-wallet-button walletId="${e.id}" name="${e.name}" .onClick="${() => this.onConnecting(e)}"></wcm-wallet-button>`);
	},
	recomendedWalletsTemplate(e = !1) {
		return Ni.recomendedWallets(e).map((e) => O`<wcm-wallet-button name="${e.name}" walletId="${e.id}" imageId="${e.image_id}" .onClick="${() => this.onConnecting(e)}"></wcm-wallet-button>`);
	},
	recentWalletTemplate() {
		let e = Ni.recentWallet();
		if (e) return O`<wcm-wallet-button name="${e.name}" walletId="${e.id}" imageId="${V(e.image_id)}" .recent="${!0}" .onClick="${() => this.onConnecting(e)}"></wcm-wallet-button>`;
	}
}, Pi = _`.wcm-grid{display:grid;grid-template-columns:repeat(4,80px);justify-content:space-between}.wcm-desktop-title,.wcm-mobile-title{display:flex;align-items:center}.wcm-mobile-title{justify-content:space-between;margin-bottom:20px;margin-top:-10px}.wcm-desktop-title{margin-bottom:10px;padding:0 10px}.wcm-subtitle{display:flex;align-items:center}.wcm-subtitle:last-child path{fill:var(--wcm-color-fg-3)}.wcm-desktop-title svg,.wcm-mobile-title svg{margin-right:6px}.wcm-desktop-title path,.wcm-mobile-title path{fill:var(--wcm-accent-color)}`, Fi = Object.defineProperty, Ii = Object.getOwnPropertyDescriptor, Li = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ii(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Fi(t, n, i), i;
}, Ri = class extends N {
	render() {
		let { explorerExcludedWalletIds: e, enableExplorer: t } = u.state, n = e !== "ALL" && t, r = $.manualWalletsTemplate(), i = $.recomendedWalletsTemplate(), a = [
			$.recentWalletTemplate(),
			...r,
			...i
		];
		a = a.filter(Boolean);
		let o = a.length > 4 || n, s = [];
		s = o ? a.slice(0, 3) : a;
		let c = !!s.length;
		return O`<wcm-modal-header .border="${!0}" title="Connect your wallet" .onAction="${J.handleUriCopy}" .actionIcon="${K.COPY_ICON}"></wcm-modal-header><wcm-modal-content><div class="wcm-mobile-title"><div class="wcm-subtitle">${K.MOBILE_ICON}<wcm-text variant="small-regular" color="accent">Mobile</wcm-text></div><div class="wcm-subtitle">${K.SCAN_ICON}<wcm-text variant="small-regular" color="secondary">Scan with your wallet</wcm-text></div></div><wcm-walletconnect-qr></wcm-walletconnect-qr></wcm-modal-content>${c ? O`<wcm-modal-footer><div class="wcm-desktop-title">${K.DESKTOP_ICON}<wcm-text variant="small-regular" color="accent">Desktop</wcm-text></div><div class="wcm-grid">${s} ${o ? O`<wcm-view-all-wallets-button></wcm-view-all-wallets-button>` : null}</div></wcm-modal-footer>` : null}`;
	}
};
Ri.styles = [W.globalCss, Pi], Ri = Li([P("wcm-desktop-wallet-selection")], Ri);
var zi = _`div{background-color:var(--wcm-color-bg-2);padding:10px 20px 15px 20px;border-top:1px solid var(--wcm-color-bg-3);text-align:center}a{color:var(--wcm-accent-color);text-decoration:none;transition:opacity .2s ease-in-out;display:inline}a:active{opacity:.8}@media(hover:hover){a:hover{opacity:.8}}`, Bi = Object.defineProperty, Vi = Object.getOwnPropertyDescriptor, Hi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Vi(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Bi(t, n, i), i;
}, Ui = class extends N {
	render() {
		let { termsOfServiceUrl: e, privacyPolicyUrl: t } = u.state;
		return e ?? t ? O`<div><wcm-text variant="small-regular" color="secondary">By connecting your wallet to this app, you agree to the app's ${e ? O`<a href="${e}" target="_blank" rel="noopener noreferrer">Terms of Service</a>` : null} ${e && t ? "and" : null} ${t ? O`<a href="${t}" target="_blank" rel="noopener noreferrer">Privacy Policy</a>` : null}</wcm-text></div>` : null;
	}
};
Ui.styles = [W.globalCss, zi], Ui = Hi([P("wcm-legal-notice")], Ui);
var Wi = _`div{display:grid;grid-template-columns:repeat(4,80px);margin:0 -10px;justify-content:space-between;row-gap:10px}`, Gi = Object.defineProperty, Ki = Object.getOwnPropertyDescriptor, qi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ki(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Gi(t, n, i), i;
}, Ji = class extends N {
	onQrcode() {
		l.push("Qrcode");
	}
	render() {
		let { explorerExcludedWalletIds: e, enableExplorer: t } = u.state, n = e !== "ALL" && t, r = $.manualWalletsTemplate(), i = $.recomendedWalletsTemplate(), a = [
			$.recentWalletTemplate(),
			...r,
			...i
		];
		a = a.filter(Boolean);
		let o = a.length > 8 || n, s = [];
		s = o ? a.slice(0, 7) : a;
		let c = !!s.length;
		return O`<wcm-modal-header title="Connect your wallet" .onAction="${this.onQrcode}" .actionIcon="${K.QRCODE_ICON}"></wcm-modal-header>${c ? O`<wcm-modal-content><div>${s} ${o ? O`<wcm-view-all-wallets-button></wcm-view-all-wallets-button>` : null}</div></wcm-modal-content>` : null}`;
	}
};
Ji.styles = [W.globalCss, Wi], Ji = qi([P("wcm-mobile-wallet-selection")], Ji);
var Yi = _`:host{all:initial}.wcm-overlay{top:0;bottom:0;left:0;right:0;position:fixed;z-index:var(--wcm-z-index);overflow:hidden;display:flex;justify-content:center;align-items:center;opacity:0;pointer-events:none;background-color:var(--wcm-overlay-background-color);backdrop-filter:var(--wcm-overlay-backdrop-filter)}@media(max-height:720px) and (orientation:landscape){.wcm-overlay{overflow:scroll;align-items:flex-start;padding:20px 0}}.wcm-active{pointer-events:auto}.wcm-container{position:relative;max-width:360px;width:100%;outline:0;border-radius:var(--wcm-background-border-radius) var(--wcm-background-border-radius) var(--wcm-container-border-radius) var(--wcm-container-border-radius);border:1px solid var(--wcm-color-overlay);overflow:hidden}.wcm-card{width:100%;position:relative;border-radius:var(--wcm-container-border-radius);overflow:hidden;box-shadow:0 6px 14px -6px rgba(10,16,31,.12),0 10px 32px -4px rgba(10,16,31,.1),0 0 0 1px var(--wcm-color-overlay);background-color:var(--wcm-color-bg-1);color:var(--wcm-color-fg-1)}@media(max-width:600px){.wcm-container{max-width:440px;border-radius:var(--wcm-background-border-radius) var(--wcm-background-border-radius) 0 0}.wcm-card{border-radius:var(--wcm-container-border-radius) var(--wcm-container-border-radius) 0 0}.wcm-overlay{align-items:flex-end}}@media(max-width:440px){.wcm-container{border:0}}`, Xi = Object.defineProperty, Zi = Object.getOwnPropertyDescriptor, Qi = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Zi(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Xi(t, n, i), i;
}, $i = class extends N {
	constructor() {
		super(), this.open = !1, this.active = !1, this.unsubscribeModal = void 0, this.abortController = void 0, this.unsubscribeModal = t.subscribe((e) => {
			e.open ? this.onOpenModalEvent() : this.onCloseModalEvent();
		});
	}
	disconnectedCallback() {
		var e;
		(e = this.unsubscribeModal) == null || e.call(this);
	}
	get overlayEl() {
		return J.getShadowRootElement(this, ".wcm-overlay");
	}
	get containerEl() {
		return J.getShadowRootElement(this, ".wcm-container");
	}
	toggleBodyScroll(e) {
		document.querySelector("body") && (e ? document.getElementById("wcm-styles")?.remove() : document.head.insertAdjacentHTML("beforeend", "<style id=\"wcm-styles\">html,body{touch-action:none;overflow:hidden;overscroll-behavior:contain;}</style>"));
	}
	onCloseModal(e) {
		e.target === e.currentTarget && t.close();
	}
	onOpenModalEvent() {
		this.toggleBodyScroll(!1), this.addKeyboardEvents(), this.open = !0, setTimeout(async () => {
			let e = J.isMobileAnimation() ? { y: ["50vh", "0vh"] } : { scale: [.98, 1] }, t = .1, n = .2;
			await Promise.all([B(this.overlayEl, { opacity: [0, 1] }, {
				delay: t,
				duration: n
			}).finished, B(this.containerEl, e, {
				delay: t,
				duration: n
			}).finished]), this.active = !0;
		}, 0);
	}
	async onCloseModalEvent() {
		this.toggleBodyScroll(!0), this.removeKeyboardEvents();
		let e = J.isMobileAnimation() ? { y: ["0vh", "50vh"] } : { scale: [1, .98] }, t = .2;
		await Promise.all([B(this.overlayEl, { opacity: [1, 0] }, { duration: t }).finished, B(this.containerEl, e, { duration: t }).finished]), this.containerEl.removeAttribute("style"), this.active = !1, this.open = !1;
	}
	addKeyboardEvents() {
		this.abortController = new AbortController(), window.addEventListener("keydown", (e) => {
			e.key === "Escape" ? t.close() : e.key === "Tab" && (e.target?.tagName.includes("wcm-") || this.containerEl.focus());
		}, this.abortController), this.containerEl.focus();
	}
	removeKeyboardEvents() {
		var e;
		(e = this.abortController) == null || e.abort(), this.abortController = void 0;
	}
	render() {
		return O`<wcm-explorer-context></wcm-explorer-context><wcm-theme-context></wcm-theme-context><div id="wcm-modal" class="${L({
			"wcm-overlay": !0,
			"wcm-active": this.active
		})}" @click="${this.onCloseModal}" role="alertdialog" aria-modal="true"><div class="wcm-container" tabindex="0">${this.open ? O`<wcm-modal-backcard></wcm-modal-backcard><div class="wcm-card"><wcm-modal-router></wcm-modal-router><wcm-modal-toast></wcm-modal-toast></div>` : null}</div></div>`;
	}
};
$i.styles = [W.globalCss, Yi], Qi([I()], $i.prototype, "open", 2), Qi([I()], $i.prototype, "active", 2), $i = Qi([P("wcm-modal")], $i);
var ea = _`div{display:flex;margin-top:15px}slot{display:inline-block;margin:0 5px}wcm-button{margin:0 5px}`, ta = Object.defineProperty, na = Object.getOwnPropertyDescriptor, ra = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? na(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && ta(t, n, i), i;
}, ia = class extends N {
	constructor() {
		super(...arguments), this.isMobile = !1, this.isDesktop = !1, this.isWeb = !1, this.isRetry = !1;
	}
	onMobile() {
		o.isMobile() ? l.replace("MobileConnecting") : l.replace("MobileQrcodeConnecting");
	}
	onDesktop() {
		l.replace("DesktopConnecting");
	}
	onWeb() {
		l.replace("WebConnecting");
	}
	render() {
		return O`<div>${this.isRetry ? O`<slot></slot>` : null} ${this.isMobile ? O`<wcm-button .onClick="${this.onMobile}" .iconLeft="${K.MOBILE_ICON}" variant="outline">Mobile</wcm-button>` : null} ${this.isDesktop ? O`<wcm-button .onClick="${this.onDesktop}" .iconLeft="${K.DESKTOP_ICON}" variant="outline">Desktop</wcm-button>` : null} ${this.isWeb ? O`<wcm-button .onClick="${this.onWeb}" .iconLeft="${K.GLOBE_ICON}" variant="outline">Web</wcm-button>` : null}</div>`;
	}
};
ia.styles = [W.globalCss, ea], ra([F({ type: Boolean })], ia.prototype, "isMobile", 2), ra([F({ type: Boolean })], ia.prototype, "isDesktop", 2), ra([F({ type: Boolean })], ia.prototype, "isWeb", 2), ra([F({ type: Boolean })], ia.prototype, "isRetry", 2), ia = ra([P("wcm-platform-selection")], ia);
var aa = _`button{display:flex;flex-direction:column;padding:5px 10px;border-radius:var(--wcm-button-hover-highlight-border-radius);height:100%;justify-content:flex-start}.wcm-icons{width:60px;height:60px;display:flex;flex-wrap:wrap;padding:7px;border-radius:var(--wcm-wallet-icon-border-radius);justify-content:space-between;align-items:center;margin-bottom:5px;background-color:var(--wcm-color-bg-2);box-shadow:inset 0 0 0 1px var(--wcm-color-overlay)}button:active{background-color:var(--wcm-color-overlay)}@media(hover:hover){button:hover{background-color:var(--wcm-color-overlay)}}.wcm-icons img{width:21px;height:21px;object-fit:cover;object-position:center;border-radius:calc(var(--wcm-wallet-icon-border-radius)/ 2);border:1px solid var(--wcm-color-overlay)}.wcm-icons svg{width:21px;height:21px}.wcm-icons img:nth-child(1),.wcm-icons img:nth-child(2),.wcm-icons svg:nth-child(1),.wcm-icons svg:nth-child(2){margin-bottom:4px}wcm-text{width:100%;text-align:center}#wallet-placeholder-fill{fill:var(--wcm-color-bg-3)}#wallet-placeholder-dash{stroke:var(--wcm-color-overlay)}`, oa = Object.defineProperty, sa = Object.getOwnPropertyDescriptor, ca = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? sa(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && oa(t, n, i), i;
}, la = class extends N {
	onClick() {
		l.push("WalletExplorer");
	}
	render() {
		let { recomendedWallets: e } = i.state, t = Ni.manualWallets(), n = [...e, ...t].reverse().slice(0, 4);
		return O`<button @click="${this.onClick}"><div class="wcm-icons">${n.map((e) => {
			let t = J.getWalletIcon(e);
			if (t) return O`<img crossorigin="anonymous" src="${t}">`;
			let n = J.getWalletIcon({ id: e.id });
			return n ? O`<img crossorigin="anonymous" src="${n}">` : K.WALLET_PLACEHOLDER;
		})} ${[...Array(4 - n.length)].map(() => K.WALLET_PLACEHOLDER)}</div><wcm-text variant="xsmall-regular">View All</wcm-text></button>`;
	}
};
la.styles = [W.globalCss, aa], la = ca([P("wcm-view-all-wallets-button")], la);
var ua = _`.wcm-qr-container{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1/1}`, da = Object.defineProperty, fa = Object.getOwnPropertyDescriptor, pa = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? fa(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && da(t, n, i), i;
}, ma = class extends N {
	constructor() {
		super(), this.walletId = "", this.imageId = "", this.uri = "", setTimeout(() => {
			let { walletConnectUri: e } = s.state;
			this.uri = e;
		}, 0);
	}
	get overlayEl() {
		return J.getShadowRootElement(this, ".wcm-qr-container");
	}
	render() {
		return O`<div class="wcm-qr-container">${this.uri ? O`<wcm-qrcode size="${this.overlayEl.offsetWidth}" uri="${this.uri}" walletId="${V(this.walletId)}" imageId="${V(this.imageId)}"></wcm-qrcode>` : O`<wcm-spinner></wcm-spinner>`}</div>`;
	}
};
ma.styles = [W.globalCss, ua], pa([F()], ma.prototype, "walletId", 2), pa([F()], ma.prototype, "imageId", 2), pa([I()], ma.prototype, "uri", 2), ma = pa([P("wcm-walletconnect-qr")], ma);
var ha = Object.defineProperty, ga = Object.getOwnPropertyDescriptor, _a = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ga(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && ha(t, n, i), i;
}, va = class extends N {
	viewTemplate() {
		return o.isAndroid() && !o.isTelegram() ? O`<wcm-android-wallet-selection></wcm-android-wallet-selection>` : o.isMobile() ? O`<wcm-mobile-wallet-selection></wcm-mobile-wallet-selection>` : O`<wcm-desktop-wallet-selection></wcm-desktop-wallet-selection>`;
	}
	render() {
		return O`${this.viewTemplate()}<wcm-legal-notice></wcm-legal-notice>`;
	}
};
va.styles = [W.globalCss], va = _a([P("wcm-connect-wallet-view")], va);
var ya = _`wcm-info-footer{flex-direction:column;align-items:center;display:flex;width:100%;padding:5px 0}wcm-text{text-align:center}`, ba = Object.defineProperty, xa = Object.getOwnPropertyDescriptor, Sa = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? xa(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && ba(t, n, i), i;
}, Ca = class extends N {
	constructor() {
		super(), this.isError = !1, this.openDesktopApp();
	}
	onFormatAndRedirect(e) {
		let { desktop: t, name: n } = o.getWalletRouterData(), r = t?.native, i = t?.universal;
		if (r) {
			let t = o.formatNativeUrl(r, e, n);
			o.openHref(t, "_self");
		} else if (i) {
			let t = o.formatUniversalUrl(i, e, n);
			o.openHref(t, "_blank");
		}
	}
	openDesktopApp() {
		let { walletConnectUri: e } = s.state, t = o.getWalletRouterData();
		J.setRecentWallet(t), e && this.onFormatAndRedirect(e);
	}
	render() {
		let { name: e, id: t, image_id: n } = o.getWalletRouterData(), { isMobile: r, isWeb: i } = J.getCachedRouterWalletPlatforms();
		return O`<wcm-modal-header title="${e}" .onAction="${J.handleUriCopy}" .actionIcon="${K.COPY_ICON}"></wcm-modal-header><wcm-modal-content><wcm-connector-waiting walletId="${t}" imageId="${V(n)}" label="${`Continue in ${e}...`}" .isError="${this.isError}"></wcm-connector-waiting></wcm-modal-content><wcm-info-footer><wcm-text color="secondary" variant="small-thin">${`Connection can continue loading if ${e} is not installed on your device`}</wcm-text><wcm-platform-selection .isMobile="${r}" .isWeb="${i}" .isRetry="${!0}"><wcm-button .onClick="${this.openDesktopApp.bind(this)}" .iconRight="${K.RETRY_ICON}">Retry</wcm-button></wcm-platform-selection></wcm-info-footer>`;
	}
};
Ca.styles = [W.globalCss, ya], Sa([I()], Ca.prototype, "isError", 2), Ca = Sa([P("wcm-desktop-connecting-view")], Ca);
var wa = _`wcm-info-footer{flex-direction:column;align-items:center;display:flex;width:100%;padding:5px 0}wcm-text{text-align:center}wcm-button{margin-top:15px}`, Ta = Object.defineProperty, Ea = Object.getOwnPropertyDescriptor, Da = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ea(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Ta(t, n, i), i;
}, Oa = class extends N {
	onInstall(e) {
		e && o.openHref(e, "_blank");
	}
	render() {
		let { name: e, id: t, image_id: n, homepage: r } = o.getWalletRouterData();
		return O`<wcm-modal-header title="${e}"></wcm-modal-header><wcm-modal-content><wcm-connector-waiting walletId="${t}" imageId="${V(n)}" label="Not Detected" .isStale="${!0}"></wcm-connector-waiting></wcm-modal-content><wcm-info-footer><wcm-text color="secondary" variant="small-thin">${`Download ${e} to continue. If multiple browser extensions are installed, disable non ${e} ones and try again`}</wcm-text><wcm-button .onClick="${() => this.onInstall(r)}" .iconLeft="${K.ARROW_DOWN_ICON}">Download</wcm-button></wcm-info-footer>`;
	}
};
Oa.styles = [W.globalCss, wa], Oa = Da([P("wcm-install-wallet-view")], Oa);
var ka = _`wcm-wallet-image{border-radius:var(--wcm-wallet-icon-large-border-radius);width:96px;height:96px;margin-bottom:20px}wcm-info-footer{display:flex;width:100%}.wcm-app-store{justify-content:space-between}.wcm-app-store wcm-wallet-image{margin-right:10px;margin-bottom:0;width:28px;height:28px;border-radius:var(--wcm-wallet-icon-small-border-radius)}.wcm-app-store div{display:flex;align-items:center}.wcm-app-store wcm-button{margin-right:-10px}.wcm-note{flex-direction:column;align-items:center;padding:5px 0}.wcm-note wcm-text{text-align:center}wcm-platform-selection{margin-top:-15px}.wcm-note wcm-text{margin-top:15px}.wcm-note wcm-text span{color:var(--wcm-accent-color)}`, Aa = Object.defineProperty, ja = Object.getOwnPropertyDescriptor, Ma = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? ja(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Aa(t, n, i), i;
}, Na = class extends N {
	constructor() {
		super(), this.isError = !1, this.openMobileApp();
	}
	onFormatAndRedirect(e, t = !1) {
		let { mobile: n, name: r } = o.getWalletRouterData(), i = n?.native, a = n?.universal, s = o.isTelegram() ? "_blank" : "_self";
		if (e = o.isTelegram() && o.isAndroid() ? encodeURIComponent(e) : e, i && !t) {
			let t = o.formatNativeUrl(i, e, r);
			o.openHref(t, s);
		} else if (a) {
			let t = o.formatUniversalUrl(a, e, r);
			o.openHref(t, s);
		}
	}
	openMobileApp(e = !1) {
		let { walletConnectUri: t } = s.state, n = o.getWalletRouterData();
		t && this.onFormatAndRedirect(t, e), J.setRecentWallet(n);
	}
	onGoToAppStore(e) {
		e && o.openHref(e, "_blank");
	}
	render() {
		let { name: e, id: t, image_id: n, app: r, mobile: i } = o.getWalletRouterData(), { isWeb: a } = J.getCachedRouterWalletPlatforms(), s = r?.ios, c = i?.universal;
		return O`<wcm-modal-header title="${e}"></wcm-modal-header><wcm-modal-content><wcm-connector-waiting walletId="${t}" imageId="${V(n)}" label="Tap 'Open' to continue…" .isError="${this.isError}"></wcm-connector-waiting></wcm-modal-content><wcm-info-footer class="wcm-note"><wcm-platform-selection .isWeb="${a}" .isRetry="${!0}"><wcm-button .onClick="${() => this.openMobileApp(!1)}" .iconRight="${K.RETRY_ICON}">Retry</wcm-button></wcm-platform-selection>${c ? O`<wcm-text color="secondary" variant="small-thin">Still doesn't work? <span tabindex="0" @click="${() => this.openMobileApp(!0)}">Try this alternate link</span></wcm-text>` : null}</wcm-info-footer><wcm-info-footer class="wcm-app-store"><div><wcm-wallet-image walletId="${t}" imageId="${V(n)}"></wcm-wallet-image><wcm-text>${`Get ${e}`}</wcm-text></div><wcm-button .iconRight="${K.ARROW_RIGHT_ICON}" .onClick="${() => this.onGoToAppStore(s)}" variant="ghost">App Store</wcm-button></wcm-info-footer>`;
	}
};
Na.styles = [W.globalCss, ka], Ma([I()], Na.prototype, "isError", 2), Na = Ma([P("wcm-mobile-connecting-view")], Na);
var Pa = _`wcm-info-footer{flex-direction:column;align-items:center;display:flex;width:100%;padding:5px 0}wcm-text{text-align:center}`, Fa = Object.defineProperty, Ia = Object.getOwnPropertyDescriptor, La = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ia(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Fa(t, n, i), i;
}, Ra = class extends N {
	render() {
		let { name: e, id: t, image_id: n } = o.getWalletRouterData(), { isDesktop: r, isWeb: i } = J.getCachedRouterWalletPlatforms();
		return O`<wcm-modal-header title="${e}" .onAction="${J.handleUriCopy}" .actionIcon="${K.COPY_ICON}"></wcm-modal-header><wcm-modal-content><wcm-walletconnect-qr walletId="${t}" imageId="${V(n)}"></wcm-walletconnect-qr></wcm-modal-content><wcm-info-footer><wcm-text color="secondary" variant="small-thin">${`Scan this QR Code with your phone's camera or inside ${e} app`}</wcm-text><wcm-platform-selection .isDesktop="${r}" .isWeb="${i}"></wcm-platform-selection></wcm-info-footer>`;
	}
};
Ra.styles = [W.globalCss, Pa], Ra = La([P("wcm-mobile-qr-connecting-view")], Ra);
var za = Object.defineProperty, Ba = Object.getOwnPropertyDescriptor, Va = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ba(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && za(t, n, i), i;
}, Ha = class extends N {
	render() {
		return O`<wcm-modal-header title="Scan the code" .onAction="${J.handleUriCopy}" .actionIcon="${K.COPY_ICON}"></wcm-modal-header><wcm-modal-content><wcm-walletconnect-qr></wcm-walletconnect-qr></wcm-modal-content>`;
	}
};
Ha.styles = [W.globalCss], Ha = Va([P("wcm-qrcode-view")], Ha);
var Ua = _`wcm-modal-content{height:clamp(200px,60vh,600px);display:block;overflow:scroll;scrollbar-width:none;position:relative;margin-top:1px}.wcm-grid{display:grid;grid-template-columns:repeat(4,80px);justify-content:space-between;margin:-15px -10px;padding-top:20px}wcm-modal-content::after,wcm-modal-content::before{content:'';position:fixed;pointer-events:none;z-index:1;width:100%;height:20px;opacity:1}wcm-modal-content::before{box-shadow:0 -1px 0 0 var(--wcm-color-bg-1);background:linear-gradient(var(--wcm-color-bg-1),rgba(255,255,255,0))}wcm-modal-content::after{box-shadow:0 1px 0 0 var(--wcm-color-bg-1);background:linear-gradient(rgba(255,255,255,0),var(--wcm-color-bg-1));top:calc(100% - 20px)}wcm-modal-content::-webkit-scrollbar{display:none}.wcm-placeholder-block{display:flex;justify-content:center;align-items:center;height:100px;overflow:hidden}.wcm-empty,.wcm-loading{display:flex}.wcm-loading .wcm-placeholder-block{height:100%}.wcm-end-reached .wcm-placeholder-block{height:0;opacity:0}.wcm-empty .wcm-placeholder-block{opacity:1;height:100%}wcm-wallet-button{margin:calc((100% - 60px)/ 3) 0}`, Wa = Object.defineProperty, Ga = Object.getOwnPropertyDescriptor, Ka = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Ga(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Wa(t, n, i), i;
}, qa = 40, Ja = class extends N {
	constructor() {
		super(...arguments), this.loading = !i.state.wallets.listings.length, this.firstFetch = !i.state.wallets.listings.length, this.search = "", this.endReached = !1, this.intersectionObserver = void 0, this.searchDebounce = J.debounce((e) => {
			e.length >= 1 ? (this.firstFetch = !0, this.endReached = !1, this.search = e, i.resetSearch(), this.fetchWallets()) : this.search && (this.search = "", this.endReached = this.isLastPage(), i.resetSearch());
		});
	}
	firstUpdated() {
		this.createPaginationObserver();
	}
	disconnectedCallback() {
		var e;
		(e = this.intersectionObserver) == null || e.disconnect();
	}
	get placeholderEl() {
		return J.getShadowRootElement(this, ".wcm-placeholder-block");
	}
	createPaginationObserver() {
		this.intersectionObserver = new IntersectionObserver(([e]) => {
			e.isIntersecting && !(this.search && this.firstFetch) && this.fetchWallets();
		}), this.intersectionObserver.observe(this.placeholderEl);
	}
	isLastPage() {
		let { wallets: e, search: t } = i.state, { listings: n, total: r } = this.search ? t : e;
		return r <= qa || n.length >= r;
	}
	async fetchWallets() {
		let { wallets: e, search: t } = i.state, { listings: n, total: r, page: c } = this.search ? t : e;
		if (!this.endReached && (this.firstFetch || r > qa && n.length < r)) try {
			this.loading = !0;
			let e = s.state.chains?.join(","), { listings: t } = await i.getWallets({
				page: this.firstFetch ? 1 : c + 1,
				entries: qa,
				search: this.search,
				version: 2,
				chains: e
			}), n = t.map((e) => J.getWalletIcon(e));
			await Promise.all([...n.map(async (e) => J.preloadImage(e)), o.wait(300)]), this.endReached = this.isLastPage();
		} catch (e) {
			console.error(e), a.openToast(J.getErrorMessage(e), "error");
		} finally {
			this.loading = !1, this.firstFetch = !1;
		}
	}
	onConnect(e) {
		o.isAndroid() ? J.handleMobileLinking(e) : J.goToConnectingView(e);
	}
	onSearchChange(e) {
		let { value: t } = e.target;
		this.searchDebounce(t);
	}
	render() {
		let { wallets: e, search: t } = i.state, { listings: n } = this.search ? t : e, r = this.loading && !n.length, a = this.search.length >= 3, o = $.manualWalletsTemplate(), s = $.recomendedWalletsTemplate(!0);
		a && (o = o.filter(({ values: e }) => J.caseSafeIncludes(e[0], this.search)), s = s.filter(({ values: e }) => J.caseSafeIncludes(e[0], this.search)));
		let c = !this.loading && !n.length && !s.length, l = {
			"wcm-loading": r,
			"wcm-end-reached": this.endReached || !this.loading,
			"wcm-empty": c
		};
		return O`<wcm-modal-header><wcm-search-input .onChange="${this.onSearchChange.bind(this)}"></wcm-search-input></wcm-modal-header><wcm-modal-content class="${L(l)}"><div class="wcm-grid">${r ? null : o} ${r ? null : s} ${r ? null : n.map((e) => O`${e ? O`<wcm-wallet-button imageId="${e.image_id}" name="${e.name}" walletId="${e.id}" .onClick="${() => this.onConnect(e)}"></wcm-wallet-button>` : null}`)}</div><div class="wcm-placeholder-block">${c ? O`<wcm-text variant="big-bold" color="secondary">No results found</wcm-text>` : null} ${!c && this.loading ? O`<wcm-spinner></wcm-spinner>` : null}</div></wcm-modal-content>`;
	}
};
Ja.styles = [W.globalCss, Ua], Ka([I()], Ja.prototype, "loading", 2), Ka([I()], Ja.prototype, "firstFetch", 2), Ka([I()], Ja.prototype, "search", 2), Ka([I()], Ja.prototype, "endReached", 2), Ja = Ka([P("wcm-wallet-explorer-view")], Ja);
var Ya = _`wcm-info-footer{flex-direction:column;align-items:center;display:flex;width:100%;padding:5px 0}wcm-text{text-align:center}`, Xa = Object.defineProperty, Za = Object.getOwnPropertyDescriptor, Qa = (e, t, n, r) => {
	for (var i = r > 1 ? void 0 : r ? Za(t, n) : t, a = e.length - 1, o; a >= 0; a--) (o = e[a]) && (i = (r ? o(t, n, i) : o(i)) || i);
	return r && i && Xa(t, n, i), i;
}, $a = class extends N {
	constructor() {
		super(), this.isError = !1, this.openWebWallet();
	}
	onFormatAndRedirect(e) {
		let { desktop: t, name: n } = o.getWalletRouterData(), r = t?.universal;
		if (r) {
			let t = o.formatUniversalUrl(r, e, n);
			o.openHref(t, "_blank");
		}
	}
	openWebWallet() {
		let { walletConnectUri: e } = s.state, t = o.getWalletRouterData();
		J.setRecentWallet(t), e && this.onFormatAndRedirect(e);
	}
	render() {
		let { name: e, id: t, image_id: n } = o.getWalletRouterData(), { isMobile: r, isDesktop: i } = J.getCachedRouterWalletPlatforms(), a = o.isMobile();
		return O`<wcm-modal-header title="${e}" .onAction="${J.handleUriCopy}" .actionIcon="${K.COPY_ICON}"></wcm-modal-header><wcm-modal-content><wcm-connector-waiting walletId="${t}" imageId="${V(n)}" label="${`Continue in ${e}...`}" .isError="${this.isError}"></wcm-connector-waiting></wcm-modal-content><wcm-info-footer><wcm-text color="secondary" variant="small-thin">${`${e} web app has opened in a new tab. Go there, accept the connection, and come back`}</wcm-text><wcm-platform-selection .isMobile="${r}" .isDesktop="${!a && i}" .isRetry="${!0}"><wcm-button .onClick="${this.openWebWallet.bind(this)}" .iconRight="${K.RETRY_ICON}">Retry</wcm-button></wcm-platform-selection></wcm-info-footer>`;
	}
};
$a.styles = [W.globalCss, Ya], Qa([I()], $a.prototype, "isError", 2), $a = Qa([P("wcm-web-connecting-view")], $a);
//#endregion
