//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t, n) => () => {
	if (n) throw n[0];
	try {
		return e && (t = e(e = 0)), t;
	} catch (e) {
		throw n = [e], e;
	}
}, s = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), c = (e, n) => {
	let r = {};
	for (var i in e) t(r, i, {
		get: e[i],
		enumerable: !0
	});
	return n || t(r, Symbol.toStringTag, { value: "Module" }), r;
}, l = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, u = (e, t, n) => (l(e, t, "default"), n && l(n, t, "default")), d = (n, r, a) => (a = n == null ? {} : e(i(n)), l(r || !n || !n.__esModule ? t(a, "default", {
	value: n,
	enumerable: !0
}) : a, n)), f = (e) => a.call(e, "module.exports") ? e["module.exports"] : l(t({}, "__esModule", { value: !0 }), e), p = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, { get: (e, t) => (typeof require < "u" ? require : e)[t] }) : e)(function(e) {
	if (typeof require < "u") return require.apply(this, arguments);
	throw Error("Calling `require` for \"" + e + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
}), m = /* @__PURE__ */ s(((e) => {
	e.byteLength = c, e.toByteArray = u, e.fromByteArray = p;
	for (var t = [], n = [], r = typeof Uint8Array < "u" ? Uint8Array : Array, i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, o = i.length; a < o; ++a) t[a] = i[a], n[i.charCodeAt(a)] = a;
	n[45] = 62, n[95] = 63;
	function s(e) {
		var t = e.length;
		if (t % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
		var n = e.indexOf("=");
		n === -1 && (n = t);
		var r = n === t ? 0 : 4 - n % 4;
		return [n, r];
	}
	function c(e) {
		var t = s(e), n = t[0], r = t[1];
		return (n + r) * 3 / 4 - r;
	}
	function l(e, t, n) {
		return (t + n) * 3 / 4 - n;
	}
	function u(e) {
		var t, i = s(e), a = i[0], o = i[1], c = new r(l(e, a, o)), u = 0, d = o > 0 ? a - 4 : a, f;
		for (f = 0; f < d; f += 4) t = n[e.charCodeAt(f)] << 18 | n[e.charCodeAt(f + 1)] << 12 | n[e.charCodeAt(f + 2)] << 6 | n[e.charCodeAt(f + 3)], c[u++] = t >> 16 & 255, c[u++] = t >> 8 & 255, c[u++] = t & 255;
		return o === 2 && (t = n[e.charCodeAt(f)] << 2 | n[e.charCodeAt(f + 1)] >> 4, c[u++] = t & 255), o === 1 && (t = n[e.charCodeAt(f)] << 10 | n[e.charCodeAt(f + 1)] << 4 | n[e.charCodeAt(f + 2)] >> 2, c[u++] = t >> 8 & 255, c[u++] = t & 255), c;
	}
	function d(e) {
		return t[e >> 18 & 63] + t[e >> 12 & 63] + t[e >> 6 & 63] + t[e & 63];
	}
	function f(e, t, n) {
		for (var r, i = [], a = t; a < n; a += 3) r = (e[a] << 16 & 16711680) + (e[a + 1] << 8 & 65280) + (e[a + 2] & 255), i.push(d(r));
		return i.join("");
	}
	function p(e) {
		for (var n, r = e.length, i = r % 3, a = [], o = 16383, s = 0, c = r - i; s < c; s += o) a.push(f(e, s, s + o > c ? c : s + o));
		return i === 1 ? (n = e[r - 1], a.push(t[n >> 2] + t[n << 4 & 63] + "==")) : i === 2 && (n = (e[r - 2] << 8) + e[r - 1], a.push(t[n >> 10] + t[n >> 4 & 63] + t[n << 2 & 63] + "=")), a.join("");
	}
})), h = /* @__PURE__ */ s(((e) => {
	e.read = function(e, t, n, r, i) {
		var a, o, s = i * 8 - r - 1, c = (1 << s) - 1, l = c >> 1, u = -7, d = n ? i - 1 : 0, f = n ? -1 : 1, p = e[t + d];
		for (d += f, a = p & (1 << -u) - 1, p >>= -u, u += s; u > 0; a = a * 256 + e[t + d], d += f, u -= 8);
		for (o = a & (1 << -u) - 1, a >>= -u, u += r; u > 0; o = o * 256 + e[t + d], d += f, u -= 8);
		if (a === 0) a = 1 - l;
		else if (a === c) return o ? NaN : (p ? -1 : 1) * Infinity;
		else o += 2 ** r, a -= l;
		return (p ? -1 : 1) * o * 2 ** (a - r);
	}, e.write = function(e, t, n, r, i, a) {
		var o, s, c, l = a * 8 - i - 1, u = (1 << l) - 1, d = u >> 1, f = i === 23 ? 2 ** -24 - 2 ** -77 : 0, p = r ? 0 : a - 1, m = r ? 1 : -1, h = +(t < 0 || t === 0 && 1 / t < 0);
		for (t = Math.abs(t), isNaN(t) || t === Infinity ? (s = +!!isNaN(t), o = u) : (o = Math.floor(Math.log(t) / Math.LN2), t * (c = 2 ** -o) < 1 && (o--, c *= 2), o + d >= 1 ? t += f / c : t += f * 2 ** (1 - d), t * c >= 2 && (o++, c /= 2), o + d >= u ? (s = 0, o = u) : o + d >= 1 ? (s = (t * c - 1) * 2 ** i, o += d) : (s = t * 2 ** (d - 1) * 2 ** i, o = 0)); i >= 8; e[n + p] = s & 255, p += m, s /= 256, i -= 8);
		for (o = o << i | s, l += i; l > 0; e[n + p] = o & 255, p += m, o /= 256, l -= 8);
		e[n + p - m] |= h * 128;
	};
})), g = /* @__PURE__ */ s(((e) => {
	var t = m(), n = h(), r = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
	e.Buffer = s, e.SlowBuffer = y, e.INSPECT_MAX_BYTES = 50;
	var i = 2147483647;
	e.kMaxLength = i, s.TYPED_ARRAY_SUPPORT = a(), !s.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
	function a() {
		try {
			let e = /* @__PURE__ */ new Uint8Array(1), t = { foo: function() {
				return 42;
			} };
			return Object.setPrototypeOf(t, Uint8Array.prototype), Object.setPrototypeOf(e, t), e.foo() === 42;
		} catch {
			return !1;
		}
	}
	Object.defineProperty(s.prototype, "parent", {
		enumerable: !0,
		get: function() {
			if (s.isBuffer(this)) return this.buffer;
		}
	}), Object.defineProperty(s.prototype, "offset", {
		enumerable: !0,
		get: function() {
			if (s.isBuffer(this)) return this.byteOffset;
		}
	});
	function o(e) {
		if (e > i) throw RangeError("The value \"" + e + "\" is invalid for option \"size\"");
		let t = new Uint8Array(e);
		return Object.setPrototypeOf(t, s.prototype), t;
	}
	function s(e, t, n) {
		if (typeof e == "number") {
			if (typeof t == "string") throw TypeError("The \"string\" argument must be of type string. Received type number");
			return d(e);
		}
		return c(e, t, n);
	}
	s.poolSize = 8192;
	function c(e, t, n) {
		if (typeof e == "string") return f(e, t);
		if (ArrayBuffer.isView(e)) return g(e);
		if (e == null) throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
		if (Y(e, ArrayBuffer) || e && Y(e.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (Y(e, SharedArrayBuffer) || e && Y(e.buffer, SharedArrayBuffer))) return _(e, t, n);
		if (typeof e == "number") throw TypeError("The \"value\" argument must not be of type number. Received type number");
		let r = e.valueOf && e.valueOf();
		if (r != null && r !== e) return s.from(r, t, n);
		let i = ee(e);
		if (i) return i;
		if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof e[Symbol.toPrimitive] == "function") return s.from(e[Symbol.toPrimitive]("string"), t, n);
		throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
	}
	s.from = function(e, t, n) {
		return c(e, t, n);
	}, Object.setPrototypeOf(s.prototype, Uint8Array.prototype), Object.setPrototypeOf(s, Uint8Array);
	function l(e) {
		if (typeof e != "number") throw TypeError("\"size\" argument must be of type number");
		if (e < 0) throw RangeError("The value \"" + e + "\" is invalid for option \"size\"");
	}
	function u(e, t, n) {
		return l(e), e <= 0 || t === void 0 ? o(e) : typeof n == "string" ? o(e).fill(t, n) : o(e).fill(t);
	}
	s.alloc = function(e, t, n) {
		return u(e, t, n);
	};
	function d(e) {
		return l(e), o(e < 0 ? 0 : v(e) | 0);
	}
	s.allocUnsafe = function(e) {
		return d(e);
	}, s.allocUnsafeSlow = function(e) {
		return d(e);
	};
	function f(e, t) {
		if ((typeof t != "string" || t === "") && (t = "utf8"), !s.isEncoding(t)) throw TypeError("Unknown encoding: " + t);
		let n = b(e, t) | 0, r = o(n), i = r.write(e, t);
		return i !== n && (r = r.slice(0, i)), r;
	}
	function p(e) {
		let t = e.length < 0 ? 0 : v(e.length) | 0, n = o(t);
		for (let r = 0; r < t; r += 1) n[r] = e[r] & 255;
		return n;
	}
	function g(e) {
		if (Y(e, Uint8Array)) {
			let t = new Uint8Array(e);
			return _(t.buffer, t.byteOffset, t.byteLength);
		}
		return p(e);
	}
	function _(e, t, n) {
		if (t < 0 || e.byteLength < t) throw RangeError("\"offset\" is outside of buffer bounds");
		if (e.byteLength < t + (n || 0)) throw RangeError("\"length\" is outside of buffer bounds");
		let r;
		return r = t === void 0 && n === void 0 ? new Uint8Array(e) : n === void 0 ? new Uint8Array(e, t) : new Uint8Array(e, t, n), Object.setPrototypeOf(r, s.prototype), r;
	}
	function ee(e) {
		if (s.isBuffer(e)) {
			let t = v(e.length) | 0, n = o(t);
			return n.length === 0 || e.copy(n, 0, 0, t), n;
		}
		if (e.length !== void 0) return typeof e.length != "number" || X(e.length) ? o(0) : p(e);
		if (e.type === "Buffer" && Array.isArray(e.data)) return p(e.data);
	}
	function v(e) {
		if (e >= i) throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + i.toString(16) + " bytes");
		return e | 0;
	}
	function y(e) {
		return +e != e && (e = 0), s.alloc(+e);
	}
	s.isBuffer = function(e) {
		return e != null && e._isBuffer === !0 && e !== s.prototype;
	}, s.compare = function(e, t) {
		if (Y(e, Uint8Array) && (e = s.from(e, e.offset, e.byteLength)), Y(t, Uint8Array) && (t = s.from(t, t.offset, t.byteLength)), !s.isBuffer(e) || !s.isBuffer(t)) throw TypeError("The \"buf1\", \"buf2\" arguments must be one of type Buffer or Uint8Array");
		if (e === t) return 0;
		let n = e.length, r = t.length;
		for (let i = 0, a = Math.min(n, r); i < a; ++i) if (e[i] !== t[i]) {
			n = e[i], r = t[i];
			break;
		}
		return n < r ? -1 : +(r < n);
	}, s.isEncoding = function(e) {
		switch (String(e).toLowerCase()) {
			case "hex":
			case "utf8":
			case "utf-8":
			case "ascii":
			case "latin1":
			case "binary":
			case "base64":
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return !0;
			default: return !1;
		}
	}, s.concat = function(e, t) {
		if (!Array.isArray(e)) throw TypeError("\"list\" argument must be an Array of Buffers");
		if (e.length === 0) return s.alloc(0);
		let n;
		if (t === void 0) for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
		let r = s.allocUnsafe(t), i = 0;
		for (n = 0; n < e.length; ++n) {
			let t = e[n];
			if (Y(t, Uint8Array)) i + t.length > r.length ? (s.isBuffer(t) || (t = s.from(t)), t.copy(r, i)) : Uint8Array.prototype.set.call(r, t, i);
			else if (s.isBuffer(t)) t.copy(r, i);
			else throw TypeError("\"list\" argument must be an Array of Buffers");
			i += t.length;
		}
		return r;
	};
	function b(e, t) {
		if (s.isBuffer(e)) return e.length;
		if (ArrayBuffer.isView(e) || Y(e, ArrayBuffer)) return e.byteLength;
		if (typeof e != "string") throw TypeError("The \"string\" argument must be one of type string, Buffer, or ArrayBuffer. Received type " + typeof e);
		let n = e.length, r = arguments.length > 2 && arguments[2] === !0;
		if (!r && n === 0) return 0;
		let i = !1;
		for (;;) switch (t) {
			case "ascii":
			case "latin1":
			case "binary": return n;
			case "utf8":
			case "utf-8": return K(e).length;
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return n * 2;
			case "hex": return n >>> 1;
			case "base64": return q(e).length;
			default:
				if (i) return r ? -1 : K(e).length;
				t = ("" + t).toLowerCase(), i = !0;
		}
	}
	s.byteLength = b;
	function te(e, t, n) {
		let r = !1;
		if ((t === void 0 || t < 0) && (t = 0), t > this.length || ((n === void 0 || n > this.length) && (n = this.length), n <= 0) || (n >>>= 0, t >>>= 0, n <= t)) return "";
		for (e ||= "utf8";;) switch (e) {
			case "hex": return M(this, t, n);
			case "utf8":
			case "utf-8": return O(this, t, n);
			case "ascii": return ie(this, t, n);
			case "latin1":
			case "binary": return j(this, t, n);
			case "base64": return D(this, t, n);
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return N(this, t, n);
			default:
				if (r) throw TypeError("Unknown encoding: " + e);
				e = (e + "").toLowerCase(), r = !0;
		}
	}
	s.prototype._isBuffer = !0;
	function x(e, t, n) {
		let r = e[t];
		e[t] = e[n], e[n] = r;
	}
	s.prototype.swap16 = function() {
		let e = this.length;
		if (e % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
		for (let t = 0; t < e; t += 2) x(this, t, t + 1);
		return this;
	}, s.prototype.swap32 = function() {
		let e = this.length;
		if (e % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
		for (let t = 0; t < e; t += 4) x(this, t, t + 3), x(this, t + 1, t + 2);
		return this;
	}, s.prototype.swap64 = function() {
		let e = this.length;
		if (e % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
		for (let t = 0; t < e; t += 8) x(this, t, t + 7), x(this, t + 1, t + 6), x(this, t + 2, t + 5), x(this, t + 3, t + 4);
		return this;
	}, s.prototype.toString = function() {
		let e = this.length;
		return e === 0 ? "" : arguments.length === 0 ? O(this, 0, e) : te.apply(this, arguments);
	}, s.prototype.toLocaleString = s.prototype.toString, s.prototype.equals = function(e) {
		if (!s.isBuffer(e)) throw TypeError("Argument must be a Buffer");
		return this === e || s.compare(this, e) === 0;
	}, s.prototype.inspect = function() {
		let t = "", n = e.INSPECT_MAX_BYTES;
		return t = this.toString("hex", 0, n).replace(/(.{2})/g, "$1 ").trim(), this.length > n && (t += " ... "), "<Buffer " + t + ">";
	}, r && (s.prototype[r] = s.prototype.inspect), s.prototype.compare = function(e, t, n, r, i) {
		if (Y(e, Uint8Array) && (e = s.from(e, e.offset, e.byteLength)), !s.isBuffer(e)) throw TypeError("The \"target\" argument must be one of type Buffer or Uint8Array. Received type " + typeof e);
		if (t === void 0 && (t = 0), n === void 0 && (n = e ? e.length : 0), r === void 0 && (r = 0), i === void 0 && (i = this.length), t < 0 || n > e.length || r < 0 || i > this.length) throw RangeError("out of range index");
		if (r >= i && t >= n) return 0;
		if (r >= i) return -1;
		if (t >= n) return 1;
		if (t >>>= 0, n >>>= 0, r >>>= 0, i >>>= 0, this === e) return 0;
		let a = i - r, o = n - t, c = Math.min(a, o), l = this.slice(r, i), u = e.slice(t, n);
		for (let e = 0; e < c; ++e) if (l[e] !== u[e]) {
			a = l[e], o = u[e];
			break;
		}
		return a < o ? -1 : +(o < a);
	};
	function S(e, t, n, r, i) {
		if (e.length === 0) return -1;
		if (typeof n == "string" ? (r = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), n = +n, X(n) && (n = i ? 0 : e.length - 1), n < 0 && (n = e.length + n), n >= e.length) {
			if (i) return -1;
			n = e.length - 1;
		} else if (n < 0) if (i) n = 0;
		else return -1;
		if (typeof t == "string" && (t = s.from(t, r)), s.isBuffer(t)) return t.length === 0 ? -1 : C(e, t, n, r, i);
		if (typeof t == "number") return t &= 255, typeof Uint8Array.prototype.indexOf == "function" ? i ? Uint8Array.prototype.indexOf.call(e, t, n) : Uint8Array.prototype.lastIndexOf.call(e, t, n) : C(e, [t], n, r, i);
		throw TypeError("val must be string, number or Buffer");
	}
	function C(e, t, n, r, i) {
		let a = 1, o = e.length, s = t.length;
		if (r !== void 0 && (r = String(r).toLowerCase(), r === "ucs2" || r === "ucs-2" || r === "utf16le" || r === "utf-16le")) {
			if (e.length < 2 || t.length < 2) return -1;
			a = 2, o /= 2, s /= 2, n /= 2;
		}
		function c(e, t) {
			return a === 1 ? e[t] : e.readUInt16BE(t * a);
		}
		let l;
		if (i) {
			let r = -1;
			for (l = n; l < o; l++) if (c(e, l) === c(t, r === -1 ? 0 : l - r)) {
				if (r === -1 && (r = l), l - r + 1 === s) return r * a;
			} else r !== -1 && (l -= l - r), r = -1;
		} else for (n + s > o && (n = o - s), l = n; l >= 0; l--) {
			let n = !0;
			for (let r = 0; r < s; r++) if (c(e, l + r) !== c(t, r)) {
				n = !1;
				break;
			}
			if (n) return l;
		}
		return -1;
	}
	s.prototype.includes = function(e, t, n) {
		return this.indexOf(e, t, n) !== -1;
	}, s.prototype.indexOf = function(e, t, n) {
		return S(this, e, t, n, !0);
	}, s.prototype.lastIndexOf = function(e, t, n) {
		return S(this, e, t, n, !1);
	};
	function w(e, t, n, r) {
		n = Number(n) || 0;
		let i = e.length - n;
		r ? (r = Number(r), r > i && (r = i)) : r = i;
		let a = t.length;
		r > a / 2 && (r = a / 2);
		let o;
		for (o = 0; o < r; ++o) {
			let r = parseInt(t.substr(o * 2, 2), 16);
			if (X(r)) return o;
			e[n + o] = r;
		}
		return o;
	}
	function ne(e, t, n, r) {
		return J(K(t, e.length - n), e, n, r);
	}
	function T(e, t, n, r) {
		return J(le(t), e, n, r);
	}
	function E(e, t, n, r) {
		return J(q(t), e, n, r);
	}
	function re(e, t, n, r) {
		return J(ue(t, e.length - n), e, n, r);
	}
	s.prototype.write = function(e, t, n, r) {
		if (t === void 0) r = "utf8", n = this.length, t = 0;
		else if (n === void 0 && typeof t == "string") r = t, n = this.length, t = 0;
		else if (isFinite(t)) t >>>= 0, isFinite(n) ? (n >>>= 0, r === void 0 && (r = "utf8")) : (r = n, n = void 0);
		else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
		let i = this.length - t;
		if ((n === void 0 || n > i) && (n = i), e.length > 0 && (n < 0 || t < 0) || t > this.length) throw RangeError("Attempt to write outside buffer bounds");
		r ||= "utf8";
		let a = !1;
		for (;;) switch (r) {
			case "hex": return w(this, e, t, n);
			case "utf8":
			case "utf-8": return ne(this, e, t, n);
			case "ascii":
			case "latin1":
			case "binary": return T(this, e, t, n);
			case "base64": return E(this, e, t, n);
			case "ucs2":
			case "ucs-2":
			case "utf16le":
			case "utf-16le": return re(this, e, t, n);
			default:
				if (a) throw TypeError("Unknown encoding: " + r);
				r = ("" + r).toLowerCase(), a = !0;
		}
	}, s.prototype.toJSON = function() {
		return {
			type: "Buffer",
			data: Array.prototype.slice.call(this._arr || this, 0)
		};
	};
	function D(e, n, r) {
		return n === 0 && r === e.length ? t.fromByteArray(e) : t.fromByteArray(e.slice(n, r));
	}
	function O(e, t, n) {
		n = Math.min(e.length, n);
		let r = [], i = t;
		for (; i < n;) {
			let t = e[i], a = null, o = t > 239 ? 4 : t > 223 ? 3 : t > 191 ? 2 : 1;
			if (i + o <= n) {
				let n, r, s, c;
				switch (o) {
					case 1:
						t < 128 && (a = t);
						break;
					case 2:
						n = e[i + 1], (n & 192) == 128 && (c = (t & 31) << 6 | n & 63, c > 127 && (a = c));
						break;
					case 3:
						n = e[i + 1], r = e[i + 2], (n & 192) == 128 && (r & 192) == 128 && (c = (t & 15) << 12 | (n & 63) << 6 | r & 63, c > 2047 && (c < 55296 || c > 57343) && (a = c));
						break;
					case 4: n = e[i + 1], r = e[i + 2], s = e[i + 3], (n & 192) == 128 && (r & 192) == 128 && (s & 192) == 128 && (c = (t & 15) << 18 | (n & 63) << 12 | (r & 63) << 6 | s & 63, c > 65535 && c < 1114112 && (a = c));
				}
			}
			a === null ? (a = 65533, o = 1) : a > 65535 && (a -= 65536, r.push(a >>> 10 & 1023 | 55296), a = 56320 | a & 1023), r.push(a), i += o;
		}
		return A(r);
	}
	var k = 4096;
	function A(e) {
		let t = e.length;
		if (t <= k) return String.fromCharCode.apply(String, e);
		let n = "", r = 0;
		for (; r < t;) n += String.fromCharCode.apply(String, e.slice(r, r += k));
		return n;
	}
	function ie(e, t, n) {
		let r = "";
		n = Math.min(e.length, n);
		for (let i = t; i < n; ++i) r += String.fromCharCode(e[i] & 127);
		return r;
	}
	function j(e, t, n) {
		let r = "";
		n = Math.min(e.length, n);
		for (let i = t; i < n; ++i) r += String.fromCharCode(e[i]);
		return r;
	}
	function M(e, t, n) {
		let r = e.length;
		(!t || t < 0) && (t = 0), (!n || n < 0 || n > r) && (n = r);
		let i = "";
		for (let r = t; r < n; ++r) i += de[e[r]];
		return i;
	}
	function N(e, t, n) {
		let r = e.slice(t, n), i = "";
		for (let e = 0; e < r.length - 1; e += 2) i += String.fromCharCode(r[e] + r[e + 1] * 256);
		return i;
	}
	s.prototype.slice = function(e, t) {
		let n = this.length;
		e = ~~e, t = t === void 0 ? n : ~~t, e < 0 ? (e += n, e < 0 && (e = 0)) : e > n && (e = n), t < 0 ? (t += n, t < 0 && (t = 0)) : t > n && (t = n), t < e && (t = e);
		let r = this.subarray(e, t);
		return Object.setPrototypeOf(r, s.prototype), r;
	};
	function P(e, t, n) {
		if (e % 1 != 0 || e < 0) throw RangeError("offset is not uint");
		if (e + t > n) throw RangeError("Trying to access beyond buffer length");
	}
	s.prototype.readUintLE = s.prototype.readUIntLE = function(e, t, n) {
		e >>>= 0, t >>>= 0, n || P(e, t, this.length);
		let r = this[e], i = 1, a = 0;
		for (; ++a < t && (i *= 256);) r += this[e + a] * i;
		return r;
	}, s.prototype.readUintBE = s.prototype.readUIntBE = function(e, t, n) {
		e >>>= 0, t >>>= 0, n || P(e, t, this.length);
		let r = this[e + --t], i = 1;
		for (; t > 0 && (i *= 256);) r += this[e + --t] * i;
		return r;
	}, s.prototype.readUint8 = s.prototype.readUInt8 = function(e, t) {
		return e >>>= 0, t || P(e, 1, this.length), this[e];
	}, s.prototype.readUint16LE = s.prototype.readUInt16LE = function(e, t) {
		return e >>>= 0, t || P(e, 2, this.length), this[e] | this[e + 1] << 8;
	}, s.prototype.readUint16BE = s.prototype.readUInt16BE = function(e, t) {
		return e >>>= 0, t || P(e, 2, this.length), this[e] << 8 | this[e + 1];
	}, s.prototype.readUint32LE = s.prototype.readUInt32LE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + this[e + 3] * 16777216;
	}, s.prototype.readUint32BE = s.prototype.readUInt32BE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), this[e] * 16777216 + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
	}, s.prototype.readBigUInt64LE = Z(function(e) {
		e >>>= 0, W(e, "offset");
		let t = this[e], n = this[e + 7];
		(t === void 0 || n === void 0) && G(e, this.length - 8);
		let r = t + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + this[++e] * 2 ** 24, i = this[++e] + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + n * 2 ** 24;
		return BigInt(r) + (BigInt(i) << BigInt(32));
	}), s.prototype.readBigUInt64BE = Z(function(e) {
		e >>>= 0, W(e, "offset");
		let t = this[e], n = this[e + 7];
		(t === void 0 || n === void 0) && G(e, this.length - 8);
		let r = t * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + this[++e], i = this[++e] * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + n;
		return (BigInt(r) << BigInt(32)) + BigInt(i);
	}), s.prototype.readIntLE = function(e, t, n) {
		e >>>= 0, t >>>= 0, n || P(e, t, this.length);
		let r = this[e], i = 1, a = 0;
		for (; ++a < t && (i *= 256);) r += this[e + a] * i;
		return i *= 128, r >= i && (r -= 2 ** (8 * t)), r;
	}, s.prototype.readIntBE = function(e, t, n) {
		e >>>= 0, t >>>= 0, n || P(e, t, this.length);
		let r = t, i = 1, a = this[e + --r];
		for (; r > 0 && (i *= 256);) a += this[e + --r] * i;
		return i *= 128, a >= i && (a -= 2 ** (8 * t)), a;
	}, s.prototype.readInt8 = function(e, t) {
		return e >>>= 0, t || P(e, 1, this.length), this[e] & 128 ? (255 - this[e] + 1) * -1 : this[e];
	}, s.prototype.readInt16LE = function(e, t) {
		e >>>= 0, t || P(e, 2, this.length);
		let n = this[e] | this[e + 1] << 8;
		return n & 32768 ? n | 4294901760 : n;
	}, s.prototype.readInt16BE = function(e, t) {
		e >>>= 0, t || P(e, 2, this.length);
		let n = this[e + 1] | this[e] << 8;
		return n & 32768 ? n | 4294901760 : n;
	}, s.prototype.readInt32LE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
	}, s.prototype.readInt32BE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
	}, s.prototype.readBigInt64LE = Z(function(e) {
		e >>>= 0, W(e, "offset");
		let t = this[e], n = this[e + 7];
		(t === void 0 || n === void 0) && G(e, this.length - 8);
		let r = this[e + 4] + this[e + 5] * 2 ** 8 + this[e + 6] * 2 ** 16 + (n << 24);
		return (BigInt(r) << BigInt(32)) + BigInt(t + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + this[++e] * 2 ** 24);
	}), s.prototype.readBigInt64BE = Z(function(e) {
		e >>>= 0, W(e, "offset");
		let t = this[e], n = this[e + 7];
		(t === void 0 || n === void 0) && G(e, this.length - 8);
		let r = (t << 24) + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + this[++e];
		return (BigInt(r) << BigInt(32)) + BigInt(this[++e] * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + n);
	}), s.prototype.readFloatLE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), n.read(this, e, !0, 23, 4);
	}, s.prototype.readFloatBE = function(e, t) {
		return e >>>= 0, t || P(e, 4, this.length), n.read(this, e, !1, 23, 4);
	}, s.prototype.readDoubleLE = function(e, t) {
		return e >>>= 0, t || P(e, 8, this.length), n.read(this, e, !0, 52, 8);
	}, s.prototype.readDoubleBE = function(e, t) {
		return e >>>= 0, t || P(e, 8, this.length), n.read(this, e, !1, 52, 8);
	};
	function F(e, t, n, r, i, a) {
		if (!s.isBuffer(e)) throw TypeError("\"buffer\" argument must be a Buffer instance");
		if (t > i || t < a) throw RangeError("\"value\" argument is out of bounds");
		if (n + r > e.length) throw RangeError("Index out of range");
	}
	s.prototype.writeUintLE = s.prototype.writeUIntLE = function(e, t, n, r) {
		if (e = +e, t >>>= 0, n >>>= 0, !r) {
			let r = 2 ** (8 * n) - 1;
			F(this, e, t, n, r, 0);
		}
		let i = 1, a = 0;
		for (this[t] = e & 255; ++a < n && (i *= 256);) this[t + a] = e / i & 255;
		return t + n;
	}, s.prototype.writeUintBE = s.prototype.writeUIntBE = function(e, t, n, r) {
		if (e = +e, t >>>= 0, n >>>= 0, !r) {
			let r = 2 ** (8 * n) - 1;
			F(this, e, t, n, r, 0);
		}
		let i = n - 1, a = 1;
		for (this[t + i] = e & 255; --i >= 0 && (a *= 256);) this[t + i] = e / a & 255;
		return t + n;
	}, s.prototype.writeUint8 = s.prototype.writeUInt8 = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 1, 255, 0), this[t] = e & 255, t + 1;
	}, s.prototype.writeUint16LE = s.prototype.writeUInt16LE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 2, 65535, 0), this[t] = e & 255, this[t + 1] = e >>> 8, t + 2;
	}, s.prototype.writeUint16BE = s.prototype.writeUInt16BE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 2, 65535, 0), this[t] = e >>> 8, this[t + 1] = e & 255, t + 2;
	}, s.prototype.writeUint32LE = s.prototype.writeUInt32LE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 4, 4294967295, 0), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = e & 255, t + 4;
	}, s.prototype.writeUint32BE = s.prototype.writeUInt32BE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 4, 4294967295, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = e & 255, t + 4;
	};
	function I(e, t, n, r, i) {
		U(t, r, i, e, n, 7);
		let a = Number(t & BigInt(4294967295));
		e[n++] = a, a >>= 8, e[n++] = a, a >>= 8, e[n++] = a, a >>= 8, e[n++] = a;
		let o = Number(t >> BigInt(32) & BigInt(4294967295));
		return e[n++] = o, o >>= 8, e[n++] = o, o >>= 8, e[n++] = o, o >>= 8, e[n++] = o, n;
	}
	function L(e, t, n, r, i) {
		U(t, r, i, e, n, 7);
		let a = Number(t & BigInt(4294967295));
		e[n + 7] = a, a >>= 8, e[n + 6] = a, a >>= 8, e[n + 5] = a, a >>= 8, e[n + 4] = a;
		let o = Number(t >> BigInt(32) & BigInt(4294967295));
		return e[n + 3] = o, o >>= 8, e[n + 2] = o, o >>= 8, e[n + 1] = o, o >>= 8, e[n] = o, n + 8;
	}
	s.prototype.writeBigUInt64LE = Z(function(e, t = 0) {
		return I(this, e, t, BigInt(0), BigInt("0xffffffffffffffff"));
	}), s.prototype.writeBigUInt64BE = Z(function(e, t = 0) {
		return L(this, e, t, BigInt(0), BigInt("0xffffffffffffffff"));
	}), s.prototype.writeIntLE = function(e, t, n, r) {
		if (e = +e, t >>>= 0, !r) {
			let r = 2 ** (8 * n - 1);
			F(this, e, t, n, r - 1, -r);
		}
		let i = 0, a = 1, o = 0;
		for (this[t] = e & 255; ++i < n && (a *= 256);) e < 0 && o === 0 && this[t + i - 1] !== 0 && (o = 1), this[t + i] = (e / a >> 0) - o & 255;
		return t + n;
	}, s.prototype.writeIntBE = function(e, t, n, r) {
		if (e = +e, t >>>= 0, !r) {
			let r = 2 ** (8 * n - 1);
			F(this, e, t, n, r - 1, -r);
		}
		let i = n - 1, a = 1, o = 0;
		for (this[t + i] = e & 255; --i >= 0 && (a *= 256);) e < 0 && o === 0 && this[t + i + 1] !== 0 && (o = 1), this[t + i] = (e / a >> 0) - o & 255;
		return t + n;
	}, s.prototype.writeInt8 = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 1, 127, -128), e < 0 && (e = 255 + e + 1), this[t] = e & 255, t + 1;
	}, s.prototype.writeInt16LE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 2, 32767, -32768), this[t] = e & 255, this[t + 1] = e >>> 8, t + 2;
	}, s.prototype.writeInt16BE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = e & 255, t + 2;
	}, s.prototype.writeInt32LE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 4, 2147483647, -2147483648), this[t] = e & 255, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24, t + 4;
	}, s.prototype.writeInt32BE = function(e, t, n) {
		return e = +e, t >>>= 0, n || F(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = e & 255, t + 4;
	}, s.prototype.writeBigInt64LE = Z(function(e, t = 0) {
		return I(this, e, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
	}), s.prototype.writeBigInt64BE = Z(function(e, t = 0) {
		return L(this, e, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
	});
	function ae(e, t, n, r, i, a) {
		if (n + r > e.length || n < 0) throw RangeError("Index out of range");
	}
	function R(e, t, r, i, a) {
		return t = +t, r >>>= 0, a || ae(e, t, r, 4, 34028234663852886e22, -34028234663852886e22), n.write(e, t, r, i, 23, 4), r + 4;
	}
	s.prototype.writeFloatLE = function(e, t, n) {
		return R(this, e, t, !0, n);
	}, s.prototype.writeFloatBE = function(e, t, n) {
		return R(this, e, t, !1, n);
	};
	function oe(e, t, r, i, a) {
		return t = +t, r >>>= 0, a || ae(e, t, r, 8, 17976931348623157e292, -17976931348623157e292), n.write(e, t, r, i, 52, 8), r + 8;
	}
	s.prototype.writeDoubleLE = function(e, t, n) {
		return oe(this, e, t, !0, n);
	}, s.prototype.writeDoubleBE = function(e, t, n) {
		return oe(this, e, t, !1, n);
	}, s.prototype.copy = function(e, t, n, r) {
		if (!s.isBuffer(e)) throw TypeError("argument should be a Buffer");
		if (n ||= 0, !r && r !== 0 && (r = this.length), t >= e.length && (t = e.length), t ||= 0, r > 0 && r < n && (r = n), r === n || e.length === 0 || this.length === 0) return 0;
		if (t < 0) throw RangeError("targetStart out of bounds");
		if (n < 0 || n >= this.length) throw RangeError("Index out of range");
		if (r < 0) throw RangeError("sourceEnd out of bounds");
		r > this.length && (r = this.length), e.length - t < r - n && (r = e.length - t + n);
		let i = r - n;
		return this === e && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(t, n, r) : Uint8Array.prototype.set.call(e, this.subarray(n, r), t), i;
	}, s.prototype.fill = function(e, t, n, r) {
		if (typeof e == "string") {
			if (typeof t == "string" ? (r = t, t = 0, n = this.length) : typeof n == "string" && (r = n, n = this.length), r !== void 0 && typeof r != "string") throw TypeError("encoding must be a string");
			if (typeof r == "string" && !s.isEncoding(r)) throw TypeError("Unknown encoding: " + r);
			if (e.length === 1) {
				let t = e.charCodeAt(0);
				(r === "utf8" && t < 128 || r === "latin1") && (e = t);
			}
		} else typeof e == "number" ? e &= 255 : typeof e == "boolean" && (e = Number(e));
		if (t < 0 || this.length < t || this.length < n) throw RangeError("Out of range index");
		if (n <= t) return this;
		t >>>= 0, n = n === void 0 ? this.length : n >>> 0, e ||= 0;
		let i;
		if (typeof e == "number") for (i = t; i < n; ++i) this[i] = e;
		else {
			let a = s.isBuffer(e) ? e : s.from(e, r), o = a.length;
			if (o === 0) throw TypeError("The value \"" + e + "\" is invalid for argument \"value\"");
			for (i = 0; i < n - t; ++i) this[i + t] = a[i % o];
		}
		return this;
	};
	var z = {};
	function B(e, t, n) {
		z[e] = class extends n {
			constructor() {
				super(), Object.defineProperty(this, "message", {
					value: t.apply(this, arguments),
					writable: !0,
					configurable: !0
				}), this.name = `${this.name} [${e}]`, this.stack, delete this.name;
			}
			get code() {
				return e;
			}
			set code(e) {
				Object.defineProperty(this, "code", {
					configurable: !0,
					enumerable: !0,
					value: e,
					writable: !0
				});
			}
			toString() {
				return `${this.name} [${e}]: ${this.message}`;
			}
		};
	}
	B("ERR_BUFFER_OUT_OF_BOUNDS", function(e) {
		return e ? `${e} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
	}, RangeError), B("ERR_INVALID_ARG_TYPE", function(e, t) {
		return `The "${e}" argument must be of type number. Received type ${typeof t}`;
	}, TypeError), B("ERR_OUT_OF_RANGE", function(e, t, n) {
		let r = `The value of "${e}" is out of range.`, i = n;
		return Number.isInteger(n) && Math.abs(n) > 2 ** 32 ? i = V(String(n)) : typeof n == "bigint" && (i = String(n), (n > BigInt(2) ** BigInt(32) || n < -(BigInt(2) ** BigInt(32))) && (i = V(i)), i += "n"), r += ` It must be ${t}. Received ${i}`, r;
	}, RangeError);
	function V(e) {
		let t = "", n = e.length, r = +(e[0] === "-");
		for (; n >= r + 4; n -= 3) t = `_${e.slice(n - 3, n)}${t}`;
		return `${e.slice(0, n)}${t}`;
	}
	function H(e, t, n) {
		W(t, "offset"), (e[t] === void 0 || e[t + n] === void 0) && G(t, e.length - (n + 1));
	}
	function U(e, t, n, r, i, a) {
		if (e > n || e < t) {
			let r = typeof t == "bigint" ? "n" : "", i;
			throw i = a > 3 ? t === 0 || t === BigInt(0) ? `>= 0${r} and < 2${r} ** ${(a + 1) * 8}${r}` : `>= -(2${r} ** ${(a + 1) * 8 - 1}${r}) and < 2 ** ${(a + 1) * 8 - 1}${r}` : `>= ${t}${r} and <= ${n}${r}`, new z.ERR_OUT_OF_RANGE("value", i, e);
		}
		H(r, i, a);
	}
	function W(e, t) {
		if (typeof e != "number") throw new z.ERR_INVALID_ARG_TYPE(t, "number", e);
	}
	function G(e, t, n) {
		throw Math.floor(e) === e ? t < 0 ? new z.ERR_BUFFER_OUT_OF_BOUNDS() : new z.ERR_OUT_OF_RANGE(n || "offset", `>= ${+!!n} and <= ${t}`, e) : (W(e, n), new z.ERR_OUT_OF_RANGE(n || "offset", "an integer", e));
	}
	var se = /[^+/0-9A-Za-z-_]/g;
	function ce(e) {
		if (e = e.split("=")[0], e = e.trim().replace(se, ""), e.length < 2) return "";
		for (; e.length % 4 != 0;) e += "=";
		return e;
	}
	function K(e, t) {
		t ||= Infinity;
		let n, r = e.length, i = null, a = [];
		for (let o = 0; o < r; ++o) {
			if (n = e.charCodeAt(o), n > 55295 && n < 57344) {
				if (!i) {
					if (n > 56319) {
						(t -= 3) > -1 && a.push(239, 191, 189);
						continue;
					} else if (o + 1 === r) {
						(t -= 3) > -1 && a.push(239, 191, 189);
						continue;
					}
					i = n;
					continue;
				}
				if (n < 56320) {
					(t -= 3) > -1 && a.push(239, 191, 189), i = n;
					continue;
				}
				n = (i - 55296 << 10 | n - 56320) + 65536;
			} else i && (t -= 3) > -1 && a.push(239, 191, 189);
			if (i = null, n < 128) {
				if (--t < 0) break;
				a.push(n);
			} else if (n < 2048) {
				if ((t -= 2) < 0) break;
				a.push(n >> 6 | 192, n & 63 | 128);
			} else if (n < 65536) {
				if ((t -= 3) < 0) break;
				a.push(n >> 12 | 224, n >> 6 & 63 | 128, n & 63 | 128);
			} else if (n < 1114112) {
				if ((t -= 4) < 0) break;
				a.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, n & 63 | 128);
			} else throw Error("Invalid code point");
		}
		return a;
	}
	function le(e) {
		let t = [];
		for (let n = 0; n < e.length; ++n) t.push(e.charCodeAt(n) & 255);
		return t;
	}
	function ue(e, t) {
		let n, r, i, a = [];
		for (let o = 0; o < e.length && !((t -= 2) < 0); ++o) n = e.charCodeAt(o), r = n >> 8, i = n % 256, a.push(i), a.push(r);
		return a;
	}
	function q(e) {
		return t.toByteArray(ce(e));
	}
	function J(e, t, n, r) {
		let i;
		for (i = 0; i < r && !(i + n >= t.length || i >= e.length); ++i) t[i + n] = e[i];
		return i;
	}
	function Y(e, t) {
		return e instanceof t || e != null && e.constructor != null && e.constructor.name != null && e.constructor.name === t.name;
	}
	function X(e) {
		return e !== e;
	}
	var de = (function() {
		let e = "0123456789abcdef", t = Array(256);
		for (let n = 0; n < 16; ++n) {
			let r = n * 16;
			for (let i = 0; i < 16; ++i) t[r + i] = e[n] + e[i];
		}
		return t;
	})();
	function Z(e) {
		return typeof BigInt > "u" ? fe : e;
	}
	function fe() {
		throw Error("BigInt not supported");
	}
})), _ = g(), ee = Symbol(), v = Object.getPrototypeOf, y = /* @__PURE__ */ new WeakMap(), b = (e) => e && (y.has(e) ? y.get(e) : v(e) === Object.prototype || v(e) === Array.prototype), te = (e) => b(e) && e[ee] || null, x = (e, t = !0) => {
	y.set(e, t);
}, S = (e) => typeof e == "object" && !!e, C = /* @__PURE__ */ new WeakMap(), w = /* @__PURE__ */ new WeakSet(), [ne] = ((e = Object.is, t = (e, t) => new Proxy(e, t), n = (e) => S(e) && !w.has(e) && (Array.isArray(e) || !(Symbol.iterator in e)) && !(e instanceof WeakMap) && !(e instanceof WeakSet) && !(e instanceof Error) && !(e instanceof Number) && !(e instanceof Date) && !(e instanceof String) && !(e instanceof RegExp) && !(e instanceof ArrayBuffer), r = (e) => {
	switch (e.status) {
		case "fulfilled": return e.value;
		case "rejected": throw e.reason;
		default: throw e;
	}
}, i = /* @__PURE__ */ new WeakMap(), a = (e, t, n = r) => {
	let o = i.get(e);
	if (o?.[0] === t) return o[1];
	let s = Array.isArray(e) ? [] : Object.create(Object.getPrototypeOf(e));
	return x(s, !0), i.set(e, [t, s]), Reflect.ownKeys(e).forEach((t) => {
		if (Object.getOwnPropertyDescriptor(s, t)) return;
		let r = Reflect.get(e, t), i = {
			value: r,
			enumerable: !0,
			configurable: !0
		};
		if (w.has(r)) x(r, !1);
		else if (r instanceof Promise) delete i.value, i.get = () => n(r);
		else if (C.has(r)) {
			let [e, t] = C.get(r);
			i.value = a(e, t(), n);
		}
		Object.defineProperty(s, t, i);
	}), Object.preventExtensions(s);
}, o = /* @__PURE__ */ new WeakMap(), s = [1, 1], c = (r) => {
	if (!S(r)) throw Error("object required");
	let i = o.get(r);
	if (i) return i;
	let l = s[0], u = /* @__PURE__ */ new Set(), d = (e, t = ++s[0]) => {
		l !== t && (l = t, u.forEach((n) => n(e, t)));
	}, f = s[1], p = (e = ++s[1]) => (f !== e && !u.size && (f = e, h.forEach(([t]) => {
		let n = t[1](e);
		n > l && (l = n);
	})), l), m = (e) => (t, n) => {
		let r = [...t];
		r[1] = [e, ...r[1]], d(r, n);
	}, h = /* @__PURE__ */ new Map(), g = (e, t) => {
		if (u.size) {
			let n = t[3](m(e));
			h.set(e, [t, n]);
		} else h.set(e, [t]);
	}, _ = (e) => {
		var t;
		let n = h.get(e);
		n && (h.delete(e), (t = n[1]) == null || t.call(n));
	}, ee = (e) => (u.add(e), u.size === 1 && h.forEach(([e, t], n) => {
		let r = e[3](m(n));
		h.set(n, [e, r]);
	}), () => {
		u.delete(e), u.size === 0 && h.forEach(([e, t], n) => {
			t && (t(), h.set(n, [e]));
		});
	}), v = Array.isArray(r) ? [] : Object.create(Object.getPrototypeOf(r)), y = t(v, {
		deleteProperty(e, t) {
			let n = Reflect.get(e, t);
			_(t);
			let r = Reflect.deleteProperty(e, t);
			return r && d([
				"delete",
				[t],
				n
			]), r;
		},
		set(t, r, i, a) {
			let s = Reflect.has(t, r), l = Reflect.get(t, r, a);
			if (s && (e(l, i) || o.has(i) && e(l, o.get(i)))) return !0;
			_(r), S(i) && (i = te(i) || i);
			let u = i;
			if (i instanceof Promise) i.then((e) => {
				i.status = "fulfilled", i.value = e, d([
					"resolve",
					[r],
					e
				]);
			}).catch((e) => {
				i.status = "rejected", i.reason = e, d([
					"reject",
					[r],
					e
				]);
			});
			else {
				!C.has(i) && n(i) && (u = c(i));
				let e = !w.has(u) && C.get(u);
				e && g(r, e);
			}
			return Reflect.set(t, r, u, a), d([
				"set",
				[r],
				i,
				l
			]), !0;
		}
	});
	o.set(r, y);
	let b = [
		v,
		p,
		a,
		ee
	];
	return C.set(y, b), Reflect.ownKeys(r).forEach((e) => {
		let t = Object.getOwnPropertyDescriptor(r, e);
		"value" in t && (y[e] = r[e], delete t.value, delete t.writable), Object.defineProperty(v, e, t);
	}), y;
}) => [
	c,
	C,
	w,
	e,
	t,
	n,
	r,
	i,
	a,
	o,
	s
])();
function T(e = {}) {
	return ne(e);
}
function E(e, t, n) {
	let r = C.get(e), i, a = [], o = r[3], s = !1, c = o((e) => {
		if (a.push(e), n) {
			t(a.splice(0));
			return;
		}
		i ||= Promise.resolve().then(() => {
			i = void 0, s && t(a.splice(0));
		});
	});
	return s = !0, () => {
		s = !1, c();
	};
}
function re(e, t) {
	let [n, r, i] = C.get(e);
	return i(n, r(), t);
}
//#endregion
//#region ../../node_modules/.pnpm/@walletconnect+modal-core@2_10378d16a7d836aebab6d4ee5641f2bc/node_modules/@walletconnect/modal-core/dist/index.js
var D = T({
	history: ["ConnectWallet"],
	view: "ConnectWallet",
	data: void 0
}), O = {
	state: D,
	subscribe(e) {
		return E(D, () => e(D));
	},
	push(e, t) {
		e !== D.view && (D.view = e, t && (D.data = t), D.history.push(e));
	},
	reset(e) {
		D.view = e, D.history = [e];
	},
	replace(e) {
		D.history.length > 1 && (D.history[D.history.length - 1] = e, D.view = e);
	},
	goBack() {
		if (D.history.length > 1) {
			D.history.pop();
			let [e] = D.history.slice(-1);
			D.view = e;
		}
	},
	setData(e) {
		D.data = e;
	}
}, k = {
	WALLETCONNECT_DEEPLINK_CHOICE: "WALLETCONNECT_DEEPLINK_CHOICE",
	WCM_VERSION: "WCM_VERSION",
	RECOMMENDED_WALLET_AMOUNT: 9,
	isMobile() {
		return typeof window < "u" && !!(window.matchMedia("(pointer:coarse)").matches || /Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini/u.test(navigator.userAgent));
	},
	isAndroid() {
		return k.isMobile() && navigator.userAgent.toLowerCase().includes("android");
	},
	isIos() {
		let e = navigator.userAgent.toLowerCase();
		return k.isMobile() && (e.includes("iphone") || e.includes("ipad"));
	},
	isHttpUrl(e) {
		return e.startsWith("http://") || e.startsWith("https://");
	},
	isArray(e) {
		return Array.isArray(e) && e.length > 0;
	},
	isTelegram() {
		return typeof window < "u" && (!!window.TelegramWebviewProxy || !!window.Telegram || !!window.TelegramWebviewProxyProto);
	},
	formatNativeUrl(e, t, n) {
		if (k.isHttpUrl(e)) return this.formatUniversalUrl(e, t, n);
		let r = e;
		return r.includes("://") || (r = e.replaceAll("/", "").replaceAll(":", ""), r = `${r}://`), r.endsWith("/") || (r = `${r}/`), this.setWalletConnectDeepLink(r, n), `${r}wc?uri=${encodeURIComponent(t)}`;
	},
	formatUniversalUrl(e, t, n) {
		if (!k.isHttpUrl(e)) return this.formatNativeUrl(e, t, n);
		let r = e;
		if (r.startsWith("https://t.me")) {
			let e = _.Buffer.from(t).toString("base64").replace(/[=]/g, "");
			r.endsWith("/") && (r = r.slice(0, -1)), this.setWalletConnectDeepLink(r, n);
			let i = new URL(r);
			return i.searchParams.set("startapp", e), i.toString();
		}
		return r.endsWith("/") || (r = `${r}/`), this.setWalletConnectDeepLink(r, n), `${r}wc?uri=${encodeURIComponent(t)}`;
	},
	async wait(e) {
		return new Promise((t) => {
			setTimeout(t, e);
		});
	},
	openHref(e, t) {
		let n = this.isTelegram() ? "_blank" : t;
		window.open(e, n, "noreferrer noopener");
	},
	setWalletConnectDeepLink(e, t) {
		try {
			localStorage.setItem(k.WALLETCONNECT_DEEPLINK_CHOICE, JSON.stringify({
				href: e,
				name: t
			}));
		} catch {
			console.info("Unable to set WalletConnect deep link");
		}
	},
	setWalletConnectAndroidDeepLink(e) {
		try {
			let [t] = e.split("?");
			localStorage.setItem(k.WALLETCONNECT_DEEPLINK_CHOICE, JSON.stringify({
				href: t,
				name: "Android"
			}));
		} catch {
			console.info("Unable to set WalletConnect android deep link");
		}
	},
	removeWalletConnectDeepLink() {
		try {
			localStorage.removeItem(k.WALLETCONNECT_DEEPLINK_CHOICE);
		} catch {
			console.info("Unable to remove WalletConnect deep link");
		}
	},
	setModalVersionInStorage() {
		try {
			typeof localStorage < "u" && localStorage.setItem(k.WCM_VERSION, "2.7.0");
		} catch {
			console.info("Unable to set Web3Modal version in storage");
		}
	},
	getWalletRouterData() {
		let e = O.state.data?.Wallet;
		if (!e) throw Error("Missing \"Wallet\" view data");
		return e;
	}
}, A = T({
	enabled: typeof location < "u" && (location.hostname.includes("localhost") || location.protocol.includes("https")),
	userSessionId: "",
	events: [],
	connectedWalletId: void 0
}), ie = {
	state: A,
	subscribe(e) {
		return E(A.events, () => e(re(A.events[A.events.length - 1])));
	},
	initialize() {
		A.enabled && (crypto == null ? void 0 : crypto.randomUUID) !== void 0 && (A.userSessionId = crypto.randomUUID());
	},
	setConnectedWalletId(e) {
		A.connectedWalletId = e;
	},
	click(e) {
		if (A.enabled) {
			let t = {
				type: "CLICK",
				name: e.name,
				userSessionId: A.userSessionId,
				timestamp: Date.now(),
				data: e
			};
			A.events.push(t);
		}
	},
	track(e) {
		if (A.enabled) {
			let t = {
				type: "TRACK",
				name: e.name,
				userSessionId: A.userSessionId,
				timestamp: Date.now(),
				data: e
			};
			A.events.push(t);
		}
	},
	view(e) {
		if (A.enabled) {
			let t = {
				type: "VIEW",
				name: e.name,
				userSessionId: A.userSessionId,
				timestamp: Date.now(),
				data: e
			};
			A.events.push(t);
		}
	}
}, j = T({
	chains: void 0,
	walletConnectUri: void 0,
	isAuth: !1,
	isCustomDesktop: !1,
	isCustomMobile: !1,
	isDataLoaded: !1,
	isUiLoaded: !1
}), M = {
	state: j,
	subscribe(e) {
		return E(j, () => e(j));
	},
	setChains(e) {
		j.chains = e;
	},
	setWalletConnectUri(e) {
		j.walletConnectUri = e;
	},
	setIsCustomDesktop(e) {
		j.isCustomDesktop = e;
	},
	setIsCustomMobile(e) {
		j.isCustomMobile = e;
	},
	setIsDataLoaded(e) {
		j.isDataLoaded = e;
	},
	setIsUiLoaded(e) {
		j.isUiLoaded = e;
	},
	setIsAuth(e) {
		j.isAuth = e;
	}
}, N = T({
	projectId: "",
	mobileWallets: void 0,
	desktopWallets: void 0,
	walletImages: void 0,
	chains: void 0,
	enableAuthMode: !1,
	enableExplorer: !0,
	explorerExcludedWalletIds: void 0,
	explorerRecommendedWalletIds: void 0,
	termsOfServiceUrl: void 0,
	privacyPolicyUrl: void 0
}), P = {
	state: N,
	subscribe(e) {
		return E(N, () => e(N));
	},
	setConfig(e) {
		ie.initialize(), M.setChains(e.chains), M.setIsAuth(!!e.enableAuthMode), M.setIsCustomMobile(!!e.mobileWallets?.length), M.setIsCustomDesktop(!!e.desktopWallets?.length), k.setModalVersionInStorage(), Object.assign(N, e);
	}
}, F = Object.defineProperty, I = Object.getOwnPropertySymbols, L = Object.prototype.hasOwnProperty, ae = Object.prototype.propertyIsEnumerable, R = (e, t, n) => t in e ? F(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, oe = (e, t) => {
	for (var n in t ||= {}) L.call(t, n) && R(e, n, t[n]);
	if (I) for (var n of I(t)) ae.call(t, n) && R(e, n, t[n]);
	return e;
}, z = "https://explorer-api.walletconnect.com", B = "wcm", V = "js-2.7.0";
async function H(e, t) {
	let n = oe({
		sdkType: B,
		sdkVersion: V
	}, t), r = new URL(e, z);
	return r.searchParams.append("projectId", P.state.projectId), Object.entries(n).forEach(([e, t]) => {
		t && r.searchParams.append(e, String(t));
	}), (await fetch(r)).json();
}
var U = {
	async getDesktopListings(e) {
		return H("/w3m/v1/getDesktopListings", e);
	},
	async getMobileListings(e) {
		return H("/w3m/v1/getMobileListings", e);
	},
	async getInjectedListings(e) {
		return H("/w3m/v1/getInjectedListings", e);
	},
	async getAllListings(e) {
		return H("/w3m/v1/getAllListings", e);
	},
	getWalletImageUrl(e) {
		return `${z}/w3m/v1/getWalletImage/${e}?projectId=${P.state.projectId}&sdkType=${B}&sdkVersion=${V}`;
	},
	getAssetImageUrl(e) {
		return `${z}/w3m/v1/getAssetImage/${e}?projectId=${P.state.projectId}&sdkType=${B}&sdkVersion=${V}`;
	}
}, W = Object.defineProperty, G = Object.getOwnPropertySymbols, se = Object.prototype.hasOwnProperty, ce = Object.prototype.propertyIsEnumerable, K = (e, t, n) => t in e ? W(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, le = (e, t) => {
	for (var n in t ||= {}) se.call(t, n) && K(e, n, t[n]);
	if (G) for (var n of G(t)) ce.call(t, n) && K(e, n, t[n]);
	return e;
}, ue = k.isMobile(), q = T({
	wallets: {
		listings: [],
		total: 0,
		page: 1
	},
	search: {
		listings: [],
		total: 0,
		page: 1
	},
	recomendedWallets: []
}), J = {
	state: q,
	async getRecomendedWallets() {
		let { explorerRecommendedWalletIds: e, explorerExcludedWalletIds: t } = P.state;
		if (e === "NONE" || t === "ALL" && !e) return q.recomendedWallets;
		if (k.isArray(e)) {
			let t = { recommendedIds: e.join(",") }, { listings: n } = await U.getAllListings(t), r = Object.values(n);
			r.sort((t, n) => e.indexOf(t.id) - e.indexOf(n.id)), q.recomendedWallets = r;
		} else {
			let { chains: e, isAuth: n } = M.state, r = e?.join(","), i = k.isArray(t), a = {
				page: 1,
				sdks: n ? "auth_v1" : void 0,
				entries: k.RECOMMENDED_WALLET_AMOUNT,
				chains: r,
				version: 2,
				excludedIds: i ? t.join(",") : void 0
			}, { listings: o } = ue ? await U.getMobileListings(a) : await U.getDesktopListings(a);
			q.recomendedWallets = Object.values(o);
		}
		return q.recomendedWallets;
	},
	async getWallets(e) {
		let t = le({}, e), { explorerRecommendedWalletIds: n, explorerExcludedWalletIds: r } = P.state, { recomendedWallets: i } = q;
		if (r === "ALL") return q.wallets;
		i.length ? t.excludedIds = i.map((e) => e.id).join(",") : k.isArray(n) && (t.excludedIds = n.join(",")), k.isArray(r) && (t.excludedIds = [t.excludedIds, r].filter(Boolean).join(",")), M.state.isAuth && (t.sdks = "auth_v1");
		let { page: a, search: o } = e, { listings: s, total: c } = ue ? await U.getMobileListings(t) : await U.getDesktopListings(t), l = Object.values(s), u = o ? "search" : "wallets";
		return q[u] = {
			listings: [...q[u].listings, ...l],
			total: c,
			page: a ?? 1
		}, {
			listings: l,
			total: c
		};
	},
	getWalletImageUrl(e) {
		return U.getWalletImageUrl(e);
	},
	getAssetImageUrl(e) {
		return U.getAssetImageUrl(e);
	},
	resetSearch() {
		q.search = {
			listings: [],
			total: 0,
			page: 1
		};
	}
}, Y = T({ open: !1 }), X = {
	state: Y,
	subscribe(e) {
		return E(Y, () => e(Y));
	},
	async open(e) {
		return new Promise((t) => {
			let { isUiLoaded: n, isDataLoaded: r } = M.state;
			if (k.removeWalletConnectDeepLink(), M.setWalletConnectUri(e?.uri), M.setChains(e?.chains), O.reset("ConnectWallet"), n && r) Y.open = !0, t();
			else {
				let e = setInterval(() => {
					let n = M.state;
					n.isUiLoaded && n.isDataLoaded && (clearInterval(e), Y.open = !0, t());
				}, 200);
			}
		});
	},
	close() {
		Y.open = !1;
	}
}, de = Object.defineProperty, Z = Object.getOwnPropertySymbols, fe = Object.prototype.hasOwnProperty, pe = Object.prototype.propertyIsEnumerable, me = (e, t, n) => t in e ? de(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n, he = (e, t) => {
	for (var n in t ||= {}) fe.call(t, n) && me(e, n, t[n]);
	if (Z) for (var n of Z(t)) pe.call(t, n) && me(e, n, t[n]);
	return e;
};
function ge() {
	return typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches;
}
var Q = T({ themeMode: ge() ? "dark" : "light" }), _e = {
	state: Q,
	subscribe(e) {
		return E(Q, () => e(Q));
	},
	setThemeConfig(e) {
		let { themeMode: t, themeVariables: n } = e;
		t && (Q.themeMode = t), n && (Q.themeVariables = he({}, n));
	}
}, $ = T({
	open: !1,
	message: "",
	variant: "success"
}), ve = {
	state: $,
	subscribe(e) {
		return E($, () => e($));
	},
	openToast(e, t) {
		$.open = !0, $.message = e, $.variant = t;
	},
	closeToast() {
		$.open = !1;
	}
};
//#endregion
export { d as _, X as a, _e as c, s as d, o as f, f as g, p as h, J as i, ve as l, u as m, k as n, M as o, c as p, ie as r, O as s, P as t, g as u };
